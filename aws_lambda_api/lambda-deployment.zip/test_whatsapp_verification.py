#!/usr/bin/env python3

"""
WhatsApp Verification System Test Script
Tests WATI API integration and code validation locally
"""

import os
import json
import boto3
import requests
import random
from datetime import datetime, timedelta
from moto import mock_aws
from lambda_handler import send_whatsapp_verification, verify_whatsapp_code

# Test configuration
TEST_PHONE_NUMBERS = [
    '+31612345678',  # Netherlands
    '+1234567890',   # US
    '+447911123456', # UK
    '+33123456789',  # France
    '+49123456789',  # Germany
]

TEST_CUSTOMER_IDS = [
    'test_customer_1',
    'test_customer_2',
    'test_customer_3'
]

def setup_mock_environment():
    """Set up mock AWS services for testing"""
    
    # Mock DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
    
    # Create mock stj_auth table
    auth_table = dynamodb.create_table(
        TableName='stj_auth',
        KeySchema=[
            {'AttributeName': 'phone_number', 'KeyType': 'HASH'},
            {'AttributeName': 'code', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'phone_number', 'AttributeType': 'S'},
            {'AttributeName': 'code', 'AttributeType': 'S'}
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    # Create mock stj_subscribers table
    subscribers_table = dynamodb.create_table(
        TableName='stj_subscribers',
        KeySchema=[
            {'AttributeName': 'customer_id', 'KeyType': 'HASH'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'customer_id', 'AttributeType': 'S'}
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    # Add test customers
    for customer_id in TEST_CUSTOMER_IDS:
        subscribers_table.put_item(
            Item={
                'customer_id': customer_id,
                'email': f'{customer_id}@example.com',
                'username': f'{customer_id}_user',
                'created_at': datetime.now().isoformat(),
                'whatsapp_verified': False,
                'whatsapp_opt_in': False
            }
        )
    
    # Mock Secrets Manager
    secrets_client = boto3.client('secretsmanager', region_name='eu-north-1')
    
    # Create mock WATI token secret
    secrets_client.create_secret(
        Name='wati-api-token',
        SecretString=json.dumps({
            'wati-api-token': 'test_mock_wati_token_for_local_testing'
        })
    )
    
    print("✅ Mock AWS environment set up successfully")
    return dynamodb, secrets_client

def test_wati_api_direct():
    """Test direct WATI API call (optional - requires real token)"""
    print("\n🔍 Testing Direct WATI API Call")
    print("=" * 50)
    
    try:
        # Get real WATI token (only if testing with real API)
        secrets_client = boto3.client('secretsmanager', region_name='eu-north-1')
        
        try:
            secret_response = secrets_client.get_secret_value(SecretId='wati-api-token')
            secret_data = json.loads(secret_response['SecretString'])
            wati_token = secret_data['wati-api-token']
            print("✅ Retrieved real WATI token")
        except Exception as e:
            print(f"⚠️  Could not retrieve real WATI token: {e}")
            print("   Using mock token for testing")
            wati_token = "mock_token"
        
        # Test phone number (use your own for real testing)
        test_phone = "+31612345678"  # Replace with your WhatsApp number for real testing
        test_code = "123456"
        
        # WATI API configuration
        tenant_id = "443368"
        whatsapp_number = test_phone.replace('+', '')
        
        wati_url = f"https://live-mt-server.wati.io/{tenant_id}/api/v1/sendTemplateMessage"
        wati_headers = {
            'Authorization': f'Bearer {wati_token}',
            'Content-Type': 'application/json'
        }
        
        wati_payload = {
            "template_name": "auth",
            "broadcast_name": "STJ Auth Verification Test",
            "parameters": [
                {
                    "name": "1",
                    "value": test_code
                }
            ]
        }
        
        wati_params = {
            'whatsappNumber': whatsapp_number
        }
        
        print(f"📱 Sending test message to: {test_phone}")
        print(f"🔑 Verification code: {test_code}")
        print(f"🌐 WATI URL: {wati_url}")
        
        if wati_token != "mock_token":
            response = requests.post(
                wati_url,
                headers=wati_headers,
                json=wati_payload,
                params=wati_params,
                timeout=30
            )
            
            print(f"📊 Response Status: {response.status_code}")
            print(f"📄 Response Body: {response.text}")
            
            if response.status_code == 200:
                print("✅ WATI API call successful!")
            else:
                print(f"❌ WATI API call failed: {response.status_code}")
        else:
            print("🧪 Mock mode - would send message via WATI API")
            
    except Exception as e:
        print(f"❌ Error testing WATI API: {e}")

@mock_aws
def test_send_verification():
    """Test the send_whatsapp_verification function"""
    print("\n📤 Testing Send WhatsApp Verification")
    print("=" * 50)
    
    # Set up mock environment
    dynamodb, secrets_client = setup_mock_environment()
    
    # Test data
    test_cases = [
        {
            'phone_number': '+31612345678',
            'customer_id': 'test_customer_1',
            'expected_success': True,
            'description': 'Valid Dutch phone number'
        },
        {
            'phone_number': '+1234567890',
            'customer_id': 'test_customer_2',
            'expected_success': True,
            'description': 'Valid US phone number'
        },
        {
            'phone_number': '1234567890',  # No country code
            'customer_id': 'test_customer_3',
            'expected_success': False,
            'description': 'Invalid phone number (no country code)'
        },
        {
            'phone_number': '+31612345678',
            'customer_id': '',  # Empty customer ID
            'expected_success': False,
            'description': 'Missing customer ID'
        }
    ]
    
    for i, test_case in enumerate(test_cases):
        print(f"\n--- Test Case {i+1}: {test_case['description']} ---")
        
        payload = {
            'phone_number': test_case['phone_number'],
            'customer_id': test_case['customer_id']
        }
        
        try:
            result = send_whatsapp_verification(payload)
            result_data = json.loads(result['body'])
            
            print(f"📊 Status Code: {result['statusCode']}")
            print(f"📄 Response: {json.dumps(result_data, indent=2)}")
            
            if test_case['expected_success']:
                if result['statusCode'] == 200 and result_data.get('success'):
                    print("✅ Test passed - verification sent successfully")
                else:
                    print("❌ Test failed - expected success but got error")
            else:
                if result['statusCode'] != 200 or not result_data.get('success'):
                    print("✅ Test passed - correctly rejected invalid input")
                else:
                    print("❌ Test failed - should have rejected invalid input")
                    
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")

@mock_aws
def test_verify_code():
    """Test the verify_whatsapp_code function"""
    print("\n🔐 Testing WhatsApp Code Verification")
    print("=" * 50)
    
    # Set up mock environment
    dynamodb, secrets_client = setup_mock_environment()
    
    # First, send a verification to create a valid code
    send_payload = {
        'phone_number': '+31612345678',
        'customer_id': 'test_customer_1'
    }
    
    send_result = send_whatsapp_verification(send_payload)
    print(f"📤 Setup verification sent: {send_result['statusCode']}")
    
    # Get the generated code from the database (for testing)
    auth_table = dynamodb.Table('stj_auth')
    auth_items = auth_table.scan()['Items']
    
    if auth_items:
        valid_code = auth_items[0]['code']
        print(f"🔑 Generated code for testing: {valid_code}")
    else:
        valid_code = "123456"  # Fallback
        # Manually insert a test code
        auth_table.put_item(
            Item={
                'phone_number': '+31612345678',
                'code': valid_code,
                'customer_id': 'test_customer_1',
                'created_at': datetime.now().isoformat(),
                'expires_at': int((datetime.now() + timedelta(minutes=10)).timestamp()),
                'attempts': 0,
                'verified': False
            }
        )
    
    # Test cases for verification
    test_cases = [
        {
            'phone_number': '+31612345678',
            'code': valid_code,
            'customer_id': 'test_customer_1',
            'expected_success': True,
            'description': 'Valid verification code'
        },
        {
            'phone_number': '+31612345678',
            'code': '000000',  # Wrong code
            'customer_id': 'test_customer_1',
            'expected_success': False,
            'description': 'Invalid verification code'
        },
        {
            'phone_number': '+31612345678',
            'code': valid_code,
            'customer_id': 'wrong_customer',
            'expected_success': False,
            'description': 'Wrong customer ID'
        },
        {
            'phone_number': '+1234567890',  # Wrong phone
            'code': valid_code,
            'customer_id': 'test_customer_1',
            'expected_success': False,
            'description': 'Wrong phone number'
        }
    ]
    
    for i, test_case in enumerate(test_cases):
        print(f"\n--- Test Case {i+1}: {test_case['description']} ---")
        
        payload = {
            'phone_number': test_case['phone_number'],
            'code': test_case['code'],
            'customer_id': test_case['customer_id']
        }
        
        try:
            result = verify_whatsapp_code(payload)
            result_data = json.loads(result['body'])
            
            print(f"📊 Status Code: {result['statusCode']}")
            print(f"📄 Response: {json.dumps(result_data, indent=2)}")
            
            if test_case['expected_success']:
                if result['statusCode'] == 200 and result_data.get('success'):
                    print("✅ Test passed - verification successful")
                    
                    # Check if customer record was updated
                    subscribers_table = dynamodb.Table('stj_subscribers')
                    customer = subscribers_table.get_item(
                        Key={'customer_id': test_case['customer_id']}
                    )['Item']
                    
                    if customer.get('whatsapp_verified') and customer.get('whatsapp_opt_in'):
                        print("✅ Customer record updated correctly")
                    else:
                        print("❌ Customer record not updated properly")
                        
                else:
                    print("❌ Test failed - expected success but got error")
            else:
                if result['statusCode'] != 200 or not result_data.get('success'):
                    print("✅ Test passed - correctly rejected invalid verification")
                else:
                    print("❌ Test failed - should have rejected invalid verification")
                    
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")

def test_edge_cases():
    """Test edge cases and error scenarios"""
    print("\n⚠️  Testing Edge Cases")
    print("=" * 50)
    
    with mock_aws():
        dynamodb, secrets_client = setup_mock_environment()
        
        # Test 1: Multiple verification attempts
        print("\n--- Test: Multiple verification attempts ---")
        
        phone = '+31612345678'
        customer = 'test_customer_1'
        
        # Send verification
        send_result = send_whatsapp_verification({
            'phone_number': phone,
            'customer_id': customer
        })
        print(f"📤 Verification sent: {send_result['statusCode']}")
        
        # Try wrong code multiple times
        for attempt in range(1, 5):
            verify_result = verify_whatsapp_code({
                'phone_number': phone,
                'code': '000000',  # Wrong code
                'customer_id': customer
            })
            
            result_data = json.loads(verify_result['body'])
            print(f"🔄 Attempt {attempt}: {verify_result['statusCode']} - {result_data.get('error', 'Success')}")
            
            if attempt >= 3 and 'Too many' in result_data.get('error', ''):
                print("✅ Rate limiting working correctly")
                break
        
        # Test 2: Expired code
        print("\n--- Test: Expired verification code ---")
        
        # Manually insert an expired code
        auth_table = dynamodb.Table('stj_auth')
        expired_code = "999999"
        
        auth_table.put_item(
            Item={
                'phone_number': '+31987654321',
                'code': expired_code,
                'customer_id': 'test_customer_2',
                'created_at': datetime.now().isoformat(),
                'expires_at': int((datetime.now() - timedelta(minutes=1)).timestamp()),  # Expired
                'attempts': 0,
                'verified': False
            }
        )
        
        verify_result = verify_whatsapp_code({
            'phone_number': '+31987654321',
            'code': expired_code,
            'customer_id': 'test_customer_2'
        })
        
        result_data = json.loads(verify_result['body'])
        print(f"⏰ Expired code test: {verify_result['statusCode']} - {result_data.get('error', 'Success')}")
        
        if 'expired' in result_data.get('error', '').lower():
            print("✅ Expiry handling working correctly")
        else:
            print("❌ Expiry handling not working")

def run_comprehensive_test():
    """Run all tests in sequence"""
    print("🧪 WhatsApp Verification System Test Suite")
    print("=" * 60)
    print(f"🕐 Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Set environment variables for testing
    os.environ['SUBSCRIBERS_TABLE'] = 'stj_subscribers'
    
    try:
        # Test 1: Direct WATI API (optional)
        print("\n" + "=" * 60)
        test_wati_api_direct()
        
        # Test 2: Send verification function
        print("\n" + "=" * 60)
        test_send_verification()
        
        # Test 3: Verify code function
        print("\n" + "=" * 60)
        test_verify_code()
        
        # Test 4: Edge cases
        print("\n" + "=" * 60)
        test_edge_cases()
        
        print("\n" + "=" * 60)
        print("🎉 All tests completed!")
        print("📊 Check the results above for any failures")
        
    except Exception as e:
        print(f"\n❌ Test suite failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Install required packages for testing
    try:
        import moto
    except ImportError:
        print("❌ Missing required package: moto")
        print("💡 Install with: pip install moto[dynamodb,secretsmanager]")
        exit(1)
    
    run_comprehensive_test()
