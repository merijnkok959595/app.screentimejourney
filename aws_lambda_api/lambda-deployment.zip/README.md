# AWS Backend

This folder contains the AWS Lambda function for the Commitment Widget app.

## Files

- `awslambda.py` - Main Lambda function handler
- `requirements.txt` - Python dependencies for the Lambda function

## Environment Variables

Set these in your AWS Lambda environment:

```
AWS_REGION=eu-north-1
WATI_SQS_URL=<your_sqs_url>
DDB_TABLE=mk_auth
APP_PROXY_SECRET=<your_app_api_secret>
OPENAI_SECRET_NAME=CHATGPT_API_KEY
OPENAI_SECRET_KEY=CHATGPT_API_KEY
SHOP_DOMAIN=<your_shop_domain>
STOREFRONT_ACCESS_TOKEN=<your_storefront_token>
```

## Deployment

1. **Create deployment package:**
   ```bash
   cd aws_backend
   pip install -r requirements.txt -t .
   zip -r function.zip awslambda.py boto3/ botocore/ -x "*.pyc" "__pycache__/*"
   ```

2. **Deploy to AWS Lambda:**
   ```bash
   aws lambda update-function-code --function-name mk_shopify_web_app --zip-file fileb://function.zip
   ```

3. **Quick test the endpoint:**
   ```bash
   curl -X POST https://3angppkge5.execute-api.eu-north-1.amazonaws.com/default/mk_shopify_web_app/send_welcome \
   -H "Content-Type: application/json" \
   -d '{"phone": "+1234567890"}'
   ```

## API Endpoints

The Lambda function handles these endpoints:

- `/evaluate_only` - ChatGPT validation of commitment answers
- `/start_auth` - Send WhatsApp auth code
- `/verify_and_checkout` - Verify code and create Shopify checkout
- `/evaluate_and_start` - Combined evaluation and auth flow
- `/send_welcome` - Send welcome message via WhatsApp

## Dependencies

- AWS DynamoDB table `mk_auth` for code storage
- AWS SQS queue for WATI integration
- AWS Secrets Manager for OpenAI API key storage
- WATI WhatsApp integration
- Shopify Storefront API access

