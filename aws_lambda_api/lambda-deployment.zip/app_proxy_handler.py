"""
Secure App Proxy Handler for Screen Time Journey
Handles Shopify App Proxy requests with HMAC verification and JWT session management
"""

import hmac
import hashlib
import base64
import jwt
import json
import time
import urllib.parse
from typing import Dict, Any, Optional
import boto3
from datetime import datetime, timedelta


class AppProxyHandler:
    def __init__(self):
        self.app_proxy_secret = os.environ.get('SHOPIFY_API_SECRET')
        self.jwt_secret = os.environ.get('JWT_SECRET', 'your-super-secret-jwt-key')
        self.domain = 'apps.screentimejourney.com'
        self.dynamodb = boto3.resource('dynamodb')
        self.subscribers_table = self.dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))

    def verify_app_proxy_signature(self, event: Dict[str, Any]) -> bool:
        """
        Verify Shopify App Proxy HMAC signature
        https://shopify.dev/docs/apps/app-extensions/app-proxy#verify-proxy-requests
        """
        try:
            # Get query parameters
            query_params = event.get('queryStringParameters') or {}
            
            # Extract signature
            signature = query_params.get('signature')
            if not signature:
                print("❌ No signature found in App Proxy request")
                return False

            # Remove signature from params for verification
            params_copy = query_params.copy()
            del params_copy['signature']
            
            # Sort parameters and create query string
            sorted_params = sorted(params_copy.items())
            query_string = '&'.join([f"{k}={v}" for k, v in sorted_params])
            
            # Calculate expected signature
            expected_signature = hmac.new(
                self.app_proxy_secret.encode('utf-8'),
                query_string.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            # Compare signatures (constant time comparison)
            is_valid = hmac.compare_digest(signature, expected_signature)
            
            if is_valid:
                print("✅ App Proxy HMAC signature verified")
            else:
                print(f"❌ Invalid App Proxy signature. Expected: {expected_signature}, Got: {signature}")
                print(f"Query string used: {query_string}")
            
            return is_valid
            
        except Exception as e:
            print(f"❌ Error verifying App Proxy signature: {e}")
            return False

    def extract_customer_info(self, event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Extract customer information from App Proxy request
        """
        try:
            query_params = event.get('queryStringParameters') or {}
            
            # Shopify sends customer info in the request
            customer_info = {
                'customer_id': query_params.get('logged_in_customer_id'),
                'customer_email': query_params.get('customer_email'),
                'shop': query_params.get('shop'),
                'timestamp': query_params.get('timestamp')
            }
            
            # Validate required fields
            if not customer_info['customer_id'] or not customer_info['shop']:
                print("⚠️ Missing required customer info in App Proxy request")
                return None
                
            print(f"✅ Extracted customer info: {customer_info['customer_id']} from {customer_info['shop']}")
            return customer_info
            
        except Exception as e:
            print(f"❌ Error extracting customer info: {e}")
            return None

    def check_customer_entitlement(self, customer_id: str) -> Dict[str, Any]:
        """
        Check if customer has active entitlement in DynamoDB
        """
        try:
            # Query stj_subscribers table
            response = self.subscribers_table.get_item(
                Key={'customer_id': customer_id}
            )
            
            if 'Item' not in response:
                print(f"❌ Customer {customer_id} not found in subscribers table")
                return {'has_access': False, 'reason': 'customer_not_found'}
            
            customer_data = response['Item']
            subscription_status = customer_data.get('subscription_status', 'inactive')
            
            if subscription_status == 'active':
                print(f"✅ Customer {customer_id} has active entitlement")
                return {
                    'has_access': True,
                    'customer_data': customer_data,
                    'subscription_status': subscription_status
                }
            else:
                print(f"❌ Customer {customer_id} has inactive subscription: {subscription_status}")
                return {'has_access': False, 'reason': 'subscription_inactive', 'status': subscription_status}
                
        except Exception as e:
            print(f"❌ Error checking customer entitlement: {e}")
            return {'has_access': False, 'reason': 'database_error'}

    def create_jwt_token(self, customer_data: Dict[str, Any]) -> str:
        """
        Create JWT token for customer session on apps.screentimejourney.com
        """
        try:
            # Token payload
            payload = {
                'customer_id': customer_data['customer_id'],
                'email': customer_data.get('shopify_data', {}).get('customer_email', ''),
                'subscription_status': customer_data.get('subscription_status', 'active'),
                'shop': customer_data.get('shopify_data', {}).get('shop', {}).get('domain', ''),
                'iat': int(time.time()),
                'exp': int(time.time()) + (24 * 60 * 60),  # 24 hours
                'iss': 'screen-time-journey-app',
                'aud': self.domain
            }
            
            # Create JWT token
            token = jwt.encode(payload, self.jwt_secret, algorithm='HS256')
            print(f"✅ Created JWT token for customer {customer_data['customer_id']}")
            
            return token
            
        except Exception as e:
            print(f"❌ Error creating JWT token: {e}")
            return None

    def verify_jwt_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Verify and decode JWT token
        """
        try:
            payload = jwt.decode(
                token, 
                self.jwt_secret, 
                algorithms=['HS256'],
                audience=self.domain,
                issuer='screen-time-journey-app'
            )
            
            print(f"✅ Valid JWT token for customer {payload.get('customer_id')}")
            return payload
            
        except jwt.ExpiredSignatureError:
            print("❌ JWT token has expired")
            return None
        except jwt.InvalidTokenError as e:
            print(f"❌ Invalid JWT token: {e}")
            return None

    def handle_app_proxy_request(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main handler for App Proxy requests from Shopify
        """
        try:
            # 1. Verify HMAC signature
            if not self.verify_app_proxy_signature(event):
                return {
                    'statusCode': 401,
                    'headers': {'Content-Type': 'text/html'},
                    'body': '<h1>Unauthorized</h1><p>Invalid request signature.</p>'
                }

            # 2. Extract customer information
            customer_info = self.extract_customer_info(event)
            if not customer_info:
                return {
                    'statusCode': 400,
                    'headers': {'Content-Type': 'text/html'},
                    'body': '<h1>Bad Request</h1><p>Missing customer information.</p>'
                }

            # 3. Check customer entitlement
            entitlement_check = self.check_customer_entitlement(customer_info['customer_id'])
            if not entitlement_check['has_access']:
                return self.render_no_access_page(entitlement_check.get('reason', 'unknown'))

            # 4. Create JWT token
            jwt_token = self.create_jwt_token(entitlement_check['customer_data'])
            if not jwt_token:
                return {
                    'statusCode': 500,
                    'headers': {'Content-Type': 'text/html'},
                    'body': '<h1>Error</h1><p>Failed to create session token.</p>'
                }

            # 5. Redirect to custom domain with JWT
            redirect_url = f"https://{self.domain}/?token={jwt_token}"
            
            return {
                'statusCode': 302,
                'headers': {
                    'Location': redirect_url,
                    'Content-Type': 'text/html'
                },
                'body': f'<script>window.location.href="{redirect_url}";</script>'
            }

        except Exception as e:
            print(f"❌ Error handling App Proxy request: {e}")
            return {
                'statusCode': 500,
                'headers': {'Content-Type': 'text/html'},
                'body': '<h1>Internal Error</h1><p>Something went wrong. Please try again.</p>'
            }

    def render_no_access_page(self, reason: str) -> Dict[str, Any]:
        """
        Render a page for customers without access
        """
        reasons = {
            'customer_not_found': 'You need to subscribe to access this feature.',
            'subscription_inactive': 'Your subscription is not active.',
            'database_error': 'Unable to verify your subscription status.'
        }
        
        message = reasons.get(reason, 'Access denied.')
        
        html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Screen Time Journey - Subscription Required</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
                       margin: 0; padding: 40px; background: #f6f6f7; }}
                .container {{ max-width: 500px; margin: 0 auto; background: white; 
                            padding: 40px; border-radius: 12px; text-align: center; }}
                .icon {{ font-size: 64px; margin-bottom: 20px; }}
                h1 {{ color: #333; margin: 0 0 20px 0; }}
                p {{ color: #666; margin-bottom: 30px; }}
                .btn {{ background: #007cba; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 6px; display: inline-block; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">🔒</div>
                <h1>Subscription Required</h1>
                <p>{message}</p>
                <a href="/products/screen-time-journey-subscription" class="btn">Subscribe Now</a>
            </div>
        </body>
        </html>
        '''
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': html
        }

    def handle_jwt_verification(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle JWT verification for apps.screentimejourney.com
        """
        try:
            query_params = event.get('queryStringParameters') or {}
            token = query_params.get('token')
            
            if not token:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'No token provided'})
                }
            
            payload = self.verify_jwt_token(token)
            if not payload:
                return {
                    'statusCode': 401,
                    'body': json.dumps({'error': 'Invalid or expired token'})
                }
            
            # Re-verify customer entitlement
            entitlement_check = self.check_customer_entitlement(payload['customer_id'])
            if not entitlement_check['has_access']:
                return {
                    'statusCode': 403,
                    'body': json.dumps({'error': 'Access revoked'})
                }
            
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'valid': True,
                    'customer_id': payload['customer_id'],
                    'email': payload['email'],
                    'subscription_status': payload['subscription_status']
                })
            }
            
        except Exception as e:
            print(f"❌ Error verifying JWT: {e}")
            return {
                'statusCode': 500,
                'body': json.dumps({'error': 'Internal server error'})
            }
