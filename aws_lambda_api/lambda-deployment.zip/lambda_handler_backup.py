import os
import json
import time
import hmac
import uuid
import base64
import hashlib
import requests
import urllib.parse
import secrets
from typing import Any, Dict, Tuple
from datetime import datetime

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

# Import our new standardized webhook processing
try:
    from webhook_transformer import transform_webhook_to_standard
    from simple_webhook_validator import validate_webhook_simple
    STANDARDIZED_WEBHOOKS_AVAILABLE = True
    print("✅ Standardized webhook processing enabled")
except ImportError:
    STANDARDIZED_WEBHOOKS_AVAILABLE = False
    print("⚠️ Standardized webhook processing not available - using legacy processing")

# Import subscription checking functions
try:
    from subscription_check import check_subscription_status, get_customer_subscription_details
    SUBSCRIPTION_CHECK_AVAILABLE = True
    print("✅ Subscription check functions available")
except ImportError:
    SUBSCRIPTION_CHECK_AVAILABLE = False
    print("⚠️ Subscription check functions not available")


# ---------- ENVIRONMENT ----------
OPENAI_MODEL        = os.environ.get("OPENAI_MODEL", "gpt-4o")

# Secrets Manager config
OPENAI_SECRET_NAME  = os.environ.get("OPENAI_SECRET_NAME", "CHATGPT_API_KEY")
OPENAI_SECRET_KEY   = os.environ.get("OPENAI_SECRET_KEY", "CHATGPT_API_KEY")

AWS_REGION          = os.environ.get("AWS_REGION", "eu-north-1")
WATI_SQS_URL        = os.environ.get("WATI_SQS_URL", "")   # e.g. https://sqs.eu-north-1.amazonaws.com/xxx/mk-screentime-wati-outbound-handler_PROD
DDB_TABLE           = os.environ.get("DDB_TABLE", "mk_auth")  # default to mk_auth
SUBSCRIBERS_TABLE   = os.environ.get("SUBSCRIBERS_TABLE", "stj_subscribers")  # STJ subscribers table
APP_PROXY_SECRET    = os.environ.get("APP_PROXY_SECRET")  # Shopify app client secret (recommended)
SHOP_DOMAIN         = os.environ.get("SHOP_DOMAIN")       # e.g. xpvznx-9w.myshopify.com

# ---------- AWS CLIENTS ----------
boto_cfg = Config(region_name=AWS_REGION, retries={"max_attempts": 3, "mode": "standard"})
sqs = boto3.client("sqs", config=boto_cfg)
dynamodb = boto3.client("dynamodb", config=boto_cfg)
secretsmanager = boto3.client("secretsmanager", config=boto_cfg)

# ---------- UTIL ----------
def json_resp(body: Dict[str, Any], status: int = 200):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            # CORS for direct browser calls (Function URL / API Gateway). Safe for POST JSON.
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type, X-Requested-With",
            "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
        },
        "body": json.dumps(body),
    }

def parse_body(event) -> Dict[str, Any]:
    raw = event.get("body") or ""
    try:
        return json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        return {}

def verify_shopify_webhook_hmac(event: Dict[str, Any]) -> bool:
    """Verify Shopify webhook HMAC with app secret.

    Expects header `X-Shopify-Hmac-SHA256` and uses the raw request body bytes.
    """
    headers = event.get("headers", {}) or {}
    hmac_header = headers.get("x-shopify-hmac-sha256") or headers.get("X-Shopify-Hmac-SHA256")
    if not hmac_header:
        print("❌ DEBUG: Missing X-Shopify-Hmac-SHA256 header")
        return False

    secret = os.environ.get("SHOPIFY_API_SECRET") or os.environ.get("APP_PROXY_SECRET") or ""
    if not secret:
        print("❌ DEBUG: Missing SHOPIFY_API_SECRET/APP_PROXY_SECRET for HMAC verification")
        return False

    raw_body = event.get("body") or ""
    try:
        body_bytes = base64.b64decode(raw_body) if event.get("isBase64Encoded") else raw_body.encode("utf-8")
    except Exception:
        body_bytes = (raw_body or "").encode("utf-8")

    computed = base64.b64encode(hmac.new(secret.encode("utf-8"), body_bytes, hashlib.sha256).digest()).decode()
    is_valid = hmac.compare_digest(computed, hmac_header)
    if not is_valid:
        print("❌ DEBUG: HMAC verification failed")
    else:
        print("✅ DEBUG: HMAC verification passed")
    
    return is_valid

def verify_bearer_token(event: Dict[str, Any]) -> bool:
    """Verify Bearer token authentication for webhooks.
    
    Expects header `Authorization: Bearer YOUR_SHARED_SECRET`
    """
    headers = event.get("headers", {}) or {}
    auth_header = headers.get("authorization") or headers.get("Authorization", "")
    
    if not auth_header.startswith("Bearer "):
        print("❌ DEBUG: Missing or invalid Authorization header format")
        return False
    
    token = auth_header.replace("Bearer ", "").strip()
    expected_token = os.environ.get("WEBHOOK_SHARED_SECRET") or os.environ.get("SHOPIFY_API_SECRET") or ""
    
    if not expected_token:
        print("❌ DEBUG: Missing WEBHOOK_SHARED_SECRET for Bearer token verification")
        return False
    
    is_valid = secrets.compare_digest(token, expected_token)
    if not is_valid:
        print("❌ DEBUG: Bearer token verification failed")
    else:
        print("✅ DEBUG: Bearer token verification passed")
    
    return is_valid

def now_unix() -> int:
    return int(time.time())

def today_stamp() -> str:
    return time.strftime("%Y%m%d", time.gmtime())

def clean_phone_to_user_id(phone: str) -> int:
    digits = "".join(ch for ch in phone if ch.isdigit())
    if digits.startswith("00"):
        digits = digits[2:]
    # NOTE: adjust local rules if you need to preserve leading '0'
    return int(digits or "0")

# --- App Proxy signature (Shopify) ---
def parse_query(qs: str) -> Dict[str, str]:
    # decode %xx and keep blanks; do not drop repeated keys
    pairs = urllib.parse.parse_qsl(qs, keep_blank_values=True)
    d: Dict[str, str] = {}
    for k, v in pairs:
        # last writer wins if repeated
        d[k] = v
    return d

def build_hmac_message(params: Dict[str, str]) -> str:
    # Exclude 'signature'; sort keys; concat as k=v with no separators between pairs
    items = [(k, params[k]) for k in sorted(params.keys()) if k != "signature"]
    return "".join(f"{k}={v}" for k, v in items)

def verify_app_proxy_signature(event) -> bool:
    if not APP_PROXY_SECRET:
        return True  # disabled
    qs = event.get("rawQueryString") or ""
    if not qs:
        return True  # allow if you front with an authorizer before this lambda
    params = parse_query(qs)
    sig = params.get("signature")
    if not sig:
        return False
    msg = build_hmac_message(params)
    digest = hmac.new(APP_PROXY_SECRET.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).hexdigest()
    try:
        return hmac.compare_digest(digest, sig)
    except Exception:
        return False

# ---------- OPENAI (Responses API) ----------
_OPENAI_API_KEY_CACHE = None  # (key, cached_at)

def get_openai_api_key() -> str:
    """Securely fetch and cache the OpenAI key from Secrets Manager.
       Supports SecretString (JSON or plaintext) and SecretBinary.
    """
    global _OPENAI_API_KEY_CACHE
    if _OPENAI_API_KEY_CACHE:
        return _OPENAI_API_KEY_CACHE[0]

    try:
        resp = secretsmanager.get_secret_value(SecretId=OPENAI_SECRET_NAME)
        key = None

        if "SecretString" in resp and resp["SecretString"]:
            secret_str = resp["SecretString"]
            try:
                data = json.loads(secret_str)
                key = data.get(OPENAI_SECRET_KEY)
            except Exception:
                key = secret_str  # plaintext secret
        elif "SecretBinary" in resp and resp["SecretBinary"]:
            decoded = base64.b64decode(resp["SecretBinary"]).decode("utf-8", "ignore")
            try:
                data = json.loads(decoded)
                key = data.get(OPENAI_SECRET_KEY)
            except Exception:
                key = decoded

        if not key or not key.strip():
            # Do not log the reason; just fail closed
            return ""

        _OPENAI_API_KEY_CACHE = (key.strip(), time.time())
        return _OPENAI_API_KEY_CACHE[0]
    except Exception:
        return ""  # fail closed

# ---------- SHOPIFY STOREFRONT TOKEN ----------
_SHOPIFY_TOKEN_CACHE = None  # (token, cached_at)

def get_shopify_storefront_token() -> str:
    """Securely fetch and cache the Shopify Storefront Access Token from Secrets Manager."""
    global _SHOPIFY_TOKEN_CACHE
    if _SHOPIFY_TOKEN_CACHE:
        return _SHOPIFY_TOKEN_CACHE[0]

    try:
        resp = secretsmanager.get_secret_value(SecretId="Shopify-Storefront-Private-Token")
        token = None

        if "SecretString" in resp and resp["SecretString"]:
            secret_str = resp["SecretString"]
            try:
                data = json.loads(secret_str)
                token = data.get("Shopify-Storefront-Private-Token")
            except Exception:
                token = secret_str  # plaintext secret

        if not token or not token.strip():
            return ""

        _SHOPIFY_TOKEN_CACHE = (token.strip(), time.time())
        return _SHOPIFY_TOKEN_CACHE[0]
    except Exception as e:
        print(f"Error retrieving Shopify token: {e}")
        return ""  # fail closed

EVAL_SYSTEM = (
    "🧭 System Message: Evaluate Commitment Form Answers (Conversion-Optimized)\n"
    "Goal: accept if all 3 answers show genuine effort; reject only if blank or meaningless.\n"
    "Return exactly: is_passionate (boolean), feedback (string - 1-2 short sentences, personalized), surrender_text (string; empty if rejected).\n"
    "Feedback should be PERSONALIZED and CONCISE. Reference ONE key element from their answers (goal, motivation, or who they want to focus on). Keep it encouraging but brief."
)

def validate_and_fix_json(raw_json: str, max_retries: int = 2) -> Dict[str, Any]:
    """Validate JSON and fix it using GPT-4o-mini if invalid"""
    print(f"[DEBUG] Validating JSON (retries left: {max_retries}): {raw_json}")
    
    # First, try to parse the JSON directly
    try:
        parsed = json.loads(raw_json)
        # Validate required fields
        if (isinstance(parsed, dict) and 
            "is_passionate" in parsed and 
            "feedback" in parsed and 
            "surrender_text" in parsed):
            print("[DEBUG] JSON validation passed!")
            return {
                "is_passionate": bool(parsed.get("is_passionate")),
                "feedback": str(parsed.get("feedback") or ""),
                "surrender_text": str(parsed.get("surrender_text") or ""),
            }
        else:
            print(f"[DEBUG] JSON missing required fields. Parsed: {parsed}")
    except (json.JSONDecodeError, TypeError) as e:
        print(f"[DEBUG] JSON parse error: {e}")
    
    # If direct parsing failed, use GPT-4o-mini to fix the JSON
    key = get_openai_api_key()
    if not key or max_retries <= 0:
        return {"is_passionate": False, "feedback": "Could not parse evaluation. Please revise answers.", "surrender_text": ""}
    
    fix_prompt = f"""Fix this invalid JSON to match the required schema. The JSON should have exactly these fields:
- is_passionate (boolean)
- feedback (string) 
- surrender_text (string)

Invalid JSON to fix: {raw_json}

Return ONLY the corrected JSON, no explanations."""

    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "You are a JSON validator and fixer. Return only valid JSON."},
            {"role": "user", "content": fix_prompt}
        ],
        "temperature": 0.1,
        "max_tokens": 500
    }

    try:
        print("[DEBUG] Attempting to fix JSON with GPT-4o-mini...")
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            json=payload,
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            timeout=8
        )
        
        if response.status_code == 200:
            data = response.json()
            fixed_json = data.get("choices", [{}])[0].get("message", {}).get("content", "{}")
            print(f"[DEBUG] GPT-4o-mini fixed JSON: {fixed_json}")
            
            # Recursively try to validate the fixed JSON (with reduced retries)
            return validate_and_fix_json(fixed_json, max_retries - 1)
        else:
            print(f"[DEBUG] JSON fixing API error: {response.status_code} - {response.text}")
            
    except Exception as e:
        print(f"[DEBUG] JSON fixing failed: {e}")
        
    return {"is_passionate": False, "feedback": "Could not parse evaluation. Please revise answers.", "surrender_text": ""}

def openai_evaluate(q1: str, q2: str, q3: str) -> Dict[str, Any]:
    key = get_openai_api_key()
    print(f"[DEBUG] API key retrieved: {'✓' if key else '✗'} (length: {len(key) if key else 0})")
    if not key:
        # explicit denial if secret unavailable
        return {"is_passionate": False, "feedback": "Validation service unavailable. Please try again shortly.", "surrender_text": ""}

    prompt_user = f"Q1: {q1}\nQ2: {q2}\nQ3: {q3}"
    payload = {
        "model": OPENAI_MODEL,
        "messages": [
            {"role": "system", "content": EVAL_SYSTEM},
            {"role": "user", "content": prompt_user}
        ],
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": "commitment_eval",
                "schema": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "is_passionate": {"type": "boolean"},
                        "feedback": {"type": "string"},
                        "surrender_text": {"type": "string"}
                    },
                    "required": ["is_passionate", "feedback", "surrender_text"]
                }
            }
        },
        "temperature": 0.3,
        "max_tokens": 800
    }

    print(f"[DEBUG] OpenAI payload: {json.dumps(payload, indent=2)}")
    
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    
    try:
        print("[DEBUG] Making OpenAI API call...")
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            json=payload,
            headers=headers,
            timeout=15
        )
        
        print(f"[DEBUG] OpenAI API status: {response.status_code}")
        
        if response.status_code != 200:
            print(f"[DEBUG] OpenAI API error response: {response.text}")
            return {"is_passionate": False, "feedback": "Service busy—please tighten your answers and try again.", "surrender_text": ""}
            
        data = response.json()
        print(f"[DEBUG] OpenAI API response: {json.dumps(data, indent=2)[:300]}...")
        
    except Exception as e:
        print(f"[DEBUG] OpenAI API call failed: {type(e).__name__}: {e}")
        return {"is_passionate": False, "feedback": "Service busy—please tighten your answers and try again.", "surrender_text": ""}

    text = data.get("choices", [{}])[0].get("message", {}).get("content", "{}")
    
    # Debug logging
    print(f"[DEBUG] OpenAI raw response: {text}")
    
    # Use the robust validation and fixing system
    result = validate_and_fix_json(text)
    print(f"[DEBUG] Final validated result: {result}")
    return result

# ---------- CORE FLOW ----------
def store_code(phone: str, code: str, commitment: Dict[str, Any]):
    ttl = now_unix() + 10 * 60   # 10 minutes
    item = {
        "pk":          {"S": f"CODE#{phone}"},
        "code":        {"S": code},
        "createdAt":   {"N": str(now_unix())},
        "ttl":         {"N": str(ttl)},
        "commitment":  {"S": json.dumps(commitment, ensure_ascii=False)},
    }
    dynamodb.put_item(TableName=DDB_TABLE, Item=item)

def get_code_record(phone: str) -> Dict[str, Any]:
    print(f"🔍 DEBUG: get_code_record called with phone: '{phone}'")
    print(f"🔍 DEBUG: Using DDB_TABLE: '{DDB_TABLE}'")
    print(f"🔍 DEBUG: Looking for key: 'CODE#{phone}'")
    
    try:
        resp = dynamodb.get_item(
            TableName=DDB_TABLE,
            Key={"pk": {"S": f"CODE#{phone}"}},
            ConsistentRead=True,
        )
        print(f"🔍 DEBUG: DynamoDB response: {json.dumps(resp, default=str)}")
        
        item = resp.get("Item")
        print(f"🔍 DEBUG: Extracted item: {json.dumps(item, default=str) if item else 'None'}")
        
        return item
    except (BotoCoreError, ClientError) as e:
        print(f"❌ DEBUG: DynamoDB error in get_code_record: {str(e)}")
        return None

# ---------- USER MANAGEMENT ----------
def check_user_exists(customer_id: str) -> bool:
    """Check if customer exists in STJ subscribers table."""
    try:
        resp = dynamodb.get_item(
            TableName=SUBSCRIBERS_TABLE,
            Key={"customer_id": {"S": customer_id}}
        )
        return "Item" in resp
    except (BotoCoreError, ClientError):
        return False

def create_user(customer_id: str, utm_source: str = "NONE", utm_campaign: str = "NONE", utm_clickid: str = "NONE", gender: str = "", email: str = "", phone: str = "") -> bool:
    """Create customer in STJ subscribers table."""
    try:
        timestamp = datetime.utcnow().isoformat() + "Z"
        
        item = {
            "customer_id": {"S": customer_id},
            "created_at": {"S": timestamp},
            "updated_at": {"S": timestamp},
            "utm_source": {"S": utm_source},
            "utm_campaign": {"S": utm_campaign},
            "utm_clickid": {"S": utm_clickid}
        }
        
        # Add optional fields if provided
        if gender:
            item["gender"] = {"S": gender}
        if email:
            item["email"] = {"S": email}
        if phone:
            item["phone"] = {"S": phone}
            
        dynamodb.put_item(
            TableName=SUBSCRIBERS_TABLE,
            Item=item,
            ConditionExpression="attribute_not_exists(customer_id)"  # Only create if doesn't exist
        )
        print(f"✅ Created customer: {customer_id} with UTMs: {utm_source}, {utm_campaign}, {utm_clickid}")
        return True
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            print(f"ℹ️ Customer {customer_id} already exists")
            return True  # Customer already exists, that's fine
        print(f"❌ Error creating customer {customer_id}: {e}")
        return False
    except (BotoCoreError, Exception) as e:
        print(f"❌ Error creating customer {customer_id}: {e}")
        return False

def ensure_user_exists(phone: str, utm_data: dict = None, gender: str = "", email: str = "") -> str:
    """Ensure customer exists in STJ subscribers table and return customer_id."""
    # Convert phone to customer_id format (remove +)
    customer_id = phone.replace("+", "")
    
    if not check_user_exists(customer_id):
        utm_source = utm_data.get("utm_source", "NONE") if utm_data else "NONE"
        utm_campaign = utm_data.get("utm_campaign", "NONE") if utm_data else "NONE" 
        utm_clickid = utm_data.get("utm_clickid", "NONE") if utm_data else "NONE"
        
        create_user(customer_id, utm_source, utm_campaign, utm_clickid, gender, email, phone)
    
    return customer_id

def send_wati_sqs(message: Dict[str, Any]):
    sqs.send_message(
        QueueUrl=WATI_SQS_URL,
        MessageBody=json.dumps(message, ensure_ascii=False),
        MessageAttributes={
            "source": {"DataType": "String", "StringValue": "commitment_widget"},
            "action": {"DataType": "String", "StringValue": "wati_template_message"},
        },
    )

def build_broadcast(prefix: str) -> str:
    return f"{prefix}_{today_stamp()}_{now_unix()}"

def generate_code() -> str:
    # cryptographically secure 4-digit numeric code
    return str(secrets.randbelow(9000) + 1000).zfill(4)

def evaluate_and_start(payload: Dict[str, Any]) -> Dict[str, Any]:
    phone = str(payload.get("phone", "")).strip()
    q1 = str(payload.get("q1", "")).strip()
    q2 = str(payload.get("q2", "")).strip()
    q3 = str(payload.get("q3", "")).strip()

    if not (phone and q1 and q2 and q3):
        return {"ok": False, "error": "phone, q1, q2, q3 are required"}

    eval_out = openai_evaluate(q1, q2, q3)

    if not eval_out.get("is_passionate"):
        return {
            "ok": True,
            "is_passionate": False,
            "feedback": eval_out.get("feedback", ""),
            "surrender_text": "",
            "next": "revise_answers",
        }

    # If phone is dummy (for webapp validation only), don't send messages
    if phone == "+1234567890":
        return {
            "ok": True,
            "is_passionate": True,
            "feedback": eval_out.get("feedback", ""),
            "next": "webapp_validation_complete",
        }

    code = generate_code()
    try:
        store_code(phone, code, {"q1": q1, "q2": q2, "q3": q3, "surrender_text": eval_out.get("surrender_text", "")})
    except (BotoCoreError, ClientError) as e:
        return {"ok": False, "error": "temporary_store_error"}

    user_id = clean_phone_to_user_id(phone)

    evt_id_1 = f"req_{uuid.uuid4().hex}"
    msg1 = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "welcome_onboard",
            "broadcast_name": build_broadcast("commitment_widget"),
        },
        "event_execution_id": evt_id_1,
    }

    evt_id_2 = f"req_{uuid.uuid4().hex}"
    msg2 = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "auth",
            "broadcast_name": build_broadcast("commitment_auth"),
            "parameters": [{"name": "1", "value": code}],
        },
        "event_execution_id": evt_id_2,
    }

    try:
        send_wati_sqs(msg1)
        send_wati_sqs(msg2)
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "queue_unavailable"}

    return {
        "ok": True,
        "is_passionate": True,
        "feedback": eval_out.get("feedback", ""),
        "next": "await_code_in_whatsapp",
        "events": {"welcome_event_id": evt_id_1, "auth_event_id": evt_id_2},
    }

def evaluate_only(payload: Dict[str, Any]) -> Dict[str, Any]:
    q1 = str(payload.get("q1", "")).strip()
    q2 = str(payload.get("q2", "")).strip()
    q3 = str(payload.get("q3", "")).strip()
    if not (q1 and q2 and q3):
        return {"ok": False, "error": "q1, q2, q3 are required"}
    out = openai_evaluate(q1, q2, q3)
    return {
        "ok": True,
        "is_passionate": bool(out.get("is_passionate")),
        "feedback": out.get("feedback", ""),
        "surrender_text": out.get("surrender_text", ""),
    }

def start_auth(payload: Dict[str, Any]) -> Dict[str, Any]:
    phone = str(payload.get("phone", "")).strip()
    # commitment answers are optional in this entrypoint
    q1 = str(payload.get("q1", "")).strip() or None
    q2 = str(payload.get("q2", "")).strip() or None
    q3 = str(payload.get("q3", "")).strip() or None
    if not phone:
        return {"ok": False, "error": "phone is required"}

    code = generate_code()
    try:
        store_code(phone, code, {"q1": q1, "q2": q2, "q3": q3})
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "temporary_store_error"}

    user_id = clean_phone_to_user_id(phone)

    evt_id_1 = f"req_{uuid.uuid4().hex}"
    msg1 = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "welcome_onboard",
            "broadcast_name": build_broadcast("commitment_widget"),
        },
        "event_execution_id": evt_id_1,
    }

    evt_id_2 = f"req_{uuid.uuid4().hex}"
    msg2 = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "auth",
            "broadcast_name": build_broadcast("commitment_auth"),
            "parameters": [{"name": "1", "value": code}],
        },
        "event_execution_id": evt_id_2,
    }

    try:
        send_wati_sqs(msg1)
        send_wati_sqs(msg2)
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "queue_unavailable"}

    return {"ok": True, "next": "await_code_in_whatsapp", "events": {"welcome_event_id": evt_id_1, "auth_event_id": evt_id_2}}

def shopify_cart_create(variant_gid: str, selling_plan_id: str, attributes: list) -> Tuple[bool, str, str]:
    print(f"🔍 DEBUG: shopify_cart_create called with variant_gid: {variant_gid}, selling_plan_id: {selling_plan_id}")
    admin_token = get_shopify_admin_token()
    print(f"🔍 DEBUG: admin_token retrieved: {'✓' if admin_token else '✗'} (length: {len(admin_token) if admin_token else 0})")
    print(f"🔍 DEBUG: SHOP_DOMAIN: {SHOP_DOMAIN}")
    if not (SHOP_DOMAIN and admin_token):
        print("❌ DEBUG: Missing credentials - returning shopify_credentials_missing")
        return False, None, "shopify_credentials_missing"

    query = {
        "query": (
            "mutation cartCreate($input: CartInput!) {\n"
            "  cartCreate(input: $input) {\n"
            "    cart { id checkoutUrl cost { totalAmount { amount currencyCode } } }\n"
            "    userErrors { field message }\n"
            "  }\n"
            "}\n"
        ),
        "variables": {
            "input": {
                "lines": [{
                    "quantity": 1,
                    "merchandiseId": variant_gid,
                    **({"sellingPlanId": selling_plan_id} if selling_plan_id else {}),
                }],
                "attributes": attributes or [],
            }
        }
    }

    try:
        url = f"https://{SHOP_DOMAIN}/api/2025-07/graphql.json"
        print(f"🔍 DEBUG: Making request to: {url}")
        print(f"🔍 DEBUG: Query variables: {query['variables']}")
        response = requests.post(
            url,
            json=query,
            headers={
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": admin_token,
            },
            timeout=12
        )
        print(f"🔍 DEBUG: Response status: {response.status_code}")
        print(f"🔍 DEBUG: Response text: {response.text[:500]}...")
        data = response.json()
    except Exception as e:
        print(f"❌ DEBUG: Exception in shopify_cart_create: {str(e)}")
        import traceback
        traceback.print_exc()
        return False, None, "shopify_request_failed"

    print(f"🔍 DEBUG: Parsing response data: {data}")
    checkout_url = (
        data.get("data", {})
            .get("cartCreate", {})
            .get("cart", {})
            .get("checkoutUrl")
    )
    print(f"🔍 DEBUG: Extracted checkout_url: {checkout_url}")
    if checkout_url:
        print(f"✅ DEBUG: Returning success with checkout_url: {checkout_url}")
        return True, checkout_url, None

    error_msgs = ", ".join(
        m.get("message", "") for m in data.get("data", {}).get("cartCreate", {}).get("userErrors", [])
    ) or "unknown_error"
    print(f"❌ DEBUG: Returning error: {error_msgs}")
    return False, None, error_msgs



def shopify_cart_create_enhanced(variant_gid: str, selling_plan_id: str, whatsapp: str, commitment_form_data: dict, gender: str, utm_data: dict = None) -> Tuple[bool, str, str]:
    """Create Shopify cart with enhanced commitment form data and invisible UTM attributes"""
    storefront_token = get_shopify_storefront_token()
    if not (SHOP_DOMAIN and storefront_token):
        return False, None, "shopify_credentials_missing"

    # Convert commitment form data to JSON string
    commitment_form_json = json.dumps(commitment_form_data)
    
    # Build base attributes (visible and hidden)
    base_attributes = [
        {"key": "WhatsApp", "value": whatsapp.replace("+", "")},  # Visible
        {"key": "gender", "value": gender.capitalize()},  # Visible
        {"key": "_commitment_form", "value": commitment_form_json},  # Hidden
        {"key": "_source", "value": "web"},  # Hidden
    ]
    
    # Add UTM parameters as invisible checkout attributes (prefixed with _)
    if utm_data:
        for utm_key, utm_value in utm_data.items():
            if utm_value and utm_value != "NONE":
                # Store as invisible attribute with _ prefix
                base_attributes.append({"key": f"_{utm_key}", "value": str(utm_value)})
        
        # Also store complete UTM data as JSON for backup
        utm_json = json.dumps(utm_data)
        base_attributes.append({"key": "_utm_data_json", "value": utm_json})

    # Add custom thank you URL for subscriptions BEFORE creating mutation
    if selling_plan_id:
        # Add custom redirect URL as attribute for subscription orders
        base_attributes.append({"key": "_thank_you_redirect", "value": f"https://{SHOP_DOMAIN}/account/extensions/commitment-widget"})

    # Create mutation based on whether selling plan is provided
    if selling_plan_id:
        # With selling plan (subscription)
        mutation = {
            "query": "mutation CreateCart($variantId: ID!, $planId: ID!, $qty: Int!, $attributes: [AttributeInput!]!) { cartCreate(input: { attributes: $attributes, lines: [{ merchandiseId: $variantId, sellingPlanId: $planId, quantity: $qty, attributes: $attributes }] }) { cart { id checkoutUrl lines(first: 10) { edges { node { id quantity merchandise { ... on ProductVariant { id title product { title } } } sellingPlanAllocation { sellingPlan { id name } } } } } cost { totalAmount { amount currencyCode } subtotalAmount { amount currencyCode } } } userErrors { field message } } }",
            "variables": {
                "variantId": variant_gid,
                "planId": selling_plan_id,
                "qty": 1,
                "attributes": base_attributes
            }
        }
    else:
        # Without selling plan (one-time purchase)
        mutation = {
            "query": "mutation CreateCart($variantId: ID!, $qty: Int!, $attributes: [AttributeInput!]!) { cartCreate(input: { attributes: $attributes, lines: [{ merchandiseId: $variantId, quantity: $qty, attributes: $attributes }] }) { cart { id checkoutUrl lines(first: 10) { edges { node { id quantity merchandise { ... on ProductVariant { id title product { title } } } } } } cost { totalAmount { amount currencyCode } subtotalAmount { amount currencyCode } } } userErrors { field message } } }",
            "variables": {
                "variantId": variant_gid,
                "qty": 1,
                "attributes": base_attributes
            }
        }

    try:
        print(f"[DEBUG] Calling Shopify GraphQL with mutation: {mutation}")
        response = requests.post(
            f"https://{SHOP_DOMAIN}/api/2025-07/graphql.json",
            json=mutation,
            headers={
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": storefront_token,  # Use Admin API header format
            },
            timeout=12
        )
        print(f"[DEBUG] Shopify response status: {response.status_code}")
        data = response.json()
        print(f"[DEBUG] Shopify response data: {data}")
    except Exception as e:
        print(f"Shopify request error: {e}")
        import traceback
        traceback.print_exc()
        return False, None, f"shopify_request_failed: {str(e)}"

    # Check for user errors first
    user_errors = data.get("data", {}).get("cartCreate", {}).get("userErrors", [])
    if user_errors:
        error_msgs = ", ".join(m.get("message", "") for m in user_errors)
        print(f"❌ DEBUG: Shopify user errors: {error_msgs}")
        return False, None, error_msgs
    
    # Get cart data safely
    cart_data = data.get("data", {}).get("cartCreate", {}).get("cart")
    if not cart_data:
        print(f"❌ DEBUG: No cart data returned from Shopify")
        return False, None, "no_cart_data_returned"
    
    checkout_url = cart_data.get("checkoutUrl")
    if checkout_url:
        print(f"✅ DEBUG: Checkout URL obtained: {checkout_url}")
        return True, checkout_url, None

    print(f"❌ DEBUG: No checkout URL in cart data")
    return False, None, "no_checkout_url"

def verify_and_checkout(payload: Dict[str, Any]) -> Dict[str, Any]:
    print(f"🔍 DEBUG: verify_and_checkout called with payload: {json.dumps(payload, default=str)}")
    
    phone = str(payload.get("phone", "")).strip()
    code = str(payload.get("code", "")).strip()
    variant_gid = str(payload.get("variantGID", "")).strip()
    selling_plan_id = payload.get("sellingPlanId")
    q1 = str(payload.get("q1", "")).strip()
    q2 = str(payload.get("q2", "")).strip()
    q3 = str(payload.get("q3", "")).strip()
    surrender_text = str(payload.get("surrender_text", "")).strip()
    gender = str(payload.get("gender", "")).strip()

    print(f"🔍 DEBUG: Parsed values - phone: '{phone}', code: '{code}', variant_gid: '{variant_gid}'")
    print(f"🔍 DEBUG: Parsed values - q1: '{q1}', q2: '{q2}', q3: '{q3}', gender: '{gender}'")
    print(f"🔍 DEBUG: Parsed values - selling_plan_id: '{selling_plan_id}', surrender_text: '{surrender_text[:50]}...'")

    if not (phone and code and variant_gid and q1 and q2 and q3 and gender):
        missing_fields = []
        if not phone: missing_fields.append("phone")
        if not code: missing_fields.append("code")
        if not variant_gid: missing_fields.append("variantGID")
        if not q1: missing_fields.append("q1")
        if not q2: missing_fields.append("q2")
        if not q3: missing_fields.append("q3")
        if not gender: missing_fields.append("gender")
        print(f"❌ DEBUG: Missing required fields: {missing_fields}")
        return {"ok": False, "error": f"Missing required fields: {missing_fields}"}

    print(f"🔍 DEBUG: All required fields present, proceeding to verify OTP code")

    # Verify the OTP code
    print(f"🔍 DEBUG: Calling get_code_record for phone: '{phone}'")
    rec = get_code_record(phone)
    print(f"🔍 DEBUG: get_code_record returned: {rec}")
    
    if not rec:
        print(f"❌ DEBUG: No code record found for phone: '{phone}'")
        return {"ok": False, "error": "code_not_found"}
    
    print(f"🔍 DEBUG: Code record found, keys: {list(rec.keys()) if rec else 'None'}")
    
    # Safely get the stored code
    code_data = rec.get("code", {})
    print(f"🔍 DEBUG: code_data from record: {code_data}")
    
    if not code_data:
        print(f"❌ DEBUG: No code_data found in record")
        return {"ok": False, "error": "code_data_missing"}
    
    stored_code = code_data.get("S")
    print(f"🔍 DEBUG: stored_code from code_data: '{stored_code}'")
    
    if not stored_code:
        print(f"❌ DEBUG: No stored_code found in code_data")
        return {"ok": False, "error": "stored_code_missing"}
    
    print(f"🔍 DEBUG: Comparing provided code '{code}' with stored code '{stored_code}'")
    if code != stored_code:
        print(f"❌ DEBUG: Code mismatch - provided: '{code}', stored: '{stored_code}'")
        return {"ok": False, "error": "code_invalid"}
    
    print(f"✅ DEBUG: OTP code verified successfully")

    # Enhanced commitment form data (matching n8n structure exactly)
    commitment_form_data = {
        "user_id": phone.replace("+", ""),  # Remove + from phone number
        "type": "formpost",
        "q123": {
            "q1": q1,
            "q2": q2,
            "q3": q3
        },
        "surrender_text": surrender_text
    }
    
    print(f"🔍 DEBUG: Created commitment_form_data: {json.dumps(commitment_form_data, default=str)}")
    print(f"🔍 DEBUG: Calling shopify_cart_create_enhanced with:")
    print(f"🔍 DEBUG:   variant_gid: '{variant_gid}'")
    print(f"🔍 DEBUG:   selling_plan_id: '{selling_plan_id}'")
    print(f"🔍 DEBUG:   phone: '{phone}'")
    print(f"🔍 DEBUG:   gender: '{gender}'")

    # Extract UTM data from the payload
    utm_data = payload.get("utm_data", {})
    print(f"🔍 DEBUG: UTM data: {json.dumps(utm_data, default=str)}")

    try:
        ok, checkout_url, err = shopify_cart_create_enhanced(
            variant_gid, selling_plan_id, phone, commitment_form_data, gender, utm_data
        )
        print(f"🔍 DEBUG: shopify_cart_create_enhanced returned: ok={ok}, checkout_url='{checkout_url}', err='{err}'")
        
        if not ok:
            print(f"❌ DEBUG: Checkout creation failed: {err}")
            return {"ok": False, "error": err or "checkout_failed"}
        
        print(f"✅ DEBUG: Checkout created successfully: {checkout_url}")
        return {"ok": True, "checkoutUrl": checkout_url}
        
    except Exception as e:
        print(f"❌ DEBUG: Exception in shopify_cart_create_enhanced: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"ok": False, "error": f"checkout_exception: {str(e)}"}

def send_welcome_message(payload: Dict[str, Any]) -> Dict[str, Any]:
    phone = str(payload.get("phone", "")).strip()
    
    if not phone:
        return {"ok": False, "error": "phone is required"}

    user_id = clean_phone_to_user_id(phone)
    evt_id = f"req_{uuid.uuid4().hex}"
    
    msg = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "welcome_onboard",
            "broadcast_name": build_broadcast("whatsapp_setup"),
        },
        "event_execution_id": evt_id,
    }

    try:
        send_wati_sqs(msg)
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "queue_unavailable"}

    return {
        "ok": True,
        "message": "Welcome message sent successfully",
        "event_id": evt_id,
    }

def create_webapp_checkout(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Create checkout for web app flow with commitment form data and UTM tracking"""
    print(f"🔍 DEBUG: create_webapp_checkout called with payload: {payload}")
    print(f"🔍 DEBUG: Environment variables check:")
    print(f"🔍 DEBUG: - SHOPIFY_ACCESS_TOKEN: {'✓' if os.environ.get('SHOPIFY_ACCESS_TOKEN') else '✗'} (length: {len(os.environ.get('SHOPIFY_ACCESS_TOKEN', ''))})")
    print(f"🔍 DEBUG: - SHOP_DOMAIN: {'✓' if os.environ.get('SHOP_DOMAIN') else '✗'} ({os.environ.get('SHOP_DOMAIN', 'None')})")
    print(f"🔍 DEBUG: - SHOPIFY_STOREFRONT_TOKEN: {'✓' if os.environ.get('SHOPIFY_STOREFRONT_TOKEN') else '✗'} (length: {len(os.environ.get('SHOPIFY_STOREFRONT_TOKEN', ''))})")
    
    q1 = str(payload.get("q1", "")).strip()
    q2 = str(payload.get("q2", "")).strip()
    q3 = str(payload.get("q3", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    variant_gid = str(payload.get("variantGID", "")).strip()
    selling_plan_id = payload.get("sellingPlanId")
    country_code = payload.get("country_code", "US")
    surrender_text = str(payload.get("surrender_text", "")).strip()
    
    # Extract UTM data
    utm_data = {
        "utm_source": payload.get("utm_source", "direct"),
        "utm_campaign": payload.get("utm_campaign", "organic"),
        "utm_clickid": payload.get("utm_clickid", "none")
    }
    
    print(f"🔍 DEBUG: Parsed values - q1: '{q1}', q2: '{q2}', q3: '{q3}', variant_gid: '{variant_gid}'")
    print(f"🔍 DEBUG: Parsed values - selling_plan_id: '{selling_plan_id}', phone: '{phone}', country_code: '{country_code}'")
    print(f"🔍 DEBUG: Parsed values - surrender_text: '{surrender_text[:50]}...' (length: {len(surrender_text)})")
    print(f"🔍 DEBUG: UTM data: {utm_data}")
    
    if not (q1 and q2 and q3 and variant_gid):
        missing_fields = []
        if not q1: missing_fields.append('q1')
        if not q2: missing_fields.append('q2') 
        if not q3: missing_fields.append('q3')
        if not variant_gid: missing_fields.append('variantGID')
        print(f"❌ DEBUG: Missing required fields: {missing_fields}")
        return {"ok": False, "error": f"Missing required fields: {missing_fields}"}
    
    # Build commitment form data with UTM tracking and surrender_text
    commitment_form_data = {
        "q1": q1,
        "q2": q2,
        "q3": q3,
        "gender": payload.get("gender", ""),
        "phone": phone,
        "country_code": country_code,
        "utm_source": utm_data["utm_source"],
        "utm_campaign": utm_data["utm_campaign"],
        "utm_clickid": utm_data["utm_clickid"],
        "surrender_text": surrender_text,
        "source": "commitment_widget_webapp"
    }
    
    # Create the checkout using enhanced cart creation with UTM tracking
    print(f"🔍 DEBUG: Calling shopify_cart_create_enhanced with variant_gid: {variant_gid}, selling_plan_id: {selling_plan_id}")
    ok, checkout_url, err = shopify_cart_create_enhanced(
        variant_gid=variant_gid,
        selling_plan_id=selling_plan_id,
        whatsapp=phone,
        commitment_form_data=commitment_form_data,
        gender=payload.get("gender", ""),
        utm_data=utm_data
    )
    print(f"🔍 DEBUG: shopify_cart_create_enhanced returned: ok={ok}, checkout_url={checkout_url}, err={err}")
    
    if not ok:
        print(f"❌ DEBUG: Checkout creation failed: {err}")
        detailed_error = f"Checkout creation failed: {err}"
        if err == "shopify_credentials_missing":
            detailed_error = "Missing Shopify credentials. Please check SHOPIFY_ACCESS_TOKEN and SHOP_DOMAIN environment variables."
        return {"ok": False, "error": detailed_error}
    
    print(f"✅ DEBUG: Checkout creation successful, returning response")
    response = {
        "ok": True, 
        "checkoutUrl": checkout_url,
        "message": "Checkout created successfully"
    }
    print(f"🔍 DEBUG: Final response: {response}")
    return response

def send_auth_code(payload: Dict[str, Any]) -> Dict[str, Any]:
    phone = str(payload.get("phone", "")).strip()
    utm_data = payload.get("utm_data", {})
    
    if not phone:
        return {"ok": False, "error": "phone is required"}

    # Ensure user exists in subscribers table with UTM data
    user_id = ensure_user_exists(phone, utm_data)

    # Generate and store a 4-digit code
    code = generate_code()
    try:
        store_code(phone, code, {"auth_type": "whatsapp_verification"})
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "temporary_store_error"}
    evt_id = f"req_{uuid.uuid4().hex}"
    
    msg = {
        "user_id": user_id,
        "event_endpoint": "/sendTemplateMessage",
        "event_payload": {
            "template_name": "auth",
            "broadcast_name": build_broadcast("whatsapp_auth"),
            "parameters": [{"name": "1", "value": code}],
        },
        "event_execution_id": evt_id,
    }

    try:
        send_wati_sqs(msg)
    except (BotoCoreError, ClientError):
        return {"ok": False, "error": "queue_unavailable"}

    return {
        "ok": True,
        "message": "Authentication code sent successfully",
        "event_id": evt_id,
    }

def handle_standardized_webhook(raw_payload: Dict[str, Any], webhook_endpoint: str) -> Dict[str, Any]:
    """
    Process webhook using standardized structure (NEW METHOD)
    Supports: subscription-created, subscription-cancelled, orders-paid
    """
    
    print(f"📨 Processing standardized webhook: {webhook_endpoint}")
    
    try:
        if not STANDARDIZED_WEBHOOKS_AVAILABLE:
            print("⚠️ Falling back to legacy webhook processing")
            return handle_shopify_webhook_legacy(raw_payload, webhook_endpoint)
        
        # Step 1: Transform to standardized structure
        print("🔄 Step 1: Transforming to standardized structure...")
        standard_payload = transform_webhook_to_standard(raw_payload, webhook_endpoint)
        print(f"✅ Transformed to: {standard_payload.get('webhook_type')}")
        
        # Step 2: Validate the standardized webhook
        print("🔄 Step 2: Validating standardized webhook...")
        validation_result = validate_webhook_simple(standard_payload)
        
        if not validation_result["ok"]:
            print(f"❌ Validation failed: {len(validation_result['issues'])} issues")
            for issue in validation_result['issues']:
                print(f"  - {issue['path']}: {issue['message']}")
            return validation_result
        
        print("✅ Webhook validation passed")
        validated_data = validation_result["data"]
        
        # Step 3: Process the validated webhook
        print("🔄 Step 3: Processing validated webhook...")
        return process_standardized_webhook_data(validated_data)
        
    except Exception as e:
        print(f"❌ Error in standardized webhook processing: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            "ok": False,
            "error": "standardized_webhook_failed",
            "details": str(e)
        }


def process_standardized_webhook_data(validated_data: Dict[str, Any]) -> Dict[str, Any]:
    """Process validated standardized webhook data"""
    
    webhook_type = validated_data.get("webhook_type")
    customer = validated_data.get("customer", {})
    customer_email = customer.get("email", "unknown")
    customer_id = customer.get("id", "unknown")
    
    print(f"🔄 Processing validated {webhook_type} for customer: {customer_email}")
    
    try:
        # Determine status based on webhook type
        if "cancelled" in webhook_type:
            status = "cancelled"
        elif "created" in webhook_type or "paid" in webhook_type:
            status = "active"
        else:
            status = "unknown"
        
        # Use existing update function with standardized data
        success = update_subscriber_record_safe(
            email=customer_email,
            customer_id=customer_id,
            event_type=webhook_type,
            status=status,
            shopify_data=validated_data,
            commitment_form=validated_data.get("commitment_data") or {},
            country_code=(validated_data.get("commitment_data") or {}).get("country_code"),
            source="standardized_webhook"
        )
        
        if success:
            print(f"✅ Standardized webhook processed for {customer_email}")
            return {
                "ok": True,
                "message": f"Webhook {webhook_type} processed successfully",
                "customer_email": customer_email,
                "status": status
            }
        else:
            print(f"❌ Failed to process standardized webhook for {customer_email}")
            return {
                "ok": False,
                "error": "database_update_failed"
            }
            
    except Exception as e:
        print(f"❌ Error processing standardized webhook data: {str(e)}")
        return {
            "ok": False,
            "error": "processing_failed",
            "details": str(e)
        }


def handle_shopify_webhook_legacy(webhook_payload: Dict[str, Any], webhook_endpoint: str) -> Dict[str, Any]:
    """Legacy webhook processing (FALLBACK)"""
    
    # Map endpoints to topics for legacy processing
    topic_mapping = {
        "/subscription-created": "subscription_contracts/create",
        "/subscription-cancelled": "subscription_contracts/cancel",
        "/orders-paid": "orders/paid"
    }
    
    topic = topic_mapping.get(webhook_endpoint, "unknown")
    print(f"📨 Processing {topic} webhook (legacy mode)...")
    
    try:
        if topic.startswith("subscription_contracts/"):
            return process_subscription_webhook(webhook_payload, topic)
        elif topic == "orders/paid":
            return process_order_webhook(webhook_payload, topic)
        else:
            print(f"⚠️ Ignoring webhook topic: {topic}")
            return {"ok": True, "message": f"Webhook {topic} received but not processed"}
            
    except Exception as e:
        print(f"❌ Error processing {topic} webhook: {str(e)}")
        return {
            "ok": False,
            "error": "webhook_processing_failed",
            "topic": topic,
            "details": str(e)
        }


def handle_shopify_webhook(webhook_payload: Dict[str, Any], topic: str) -> Dict[str, Any]:
    """Process Shopify webhook directly and store relevant data (LEGACY)"""
    
    print(f"📨 Processing {topic} webhook directly...")
    
    try:
        if topic.startswith("subscription_contracts/"):
            return process_subscription_webhook(webhook_payload, topic)
        elif topic.startswith("subscription_billing_attempts/"):
            return process_billing_webhook(webhook_payload, topic)
        elif topic == "orders/paid":
            return process_order_webhook(webhook_payload, topic)
        else:
            # Log other webhooks but don't process
            print(f"⚠️ Ignoring webhook topic: {topic}")
            return {"ok": True, "message": f"Webhook {topic} received but not processed"}
            
    except Exception as e:
        print(f"❌ Error processing {topic} webhook: {str(e)}")
        return {
            "ok": False,
            "error": "webhook_processing_failed",
            "topic": topic,
            "details": str(e)
        }

def process_subscription_webhook(payload: Dict[str, Any], topic: str) -> Dict[str, Any]:
    """Process subscription contract webhooks"""
    
    subscription_id = payload.get("id")
    customer = payload.get("customer", {})
    customer_email = customer.get("email", "unknown")
    customer_id = customer.get("id", "unknown")
    status = payload.get("status", "unknown")
    
    print(f"🔗 Processing subscription {topic} for customer: {customer_email}")
    
    # Extract subscription data
    subscriber_data = {
        "subscription_id": subscription_id,
        "customer_id": customer_id,
        "customer_email": customer_email,
        "status": status,
        "created_at": payload.get("created_at"),
        "updated_at": payload.get("updated_at"),
        "next_billing_date": payload.get("next_billing_date"),
        "line_items": payload.get("line_items", []),
        "billing_address": payload.get("billing_address", {}),
        "delivery_address": payload.get("delivery_address", {}),
        "event_type": topic,
        "last_updated": datetime.now().isoformat(),
        "source": "webhook"
    }
    
    # Determine subscription status for metafield
    subscription_status_active = "true" if status in ["ACTIVE", "active"] else "false"
    
    # Store in DynamoDB using safe update
    success = update_subscriber_record_safe(
        email=customer_email,
        customer_id=customer_id,
        event_type=topic,
        status=status,
        shopify_data=subscriber_data,
        subscription_status_active=subscription_status_active,
        source="webhook"
    )
    
    if success:
        print(f"✅ Subscription data stored for {customer_email}")
        return {"ok": True, "message": f"Subscription {topic} processed successfully"}
    else:
        print(f"❌ Failed to store subscription data for {customer_email}")
        return {"ok": False, "error": "database_update_failed"}

def process_billing_webhook(payload: Dict[str, Any], topic: str) -> Dict[str, Any]:
    """Process subscription billing attempt webhooks"""
    
    subscription_contract = payload.get("subscription_contract", {})
    customer = subscription_contract.get("customer", {})
    customer_email = customer.get("email", "unknown")
    
    print(f"💳 Processing billing {topic} for customer: {customer_email}")
    
    # Extract billing data
    billing_data = {
        "billing_attempt_id": payload.get("id"),
        "subscription_id": subscription_contract.get("id"),
        "customer_email": customer_email,
        "status": "success" if "success" in topic else "failure",
        "error_message": payload.get("error_message"),
        "error_code": payload.get("error_code"),
        "total_price": payload.get("total_price"),
        "currency": payload.get("currency_code"),
        "created_at": payload.get("created_at"),
        "event_type": topic,
        "last_updated": datetime.now().isoformat(),
        "source": "webhook"
    }
    
    # Store in DynamoDB
    success = update_subscriber_record(
        email=customer_email,
        event_type=topic,
        shopify_data=billing_data,
        source="webhook"
    )
    
    if success:
        print(f"✅ Billing data stored for {customer_email}")
        return {"ok": True, "message": f"Billing {topic} processed successfully"}
    else:
        print(f"❌ Failed to store billing data for {customer_email}")
        return {"ok": False, "error": "database_update_failed"}

def process_order_webhook(payload: Dict[str, Any], topic: str) -> Dict[str, Any]:
    """Process orders/paid webhook and extract commitment form data"""
    
    customer = payload.get("customer", {})
    customer_email = customer.get("email", "unknown") if customer else "unknown"
    customer_id = customer.get("id", "unknown") if customer else "unknown"
    
    print(f"🛒 Processing order {topic} for customer: {customer_email}")
    
    # Extract commitment form data from order metafields or line items
    commitment_data = extract_commitment_form_data(payload)
    
    # Extract order data
    order_data = {
        "order_id": payload.get("id"),
        "order_number": payload.get("order_number"),
        "customer_email": customer_email,
        "customer_id": customer_id,
        "total_price": payload.get("total_price"),
        "currency": payload.get("currency"),
        "line_items": payload.get("line_items", []),
        "created_at": payload.get("created_at"),
        "financial_status": payload.get("financial_status"),
        "commitment_form_data": commitment_data,
        "event_type": topic,
        "last_updated": datetime.now().isoformat(),
        "source": "webhook"
    }
    
    # Store in DynamoDB ONLY if customer exists AND commitment form data is present (first-time orders)
    if customer_email != "unknown":
        # Debug: Print what commitment data was found
        print(f"🔍 DEBUG: Commitment data found: {commitment_data}")
        print(f"🔍 DEBUG: q1={commitment_data.get('q1')}, q2={commitment_data.get('q2')}, q3={commitment_data.get('q3')}, phone={commitment_data.get('phone')}")
        
        # Check if this is a first-time order with commitment form data
        has_commitment_data = (
            commitment_data.get("q1") or 
            commitment_data.get("q2") or 
            commitment_data.get("q3") or
            commitment_data.get("phone")
        )
        
        print(f"🔍 DEBUG: Final commitment data check - has_commitment_data: {has_commitment_data}")
        print(f"🔍 DEBUG: commitment_data keys: {list(commitment_data.keys())}")
        print(f"🔍 DEBUG: commitment_data values: {commitment_data}")
        
        if has_commitment_data:
            print(f"📝 First-time order detected with commitment form data for {customer_email}")
            
            # Extract individual fields from commitment_data for separate storage
            commitment_form = {
                "q1": commitment_data.get("q1", ""),
                "q2": commitment_data.get("q2", ""),
                "q3": commitment_data.get("q3", ""),
                "gender": commitment_data.get("gender", ""),
                "phone": commitment_data.get("phone", "")
            }
            
            # Extract surrender_text separately
            surrender_text = commitment_data.get("surrender_text", "")
            
            # Extract UTM data from commitment_data
            utm_data = commitment_data.get("utm_data", {})
            if not utm_data:
                # Fallback to defaults if no UTM data found
                utm_data = {
                    "utm_source": "direct",
                    "utm_campaign": "organic", 
                    "utm_clickid": "none"
                }
            
            success = update_subscriber_record_safe(
                email=customer_email,
                customer_id=customer_id,
                event_type="subscription_contracts/create",  # Keep the original event type
                shopify_data=order_data,
                commitment_form=commitment_form,
                surrender_text=surrender_text,
                utm_data=utm_data,
                country_code=commitment_data.get("country_code", ""),
                source="webhook"
            )
            
            if success:
                print(f"✅ First-time order data stored for {customer_email}")
                return {"ok": True, "message": f"First-time order {topic} processed successfully"}
            else:
                print(f"❌ Failed to store first-time order data for {customer_email}")
                return {"ok": False, "error": "database_update_failed"}
        else:
            print(f"⏭️ Skipping order {payload.get('id')} - no commitment form data (not first-time order)")
            return {"ok": True, "message": "Order processed but no commitment form data to update"}
    else:
        print(f"⚠️ Order {payload.get('id')} has no customer email")
        return {"ok": True, "message": "Order processed but no customer to update"}

def extract_commitment_form_data(order_payload: Dict[str, Any]) -> Dict[str, Any]:
    """Extract commitment form data from order metafields or line items"""
    
    commitment_data = {}
    
    try:
        # Check for commitment form data in metafields
        metafields = order_payload.get("metafields", [])
        for metafield in metafields:
            if metafield.get("key") in ["commitment_form_data", "mk_commitment_data"]:
                try:
                    commitment_data = json.loads(metafield.get("value", "{}"))
                    print(f"📝 Found commitment form data in metafields: {commitment_data}")
                    break
                except json.JSONDecodeError:
                    print(f"⚠️ Invalid JSON in commitment metafield: {metafield.get('value')}")
        
        # If no metafields, check line items for commitment form data
        if not commitment_data:
            line_items = order_payload.get("line_items", [])
            print(f"🔍 DEBUG: Checking {len(line_items)} line items for commitment form data")
            for i, item in enumerate(line_items):
                print(f"🔍 DEBUG: Line item {i}: title='{item.get('title', 'N/A')}'")
                # Check if this line item has commitment form data in properties
                properties = item.get("properties", [])
                has_commitment_data = any(
                    prop.get("name") in ["_commitment_form", "q1", "q2", "q3", "gender", "phone", "commitment_goals", "country_code"]
                    for prop in properties
                )
                
                if has_commitment_data:
                    print(f"🔍 DEBUG: Found commitment/screentime product in line item {i}")
                    # Extract data from line item properties
                    properties = item.get("properties", [])
                    print(f"🔍 DEBUG: Found {len(properties)} properties in line item {i}")
                    for prop in properties:
                        prop_name = prop.get("name", "")
                        prop_value = prop.get("value", "")
                        print(f"🔍 DEBUG: Property: {prop_name} = {prop_value[:100]}...")
                        
                        # Check for the _commitment_form JSON property first
                        if prop_name == "_commitment_form":
                            try:
                                # First try to parse as regular JSON
                                commitment_json = json.loads(prop_value)
                                commitment_data.update(commitment_json)
                                print(f"📝 Found commitment form JSON in line item: {commitment_json}")
                            except json.JSONDecodeError:
                                print(f"⚠️ Invalid commitment form JSON in line item: {prop_value}")
                                # Try to handle double-escaped JSON
                                try:
                                    # Remove extra escaping
                                    cleaned_value = prop_value.replace('\\"', '"').replace('\\\\', '\\')
                                    commitment_json = json.loads(cleaned_value)
                                    commitment_data.update(commitment_json)
                                    print(f"📝 Found commitment form JSON (cleaned) in line item: {commitment_json}")
                                except json.JSONDecodeError:
                                    print(f"⚠️ Still invalid JSON after cleaning: {cleaned_value}")
                                    # Try to extract individual fields as fallback
                                    if "q1" in prop_value or "q2" in prop_value or "q3" in prop_value:
                                        print(f"📝 Attempting to extract individual fields from: {prop_value}")
                                        # Extract basic fields using regex as fallback
                                        import re
                                        q1_match = re.search(r'"q1"\s*:\s*"([^"]+)"', prop_value)
                                        q2_match = re.search(r'"q2"\s*:\s*"([^"]+)"', prop_value)
                                        q3_match = re.search(r'"q3"\s*:\s*"([^"]+)"', prop_value)
                                        phone_match = re.search(r'"phone"\s*:\s*"([^"]+)"', prop_value)
                                        
                                        if q1_match:
                                            commitment_data["q1"] = q1_match.group(1)
                                        if q2_match:
                                            commitment_data["q2"] = q2_match.group(1)
                                        if q3_match:
                                            commitment_data["q3"] = q3_match.group(1)
                                        if phone_match:
                                            commitment_data["phone"] = phone_match.group(1)
                        # Also check individual commitment form fields
                        elif prop_name in ["q1", "q2", "q3", "gender", "phone", "commitment_goals", "country_code"]:
                            commitment_data[prop_name] = prop_value
                    
                    if commitment_data:
                        print(f"📝 Found commitment form data in line item: {commitment_data}")
                        break
        
        # If still no data, check order note or tags
        if not commitment_data:
            order_note = order_payload.get("note") or ""
            if order_note and "commitment" in order_note.lower():
                # Try to extract JSON from note
                try:
                    # Look for JSON pattern in note
                    import re
                    json_match = re.search(r'\{.*\}', order_note)
                    if json_match:
                        commitment_data = json.loads(json_match.group())
                        print(f"📝 Found commitment form data in order note: {commitment_data}")
                except (json.JSONDecodeError, AttributeError):
                    pass
        
        # Extract country code from customer data if not found in commitment form
        if not commitment_data.get("country_code"):
            customer = order_payload.get("customer", {})
            if customer:
                # Try to get country code from customer's default address
                default_address = customer.get("default_address", {})
                if default_address:
                    country_code = default_address.get("country_code")
                    if country_code:
                        commitment_data["country_code"] = country_code
                        print(f"🌍 Found country code from customer address: {country_code}")
                
                # Fallback to customer's country code field
                if not commitment_data.get("country_code"):
                    country_code = customer.get("country_code")
                    if country_code:
                        commitment_data["country_code"] = country_code
                        print(f"🌍 Found country code from customer: {country_code}")
        
        # Extract country code from billing address if still not found
        if not commitment_data.get("country_code"):
            billing_address = order_payload.get("billing_address", {})
            if billing_address:
                country_code = billing_address.get("country_code")
                if country_code:
                    commitment_data["country_code"] = country_code
                    print(f"🌍 Found country code from billing address: {country_code}")
        
        # Extract country code from shipping address as last resort
        if not commitment_data.get("country_code"):
            shipping_address = order_payload.get("shipping_address", {})
            if shipping_address:
                country_code = shipping_address.get("country_code")
                if country_code:
                    commitment_data["country_code"] = country_code
                    print(f"🌍 Found country code from shipping address: {country_code}")
        
        # Extract UTM data from line item properties (invisible attributes)
        utm_data = {}
        line_items = order_payload.get("line_items", [])
        for item in line_items:
            properties = item.get("properties", [])
            for prop in properties:
                prop_name = prop.get("name", "")
                prop_value = prop.get("value", "")
                
                # Look for UTM parameters (invisible attributes with _ prefix)
                if prop_name in ["_utm_source", "_utm_campaign", "_utm_clickid", "_utm_data_json"]:
                    if prop_name == "_utm_data_json":
                        try:
                            utm_json = json.loads(prop_value)
                            utm_data.update(utm_json)
                            print(f"📊 Found UTM data from JSON: {utm_json}")
                        except json.JSONDecodeError:
                            print(f"⚠️ Invalid UTM JSON: {prop_value}")
                    else:
                        # Remove _ prefix for storage
                        clean_name = prop_name.replace("_", "")
                        utm_data[clean_name] = prop_value
                        print(f"📊 Found UTM {clean_name}: {prop_value}")
        
        # Add UTM data to commitment data if found
        if utm_data:
            commitment_data["utm_data"] = utm_data
            print(f"📊 Added UTM data to commitment form: {utm_data}")
        
    except Exception as e:
        print(f"❌ Error extracting commitment form data: {str(e)}")
    
    return commitment_data

def update_subscriber_record_safe(email: str, customer_id: str = None, event_type: str = None, status: str = None, shopify_data: Dict[str, Any] = None, commitment_form: Dict[str, Any] = None, surrender_text: str = None, utm_data: Dict[str, Any] = None, country_code: str = None, source: str = "webhook", **kwargs) -> bool:
    """Update subscriber record in DynamoDB with race condition prevention and proper partition keys"""
    
    try:
        # Connect to DynamoDB subscribers table
        dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
        subscribers_table = dynamodb.Table('tpl_subscribers')
        
        # Use customer_id as shopify_id for DynamoDB primary key, or email as fallback
        # Ensure shopify_id is always a string for DynamoDB compatibility
        if customer_id and customer_id != "unknown":
            shopify_id = str(customer_id)  # Convert to string for DynamoDB
        else:
            shopify_id = email
        
        # Prepare update expression and attribute values
        update_expression_parts = []
        expression_attribute_values = {}
        expression_attribute_names = {}
        
        # Always update the last_updated timestamp
        update_expression_parts.append("#last_updated = :last_updated")
        expression_attribute_names["#last_updated"] = "last_updated"
        expression_attribute_values[":last_updated"] = datetime.now().isoformat()
        
        # Update event type if provided
        if event_type:
            update_expression_parts.append("#event_type = :event_type")
            expression_attribute_names["#event_type"] = "event_type"
            expression_attribute_values[":event_type"] = event_type
        
        # Update status if provided
        if status:
            update_expression_parts.append("#status = :status")
            expression_attribute_names["#status"] = "status"
            expression_attribute_values[":status"] = status
        
        # Update source
        update_expression_parts.append("#source = :source")
        expression_attribute_names["#source"] = "source"
        expression_attribute_values[":source"] = source
        
        # Add shopify_data if provided (merge with existing data to prevent overwrites)
        if shopify_data:
            # Always try to merge with existing shopify_data, create if doesn't exist
            try:
                existing_response = subscribers_table.get_item(Key={'shopify_id': shopify_id})
                if 'Item' in existing_response:
                    existing_item = existing_response['Item']
                    existing_shopify_data = existing_item.get('shopify_data', {})
                    
                    # Merge the data intelligently
                    merged_shopify_data = existing_shopify_data.copy()
                    
                    # For each key in new data, merge based on type
                    for key, new_value in shopify_data.items():
                        if key in existing_shopify_data:
                            existing_value = existing_shopify_data[key]
                            
                            if isinstance(existing_value, dict) and isinstance(new_value, dict):
                                # Merge nested dictionaries (preserve existing, add new)
                                merged_shopify_data[key] = {**existing_value, **new_value}
                                print(f"🔄 Merged dict {key}: {len(existing_value)} → {len(merged_shopify_data[key])} fields")
                            elif isinstance(existing_value, list) and isinstance(new_value, list):
                                # Merge lists (avoid duplicates)
                                merged_shopify_data[key] = existing_value + [x for x in new_value if x not in existing_value]
                                print(f"🔄 Merged list {key}: {len(existing_value)} → {len(merged_shopify_data[key])} items")
                            elif existing_value != new_value:
                                # Different values - prefer newer but log the change
                                print(f"🔄 Updated {key}: {existing_value} → {new_value}")
                                merged_shopify_data[key] = new_value
                            # If values are identical, keep existing
                        else:
                            # New key, add it
                            merged_shopify_data[key] = new_value
                            print(f"➕ Added new field {key}: {new_value}")
                    
                    # Keep the most recent timestamp
                    if 'last_updated' in existing_shopify_data and 'last_updated' in shopify_data:
                        merged_shopify_data['last_updated'] = max(existing_shopify_data['last_updated'], shopify_data['last_updated'])
                    
                    update_expression_parts.append("#shopify_data = :shopify_data")
                    expression_attribute_names["#shopify_data"] = "shopify_data"
                    expression_attribute_values[":shopify_data"] = merged_shopify_data
                    print(f"🔄 Successfully merged shopify_data for {shopify_id}")
                else:
                    # Record doesn't exist, use new data
                    update_expression_parts.append("#shopify_data = :shopify_data")
                    expression_attribute_names["#shopify_data"] = "shopify_data"
                    expression_attribute_values[":shopify_data"] = shopify_data
                    print(f"📝 Using new shopify_data for {shopify_id} (no existing record)")
            except Exception as e:
                print(f"⚠️ Could not merge shopify_data, using new data: {e}")
                update_expression_parts.append("#shopify_data = :shopify_data")
                expression_attribute_names["#shopify_data"] = "shopify_data"
                expression_attribute_values[":shopify_data"] = shopify_data
        
        # Add commitment_form if provided
        if commitment_form:
            update_expression_parts.append("#commitment_form = :commitment_form")
            expression_attribute_names["#commitment_form"] = "commitment_form"
            expression_attribute_values[":commitment_form"] = commitment_form
        
        # Add surrender_text if provided
        if surrender_text is not None:
            update_expression_parts.append("#surrender_text = :surrender_text")
            expression_attribute_names["#surrender_text"] = "surrender_text"
            expression_attribute_values[":surrender_text"] = surrender_text
        
        # Add utm_data if provided
        if utm_data:
            update_expression_parts.append("#utm_data = :utm_data")
            expression_attribute_names["#utm_data"] = "utm_data"
            expression_attribute_values[":utm_data"] = utm_data
            
        # Add country_code if provided
        if country_code:
            update_expression_parts.append("#country_code = :country_code")
            expression_attribute_names["#country_code"] = "country_code"
            expression_attribute_values[":country_code"] = country_code
        
        # Add any additional kwargs
        for key, value in kwargs.items():
            if value is not None:
                safe_key = key.replace('-', '_').replace('.', '_')
                update_expression_parts.append(f"#{safe_key} = :{safe_key}")
                expression_attribute_names[f"#{safe_key}"] = key
                expression_attribute_values[f":{safe_key}"] = value
        
        # Build update expression
        update_expression = "SET " + ", ".join(update_expression_parts)
        
        # Perform the update - handle both new records and updates
        try:
            subscribers_table.update_item(
                Key={'shopify_id': shopify_id},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_attribute_values,
                ExpressionAttributeNames=expression_attribute_names
            )
            print(f"✅ Updated subscriber record for {shopify_id}")
            return True
        except dynamodb.meta.client.exceptions.ResourceNotFoundException:
            # Record doesn't exist - create it
            print(f"📝 Record doesn't exist for {shopify_id}, creating new record...")
            return create_subscriber_record(shopify_id, email, customer_id, event_type, shopify_data, commitment_form, surrender_text, utm_data, country_code, source, **kwargs)
        
        print(f"✅ Updated subscriber record for {shopify_id}")
        return True
        
    except Exception as e:
        print(f"❌ Failed to update subscriber record for {shopify_id}: {str(e)}")
        return False

def merge_subscriber_data(shopify_id: str, new_shopify_data: Dict[str, Any] = None, new_commitment_form: Dict[str, Any] = None, new_surrender_text: str = None, new_utm_data: Dict[str, Any] = None, new_country_code: str = None, event_type: str = None, status: str = None) -> bool:
    """Merge new data with existing subscriber data to handle race conditions"""
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
        subscribers_table = dynamodb.Table('tpl_subscribers')
        
        # Get existing data
        response = subscribers_table.get_item(Key={'shopify_id': shopify_id})
        existing_item = response.get('Item', {})
        
        # Merge shopify_data intelligently
        existing_shopify_data = existing_item.get('shopify_data', {})
        if new_shopify_data:
            # For each key in new data, merge based on type
            for key, new_value in new_shopify_data.items():
                if key in existing_shopify_data:
                    existing_value = existing_shopify_data[key]
                    
                    if isinstance(existing_value, dict) and isinstance(new_value, dict):
                        # Merge nested dictionaries (preserve existing, add new)
                        existing_shopify_data[key] = {**existing_value, **new_value}
                        print(f"🔄 Merged dict {key}: {len(existing_value)} → {len(existing_shopify_data[key])} fields")
                    elif isinstance(existing_value, list) and isinstance(new_value, list):
                        # Merge lists (avoid duplicates)
                        existing_shopify_data[key] = existing_value + [x for x in new_value if x not in existing_value]
                        print(f"🔄 Merged list {key}: {len(existing_value)} → {len(existing_shopify_data[key])} items")
                    elif key == 'last_updated':
                        # Keep the most recent timestamp
                        existing_shopify_data[key] = max(existing_value, new_value)
                        print(f"🔄 Updated timestamp {key}: {existing_value} → {existing_shopify_data[key]}")
                    elif existing_value != new_value:
                        # Different values - prefer newer but log the change
                        print(f"🔄 Updated {key}: {existing_value} → {new_value}")
                        existing_shopify_data[key] = new_value
                    # If values are identical, keep existing
                else:
                    # New key, add it
                    existing_shopify_data[key] = new_value
                    print(f"➕ Added new field {key}: {new_value}")
        
        # Merge commitment_form
        existing_commitment_form = existing_item.get('commitment_form', {})
        if new_commitment_form:
            existing_commitment_form.update(new_commitment_form)
        
        # Update surrender_text (keep new if provided)
        surrender_text = new_surrender_text if new_surrender_text is not None else existing_item.get('surrender_text', '')
        
        # Merge utm_data
        existing_utm_data = existing_item.get('utm_data', {})
        if new_utm_data:
            existing_utm_data.update(new_utm_data)
        
        # Update country_code (keep new if provided)
        country_code = new_country_code if new_country_code else existing_item.get('country_code', '')
        
        # Update the record with merged data
        update_expression_parts = [
            "#last_updated = :last_updated",
            "#shopify_data = :shopify_data",
            "#commitment_form = :commitment_form",
            "#surrender_text = :surrender_text",
            "#utm_data = :utm_data",
            "#country_code = :country_code"
        ]
        
        expression_attribute_names = {
            "#last_updated": "last_updated",
            "#shopify_data": "shopify_data",
            "#commitment_form": "commitment_form",
            "#surrender_text": "surrender_text",
            "#utm_data": "utm_data",
            "#country_code": "country_code"
        }
        
        expression_attribute_values = {
            ":last_updated": datetime.now().isoformat(),
            ":shopify_data": existing_shopify_data,
            ":commitment_form": existing_commitment_form,
            ":surrender_text": surrender_text,
            ":utm_data": existing_utm_data,
            ":country_code": country_code
        }
        
        # Add event_type and status if provided
        if event_type:
            update_expression_parts.append("#event_type = :event_type")
            expression_attribute_names["#event_type"] = "event_type"
            expression_attribute_values[":event_type"] = event_type
        
        if status:
            update_expression_parts.append("#status = :status")
            expression_attribute_names["#status"] = "status"
            expression_attribute_values[":status"] = status
        
        update_expression = "SET " + ", ".join(update_expression_parts)
        
        subscribers_table.update_item(
            Key={'shopify_id': shopify_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames=expression_attribute_names
        )
        
        print(f"✅ Merged subscriber data for {shopify_id}")
        return True
        
    except Exception as e:
        print(f"❌ Failed to merge subscriber data for {shopify_id}: {str(e)}")
        return False

def update_subscriber_record(email: str, event_type: str = None, status: str = None, shopify_data: Dict[str, Any] = None, source: str = "webhook", **kwargs) -> bool:
    """Legacy update function - now calls the safe version"""
    return update_subscriber_record_safe(email, None, event_type, status, shopify_data, None, None, None, None, source, **kwargs)


def handle_oauth_callback(event):
    """Handle Shopify OAuth callback and exchange code for access token"""
    print("🔄 Processing OAuth callback...")
    
    # Extract query parameters
    query_params = event.get("queryStringParameters") or {}
    code = query_params.get("code")
    shop = query_params.get("shop")
    
    if not code:
        print("❌ No authorization code in callback")
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "text/html"},
            "body": "<h1>Error</h1><p>No authorization code provided</p>"
        }
    
    if not shop:
        print("❌ No shop parameter in callback")
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "text/html"},
            "body": "<h1>Error</h1><p>No shop parameter provided</p>"
        }
    
    print(f"📋 OAuth Details: shop={shop}, code={code[:10]}...")
    
    # Exchange code for access token
    CLIENT_ID = "cb42141b2a2dff84ca2779da26291b5c"
    CLIENT_SECRET = "b039bfce077daf625c9b1791331357b1"
    
    token_url = f"https://{shop}/admin/oauth/access_token"
    payload = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "code": code
    }
    
    try:
        response = requests.post(token_url, json=payload, timeout=10)
        print(f"🔄 Token exchange response status: {response.status_code}")
        
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get("access_token")
            
            print(f"✅ SUCCESS! Access token obtained: {access_token}")
            print(f"🔗 Full token data: {token_data}")
            
            # Return success page with token for easy copying
            html_response = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>OAuth Success</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; }}
                    .success {{ color: green; }}
                    .token {{ background: #f5f5f5; padding: 10px; border-radius: 5px; margin: 10px 0; word-break: break-all; }}
                    .copy-btn {{ background: #007cba; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }}
                </style>
            </head>
            <body>
                <h1 class="success">✅ OAuth Success!</h1>
                <p>Your app has been successfully authorized.</p>
                <h2>Access Token:</h2>
                <div class="token" id="token">{access_token}</div>
                <button class="copy-btn" onclick="copyToken()">Copy Token</button>
                
                <h2>Next Steps:</h2>
                <ol>
                    <li>Copy the access token above</li>
                    <li>Use it with the create_shopify_webhooks.sh script</li>
                    <li>Set ADMIN_TOKEN="{access_token}" in your environment</li>
                </ol>
                
                <script>
                function copyToken() {{
                    navigator.clipboard.writeText('{access_token}').then(() => {{
                        alert('Token copied to clipboard!');
                    }});
                }}
                </script>
            </body>
            </html>
            """
            
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "text/html"},
                "body": html_response
            }
        else:
            error_text = response.text
            print(f"❌ Token exchange failed: {response.status_code} - {error_text}")
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "text/html"},
                "body": f"<h1>Token Exchange Failed</h1><p>Status: {response.status_code}</p><p>Error: {error_text}</p>"
            }
            
    except Exception as e:
        print(f"❌ Exception during token exchange: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "text/html"},
            "body": f"<h1>Server Error</h1><p>Exception: {str(e)}</p>"
        }

# ---------- SCREENTIME DASHBOARD API ----------
def get_shopify_admin_token() -> str:
    """Get Shopify Admin API access token from environment"""
    return os.environ.get("SHOPIFY_ACCESS_TOKEN", "")

def get_customer_subscription_status(customer_id: str) -> Dict[str, Any]:
    """Get customer subscription status from metafield"""
    try:
        admin_token = get_shopify_admin_token()
        if not admin_token:
            print("❌ No Shopify admin token available")
            return {"has_active_subscription": False, "error": "no_token"}
        
        # Extract numeric ID from GID
        numeric_id = customer_id.split("/")[-1] if "/" in customer_id else customer_id
        
        # Get customer metafield
        response = requests.get(
            f"https://{SHOP_DOMAIN}/admin/api/2025-07/customers/{numeric_id}/metafields.json?namespace=stj&key=subscription_status_active",
            headers={
                "X-Shopify-Access-Token": admin_token
            },
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            metafields = data.get("metafields", [])
            
            if metafields:
                subscription_status = metafields[0].get("value", "false")
                has_active_subscription = subscription_status.lower() == "true"
                print(f"✅ Customer {customer_id} subscription status: {has_active_subscription}")
                return {
                    "has_active_subscription": has_active_subscription,
                    "subscription_status": subscription_status
                }
            else:
                print(f"⚠️ No subscription metafield found for customer {customer_id}")
                return {"has_active_subscription": False, "subscription_status": "false"}
        else:
            print(f"❌ Failed to get customer metafield: {response.status_code}")
            return {"has_active_subscription": False, "error": f"api_error_{response.status_code}"}
            
    except Exception as e:
        print(f"❌ Error getting customer metafield: {str(e)}")
        return {"has_active_subscription": False, "error": str(e)}

def add_customer_tag(customer_id: str, tag: str) -> bool:
    """Add tag to customer using GraphQL Admin API"""
    admin_token = get_shopify_admin_token()
    if not admin_token:
        print("❌ Admin token not configured for adding customer tags")
        return False
    
    url = f"https://{SHOP_DOMAIN}/admin/api/2024-10/graphql.json"
    headers = {
        "X-Shopify-Access-Token": admin_token,
        "Content-Type": "application/json"
    }
    
    # GraphQL mutation to add tag to customer
    mutation = """
    mutation customerUpdate($input: CustomerInput!) {
      customerUpdate(input: $input) {
        customer {
          id
          tags
        }
        userErrors {
          field
          message
        }
      }
    }
    """
    
    variables = {
        "input": {
            "id": customer_id,
            "tags": [tag]
        }
    }
    
    payload = {"query": mutation, "variables": variables}
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        user_errors = data.get('data', {}).get('customerUpdate', {}).get('userErrors', [])
        if user_errors:
            print(f"❌ Error adding tag '{tag}' to customer {customer_id}: {user_errors}")
            return False
        
        print(f"✅ Successfully added tag '{tag}' to customer {customer_id}")
        return True
        
    except Exception as e:
        print(f"❌ Exception adding tag '{tag}' to customer {customer_id}: {str(e)}")
        return False

def check_customer_subscription_status(customer_email: str) -> Dict[str, Any]:
    """Check if customer has subscription_screentime tag using GraphQL"""
    admin_token = get_shopify_admin_token()
    if not admin_token:
        return {"error": "Admin token not configured"}
    
    url = f"https://{SHOP_DOMAIN}/admin/api/2024-10/graphql.json"
    headers = {
        "X-Shopify-Access-Token": admin_token,
        "Content-Type": "application/json"
    }
    
    query = """
    query GetCustomerByEmail($email: String!) {
      customers(first: 1, query: $email) {
        edges {
          node {
            id
            email
            firstName
            lastName
            tags
            subscriptionContracts(first: 10) {
              edges {
                node {
                  id
                  status
                  nextBillingDate
                }
              }
            }
          }
        }
      }
    }
    """
    
    variables = {"email": f"email:{customer_email}"}
    payload = {"query": query, "variables": variables}
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        customers = data.get('data', {}).get('customers', {}).get('edges', [])
        if not customers:
            return {"error": "Customer not found"}
        
        customer = customers[0]['node']
        tags_string = customer.get('tags', '')
        tags = [tag.strip() for tag in tags_string.split(',') if tag.strip()]
        
        subscription_contracts = customer.get('subscriptionContracts', {}).get('edges', [])
        active_subscriptions = [
            contract['node'] for contract in subscription_contracts
            if contract['node']['status'] in ['active', 'trialing']
        ]
        
        return {
            "success": True,
            "customer": {
                "id": customer['id'],
                "email": customer['email'],
                "firstName": customer.get('firstName'),
                "lastName": customer.get('lastName'),
                "tags": tags,
                "is_subscriber": 'subscription_screentime' in tags or 'subscriber' in tags,
                "has_active_subscriptions": len(active_subscriptions) > 0,
                "subscription_count": len(subscription_contracts),
                "active_subscription_count": len(active_subscriptions)
            }
        }
        
    except Exception as e:
        print(f"Error checking customer status: {str(e)}")
        return {"error": f"API request failed: {str(e)}"}

def get_dashboard_stats(customer_email: str) -> Dict[str, Any]:
    """Get screentime dashboard stats for customer"""
    # This would typically fetch from your screentime tracking database
    # For now, return mock data
    return {
        "success": True,
        "stats": {
            "total_screen_time": "4h 23m",
            "goal_progress": "73%",
            "weekly_average": "5h 12m",
            "streak_days": "7",
            "daily_goal": "6h",
            "apps_used_today": 12,
            "most_used_app": "Instagram",
            "most_used_time": "1h 23m"
        }
    }

def get_time_limits(customer_email: str) -> Dict[str, Any]:
    """Get customer's time limits"""
    # This would fetch from your database
    # For now, return mock data
    return {
        "success": True,
        "time_limits": [
            {
                "app_name": "Instagram",
                "daily_limit": 30,
                "used_today": 24,
                "limit_type": "soft"
            },
            {
                "app_name": "TikTok",
                "daily_limit": 45,
                "used_today": 27,
                "limit_type": "hard"
            }
        ]
    }

def get_weekly_report(customer_email: str, week: str = "current") -> Dict[str, Any]:
    """Get weekly screentime report"""
    # This would fetch from your database
    # For now, return mock data
    return {
        "success": True,
        "weekly_report": {
            "total_screen_time": "36h 24m",
            "daily_average": "5h 12m",
            "goal_achievement": "4/7 days",
            "most_used_day": "Wednesday",
            "least_used_day": "Sunday",
            "apps_breakdown": [
                {"app": "Instagram", "time": "8h 12m"},
                {"app": "TikTok", "time": "6h 45m"},
                {"app": "WhatsApp", "time": "4h 30m"}
            ]
        }
    }

def add_time_limit(customer_email: str, app_name: str, daily_limit: int, limit_type: str) -> Dict[str, Any]:
    """Add a new time limit for customer"""
    # This would save to your database
    # For now, just return success
    return {
        "success": True,
        "message": f"Time limit added for {app_name}: {daily_limit} minutes daily ({limit_type} limit)"
    }

def set_daily_goal(customer_email: str, goal_hours: int) -> Dict[str, Any]:
    """Set daily screentime goal for customer"""
    # This would save to your database
    return {
        "success": True,
        "message": f"Daily goal set to {goal_hours} hours"
    }

def save_customer_whatsapp(customer_email: str, whatsapp_number: str) -> Dict[str, Any]:
    """Save WhatsApp number to customer metafield mk.profile.whatsapp"""
    try:
        shop_domain = "xpvznx-9w.myshopify.com"
        access_token = get_shopify_admin_token()
        
        if not access_token:
            return {"error": "Unable to access Shopify Admin API"}
        
        # First, find the customer by email
        query = """
        query GetCustomerByEmail($email: String!) {
          customers(first: 1, query: $email) {
            edges {
              node {
                id
                email
                metafields(namespace: "mk.profile", first: 10) {
                  edges {
                    node {
                      id
                      key
                      value
                    }
                  }
                }
              }
            }
          }
        }
        """
        
        variables = {"email": customer_email}
        
        response = requests.post(
            f"https://{shop_domain}/admin/api/2024-07/graphql.json",
            headers={
                "X-Shopify-Access-Token": access_token,
                "Content-Type": "application/json"
            },
            json={"query": query, "variables": variables}
        )
        
        if response.status_code != 200:
            return {"error": f"Failed to find customer: {response.status_code}"}
        
        data = response.json()
        customers = data.get("data", {}).get("customers", {}).get("edges", [])
        
        if not customers:
            return {"error": "Customer not found"}
        
        customer_id = customers[0]["node"]["id"]
        
        # Now save the WhatsApp number as a metafield
        mutation = """
        mutation CreateCustomerMetafield($input: CustomerInput!) {
          customerUpdate(input: $input) {
            customer {
              id
              metafields(namespace: "mk.profile", first: 10) {
                edges {
                  node {
                    key
                    value
                  }
                }
              }
            }
            userErrors {
              field
              message
            }
          }
        }
        """
        
        mutation_variables = {
            "input": {
                "id": customer_id,
                "metafields": [
                    {
                        "namespace": "mk.profile",
                        "key": "whatsapp",
                        "value": whatsapp_number,
                        "type": "single_line_text_field"
                    }
                ]
            }
        }
        
        mutation_response = requests.post(
            f"https://{shop_domain}/admin/api/2024-07/graphql.json",
            headers={
                "X-Shopify-Access-Token": access_token,
                "Content-Type": "application/json"
            },
            json={"query": mutation, "variables": mutation_variables}
        )
        
        if mutation_response.status_code != 200:
            return {"error": f"Failed to save WhatsApp number: {mutation_response.status_code}"}
        
        mutation_data = mutation_response.json()
        errors = mutation_data.get("data", {}).get("customerUpdate", {}).get("userErrors", [])
        
        if errors:
            return {"error": f"GraphQL errors: {errors}"}
        
        return {
            "success": True,
            "message": "WhatsApp number saved successfully",
            "customer_id": customer_id
        }
        
    except Exception as e:
        return {"error": f"Exception saving WhatsApp number: {str(e)}"}

def get_customer_devices(customer_email: str) -> Dict[str, Any]:
    """Get customer's registered devices"""
    try:
        # Get from DynamoDB
        dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
        subscribers_table = dynamodb.Table('tpl_subscribers')
        
        response = subscribers_table.get_item(Key={'email': customer_email})
        item = response.get('Item', {})
        
        devices = item.get('devices', [])
        
        return {
            "success": True,
            "devices": devices,
            "device_count": len(devices),
            "max_devices": 3
        }
    except Exception as e:
        print(f"❌ Error getting customer devices: {str(e)}")
        return {"success": False, "error": str(e)}

def add_customer_device(customer_email: str, device_name: str, device_type: str, device_id: str) -> Dict[str, Any]:
    """Add a new device for customer"""
    try:
        dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
        subscribers_table = dynamodb.Table('tpl_subscribers')
        
        # Get current devices
        response = subscribers_table.get_item(Key={'email': customer_email})
        item = response.get('Item', {})
        current_devices = item.get('devices', [])
        
        # Check if device limit reached
        if len(current_devices) >= 3:
            return {"success": False, "error": "Maximum 3 devices allowed"}
        
        # Check if device already exists
        for device in current_devices:
            if device.get('device_id') == device_id:
                return {"success": False, "error": "Device already registered"}
        
        # Add new device
        new_device = {
            "device_id": device_id,
            "device_name": device_name,
            "device_type": device_type,
            "status": "locked",
            "added_at": datetime.now().isoformat(),
            "last_unlock": None
        }
        
        current_devices.append(new_device)
        
        # Update DynamoDB
        subscribers_table.update_item(
            Key={'email': customer_email},
            UpdateExpression="SET devices = :devices, last_updated = :last_updated",
            ExpressionAttributeValues={
                ':devices': current_devices,
                ':last_updated': datetime.now().isoformat()
            }
        )
        
        return {
            "success": True,
            "device": new_device,
            "total_devices": len(current_devices)
        }
    except Exception as e:
        print(f"❌ Error adding customer device: {str(e)}")
        return {"success": False, "error": str(e)}

def unlock_customer_device(customer_email: str, device_id: str) -> Dict[str, Any]:
    """Unlock a customer device"""
    try:
        dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
        subscribers_table = dynamodb.Table('tpl_subscribers')
        
        # Get current devices
        response = subscribers_table.get_item(Key={'email': customer_email})
        item = response.get('Item', {})
        current_devices = item.get('devices', [])
        
        # Find and update device
        device_found = False
        for device in current_devices:
            if device.get('device_id') == device_id:
                device['status'] = 'unlocked'
                device['last_unlock'] = datetime.now().isoformat()
                device_found = True
                break
        
        if not device_found:
            return {"success": False, "error": "Device not found"}
        
        # Update DynamoDB
        subscribers_table.update_item(
            Key={'email': customer_email},
            UpdateExpression="SET devices = :devices, last_updated = :last_updated",
            ExpressionAttributeValues={
                ':devices': current_devices,
                ':last_updated': datetime.now().isoformat()
            }
        )
        
        return {
            "success": True,
            "message": "Device unlocked successfully",
            "device_id": device_id
        }
    except Exception as e:
        print(f"❌ Error unlocking customer device: {str(e)}")
        return {"success": False, "error": str(e)}

def get_customer_onboarding_status(customer_email: str) -> Dict[str, Any]:
    """Check if customer has completed WhatsApp onboarding"""
    try:
        shop_domain = "xpvznx-9w.myshopify.com"
        access_token = get_shopify_admin_token()
        
        if not access_token:
            return {"error": "Unable to access Shopify Admin API"}
        
        # Find the customer and check their metafields
        query = """
        query GetCustomerByEmail($email: String!) {
          customers(first: 1, query: $email) {
            edges {
              node {
                id
                email
                metafields(namespace: "mk.profile", first: 10) {
                  edges {
                    node {
                      key
                      value
                    }
                  }
                }
              }
            }
          }
        }
        """
        
        variables = {"email": customer_email}
        
        response = requests.post(
            f"https://{shop_domain}/admin/api/2024-07/graphql.json",
            headers={
                "X-Shopify-Access-Token": access_token,
                "Content-Type": "application/json"
            },
            json={"query": query, "variables": variables}
        )
        
        if response.status_code != 200:
            return {"error": f"Failed to find customer: {response.status_code}"}
        
        data = response.json()
        customers = data.get("data", {}).get("customers", {}).get("edges", [])
        
        if not customers:
            return {"error": "Customer not found"}
        
        metafields = customers[0]["node"]["metafields"]["edges"]
        whatsapp_number = None
        
        for metafield in metafields:
            if metafield["node"]["key"] == "whatsapp":
                whatsapp_number = metafield["node"]["value"]
                break
        
        return {
            "success": True,
            "is_onboarded": whatsapp_number is not None,
            "whatsapp_number": whatsapp_number if whatsapp_number else ""
        }
        
    except Exception as e:
        return {"error": f"Exception checking onboarding status: {str(e)}"}

def handle_dashboard_api(path: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """Handle screentime dashboard API calls"""
    action = body.get("action", "")
    customer_email = body.get("customer_email", "")
    customer_id = body.get("customer_id", "")
    
    if not customer_email:
        return {"error": "customer_email is required"}
    
    if action == "check_subscription":
        return check_customer_subscription_status(customer_email)
    elif action == "get_subscription_status":
        if not customer_id:
            return {"error": "customer_id is required"}
        return get_customer_subscription_status(customer_id)
    elif action == "get_devices":
        return get_customer_devices(customer_email)
    elif action == "add_device":
        device_name = body.get("device_name", "")
        device_type = body.get("device_type", "")
        device_id = body.get("device_id", "")
        if not all([device_name, device_type, device_id]):
            return {"error": "device_name, device_type, and device_id are required"}
        return add_customer_device(customer_email, device_name, device_type, device_id)
    elif action == "unlock_device":
        device_id = body.get("device_id", "")
        if not device_id:
            return {"error": "device_id is required"}
        return unlock_customer_device(customer_email, device_id)
    elif action == "get_stats":
        return get_dashboard_stats(customer_email)
    elif action == "get_time_limits":
        return get_time_limits(customer_email)
    elif action == "get_weekly_report":
        week = body.get("week", "current")
        return get_weekly_report(customer_email, week)
    elif action == "add_time_limit":
        app_name = body.get("app_name", "")
        daily_limit = body.get("daily_limit", 0)
        limit_type = body.get("limit_type", "soft")
        if not app_name or not daily_limit:
            return {"error": "app_name and daily_limit are required"}
        return add_time_limit(customer_email, app_name, daily_limit, limit_type)
    elif action == "set_daily_goal":
        goal_hours = body.get("goal_hours", 0)
        if not goal_hours:
            return {"error": "goal_hours is required"}
        return set_daily_goal(customer_email, goal_hours)
    elif action == "save_whatsapp":
        whatsapp_number = body.get("whatsapp_number", "")
        if not whatsapp_number:
            return {"error": "whatsapp_number is required"}
        return save_customer_whatsapp(customer_email, whatsapp_number)
    elif action == "get_onboarding_status":
        return get_customer_onboarding_status(customer_email)
    else:
        return {"error": f"Unknown action: {action}"}

# ---------- SUBSCRIPTION CHECK ----------
def handle_subscription_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Handle subscription status check requests from dashboard."""
    
    customer_id = str(payload.get("customer_id", "")).strip()
    if not customer_id:
        return {"ok": False, "error": "customer_id is required"}
    
    if not SUBSCRIPTION_CHECK_AVAILABLE:
        return {"ok": False, "error": "subscription_check_unavailable"}
    
    try:
        # Check subscription status in DynamoDB
        status_result = check_subscription_status(customer_id)
        
        return {
            "ok": True,
            "customer_id": customer_id,
            "is_subscribed": status_result.get("is_subscribed", False),
            "status": status_result.get("status", "unknown"),
            "message": status_result.get("message", ""),
            "details": {
                "created_at": status_result.get("created_at", ""),
                "utm_source": status_result.get("utm_source", "")
            }
        }
        
    except Exception as e:
        print(f"❌ Error in handle_subscription_check: {str(e)}")
        return {
            "ok": False,
            "error": f"subscription_check_failed: {str(e)}"
        }

# ---------- LAMBDA ENTRY ----------
def handler(event, context):
    # Debug: Log that we've entered the handler
    print(f"🚀 LAMBDA HANDLER STARTED")
    print(f"🔍 Event: {json.dumps(event, indent=2)}")
    print(f"🔍 Context: {context}")
    
    # Preflight CORS
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if method == "OPTIONS":
        return json_resp({"ok": True})

    # Get the path to determine which function to call
    path = event.get("requestContext", {}).get("http", {}).get("path", "")
    
    # OAuth installation endpoint - handles GET requests
    if path.endswith("/auth/shopify") and method == "GET":
        return handle_oauth_install(event)
    
    # OAuth callback endpoint - handles GET requests
    if path.endswith("/auth/callback") and method == "GET":
        return handle_oauth_callback(event)
    
    # Alternative OAuth callback path
    if path.endswith("/auth/shopify/callback") and method == "GET":
        return handle_oauth_callback(event)

    # Handle app proxy page requests (GET requests) - do this BEFORE signature verification
    if method == "GET" and ("/stj/" in path or "/app-proxy/stj/" in path):
        print(f"🌐 DEBUG: App proxy page request detected: {path}")
        print(f"🔍 DEBUG: Query string: {event.get('rawQueryString', '')}")
        
        # Temporarily skip HMAC verification for debugging
        # if not verify_app_proxy_signature(event):
        #     return json_resp({"error": "invalid signature"}, 401)
        
        return handle_app_proxy_page(event)
    
    # Handle customer dashboard requests (GET requests to base path)
    if method == "GET" and (path == "" or path == "/" or path.endswith("/dashboard")):
        print(f"🎯 DEBUG: Customer dashboard request detected: {path}")
        print(f"🔍 DEBUG: Query string: {event.get('rawQueryString', '')}")
        
        # Check for customer authentication
        query_params = event.get("queryStringParameters") or {}
        customer_email = query_params.get("email")
        customer_phone = query_params.get("phone")
        token = query_params.get("token")
        auto_login = query_params.get("auto_login")
        
        # If customer is provided, check subscription status
        if customer_email or customer_phone or token:
            # If auto_login is true, automatically check subscription and show dashboard
            if auto_login == "true" and customer_email:
                return handle_auto_login(event, customer_email)
            return handle_customer_dashboard(event)
        
        # If no authentication, show login page
        print(f"🔐 No customer authentication, showing login page")
        return handle_customer_login(event)
    
    # Verify App Proxy signature for other requests (skip for OAuth callbacks)
    if not verify_app_proxy_signature(event):
        return json_resp({"error": "invalid signature"}, 401)

    if method != "POST":
        return json_resp({"error": "method not allowed"}, 405)
    
    # Debug logging - remove after testing
    print(f"DEBUG: Received path: {path}")
    print(f"DEBUG: Full event: {json.dumps(event, default=str)}")
    
    body = parse_body(event)
    
    try:
        if path.endswith("/send_welcome"):
            result = send_welcome_message(body)
        elif path.endswith("/send_auth"):
            result = send_auth_code(body)
        elif path.endswith("/create_webapp_checkout"):
            result = create_webapp_checkout(body)
        elif path.endswith("/evaluate_only"):
            result = evaluate_only(body)
        elif path.endswith("/start_auth"):
            result = start_auth(body)
        elif path.endswith("/verify_and_checkout"):
            result = verify_and_checkout(body)
        elif path.endswith("/evaluate_and_start"):
            result = evaluate_and_start(body)
        elif path.endswith("/subscription-created"):
            # Use new standardized webhook processing
            result = handle_standardized_webhook(body, "/subscription-created")
        elif path.endswith("/subscription-updated"):
            # Extract subscription data from nested structure for Shopify subscription webhooks
            webhook_data = body
            if body.get("subscription_contract"):
                webhook_data = body.get("subscription_contract", {})
                print(f"📦 DEBUG: Extracted subscription data from Shopify webhook: {webhook_data.get('id')}")
            result = handle_shopify_webhook(webhook_data, "subscription_contracts/update")
        elif path.endswith("/subscription-billing-success"):
            # Extract billing data from nested structure for Shopify billing webhooks
            webhook_data = body
            if body.get("subscription_billing_attempt"):
                webhook_data = body.get("subscription_billing_attempt", {})
                print(f"📦 DEBUG: Extracted billing data from Shopify webhook: {webhook_data.get('id')}")
            result = handle_shopify_webhook(webhook_data, "subscription_billing_attempts/success")
        elif path.endswith("/subscription-cancelled"):
            # Use new standardized webhook processing
            result = handle_standardized_webhook(body, "/subscription-cancelled")
        elif path.endswith("/subscription-billing-failure"):
            # Extract billing data from nested structure for Shopify billing webhooks
            webhook_data = body
            if body.get("subscription_billing_attempt"):
                webhook_data = body.get("subscription_billing_attempt", {})
                print(f"📦 DEBUG: Extracted billing data from Shopify webhook: {webhook_data.get('id')}")
            result = handle_shopify_webhook(webhook_data, "subscription_billing_attempts/failure")
        elif path.endswith("/check-subscription"):
            result = handle_subscription_check(body)
        elif path.endswith("/check-username"):
            result = handle_username_check(body)
        elif path.endswith("/register-username"):
            result = handle_username_registration(body)
        elif path.endswith("/get-username"):
            result = handle_get_username(body)
        elif path.endswith("/send-whatsapp-code"):
            result = handle_send_whatsapp_code(body)
        elif path.endswith("/verify-whatsapp-code"):
            result = handle_verify_whatsapp_code(body)
        elif path.endswith("/orders-paid"):
            # Use new standardized webhook processing
            result = handle_standardized_webhook(body, "/orders-paid")
        elif path.endswith("/webhooks"):
            # New unified webhook endpoint - support both HMAC and Bearer token auth
            # Try HMAC first (Shopify), then Bearer token (Flow)
            auth_valid = False
            
            # Check for HMAC (Shopify webhooks)
            if event.get("headers", {}).get("x-shopify-hmac-sha256") or event.get("headers", {}).get("X-Shopify-Hmac-SHA256"):
                auth_valid = verify_shopify_webhook_hmac(event)
                print("🔐 DEBUG: Using HMAC authentication")
            
            # Check for Bearer token (Flow webhooks)
            elif event.get("headers", {}).get("authorization") or event.get("headers", {}).get("Authorization"):
                auth_valid = verify_bearer_token(event)
                print("🔐 DEBUG: Using Bearer token authentication")
            
            if not auth_valid:
                return json_resp({"ok": False, "error": "authentication_failed"}, 401)
            
            # Handle Shopify Flow webhook structure - the actual data is in body.body as a JSON string
            webhook_data = body
            topic = None
            
            # Check if this is a Shopify Flow webhook with nested body structure
            if body.get("body") and isinstance(body.get("body"), str):
                try:
                    # Parse the nested JSON body
                    nested_body = json.loads(body.get("body"))
                    print(f"📦 DEBUG: Parsed nested body from Shopify Flow webhook")
                    
                    # Determine topic based on the nested data structure
                    if nested_body.get("order"):
                        topic = "orders/paid"
                        webhook_data = nested_body.get("order", {})
                        print(f"📦 DEBUG: Extracted order data from Flow webhook: {webhook_data.get('id')}")
                    elif nested_body.get("subscription_contract"):
                        if nested_body.get("subscription_contract", {}).get("status") == "CANCELLED":
                            topic = "subscription_contracts/cancel"
                        else:
                            topic = "subscription_contracts/create"
                        webhook_data = nested_body.get("subscription_contract", {})
                        print(f"📦 DEBUG: Extracted subscription data from Flow webhook: {webhook_data.get('id')}")
                    elif nested_body.get("subscription_billing_attempt"):
                        if "success" in nested_body.get("subscription_billing_attempt", {}).get("status", ""):
                            topic = "subscription_billing_attempts/success"
                        else:
                            topic = "subscription_billing_attempts/failure"
                        webhook_data = nested_body.get("subscription_billing_attempt", {})
                        print(f"📦 DEBUG: Extracted billing data from Flow webhook: {webhook_data.get('id')}")
                    
                    # If we still don't have a topic, try to determine from headers
                    if not topic:
                        topic = event.get("headers", {}).get("x-shopify-topic") or event.get("headers", {}).get("X-Shopify-Topic")
                        if not topic:
                            # Default to orders/paid if we have order data
                            if nested_body.get("order"):
                                topic = "orders/paid"
                                webhook_data = nested_body.get("order", {})
                            else:
                                return json_resp({"error": "Cannot determine topic from webhook data"}, 400)
                    
                except json.JSONDecodeError as e:
                    print(f"❌ DEBUG: Failed to parse nested body JSON: {e}")
                    return json_resp({"error": "Invalid JSON in nested body"}, 400)
            else:
                # Fallback to original logic for direct webhooks
                topic = event.get("headers", {}).get("x-shopify-topic") or event.get("headers", {}).get("X-Shopify-Topic")
                if not topic:
                    # Try to get topic from body for Flow webhooks
                    topic = body.get("topic") or body.get("event_type")
                    if not topic:
                        # For Flow webhooks, determine topic from the data structure
                        if body.get("order"):
                            topic = "orders/paid"
                        elif body.get("status") == "CANCELLED" or body.get("cancelled_at"):
                            topic = "subscription_contracts/cancel"
                        elif body.get("status") == "ACTIVE" and body.get("created_at"):
                            topic = "subscription_contracts/create"
                        elif body.get("status") == "ACTIVE" and body.get("updated_at"):
                            topic = "subscription_contracts/update"
                        else:
                            return json_resp({"error": "Cannot determine topic from webhook data"}, 400)
                
                # Extract the actual data based on topic
                if topic == "orders/paid" and body.get("order"):
                    # For order webhooks from Flow, extract the order data
                    webhook_data = body.get("order", {})
                    print(f"📦 DEBUG: Extracted order data from Flow webhook: {webhook_data.get('id')}")
                elif topic.startswith("subscription_contracts/") and body.get("subscription_contract"):
                    # For subscription webhooks from Flow, extract the subscription data
                    webhook_data = body.get("subscription_contract", {})
                    print(f"📦 DEBUG: Extracted subscription data from Flow webhook: {webhook_data.get('id')}")
            
            result = handle_shopify_webhook(webhook_data, topic)
        elif path.endswith("/dashboard-api"):
            result = handle_dashboard_api(path, body)
        elif path.endswith("/") or path == "" or path.endswith("/mk_shopify_web_app"):
            # Handle Flow webhooks at base endpoint (no authentication required)
            print("🔐 DEBUG: Processing request at base endpoint")
            
            # Check if this is a Flow webhook
            if body.get("source") == "shopify_flow" and body.get("event") == "subscription_contract_event":
                print("📨 DEBUG: Processing Flow subscription contract event")
                
                # Extract subscription data from Flow format
                contract = body.get("contract", {})
                customer = body.get("customer", {})
                
                # Convert Flow format to standard webhook format
                webhook_data = {
                    "id": contract.get("id", "").split("/")[-1] if contract.get("id") else "",  # Extract ID from GID
                    "admin_graphql_api_id": contract.get("id"),
                    "status": contract.get("status"),
                    "created_at": contract.get("created_at"),
                    "updated_at": contract.get("updated_at"),
                    "next_billing_date": contract.get("next_billing_date"),
                    "billing_policy": contract.get("billing_policy"),
                    "delivery_policy": contract.get("delivery_policy"),
                    "customer": {
                        "id": customer.get("id", "").split("/")[-1] if customer.get("id") else "",  # Extract ID from GID
                        "email": customer.get("email"),
                        "first_name": customer.get("first_name"),
                        "last_name": customer.get("last_name")
                    }
                }
                
                # Determine topic based on contract status
                topic = "subscription_contracts/create" if contract.get("status") == "ACTIVE" else "subscription_contracts/cancel"
                
                result = handle_shopify_webhook(webhook_data, topic)
            else:
                # Default to evaluate_and_start for other requests
                result = evaluate_and_start(body)
        else:
            # Default to evaluate_and_start for backward compatibility
            result = evaluate_and_start(body)
        
        return json_resp(result, 200 if result.get("ok") else 400)
    except Exception as e:
        print(f"Lambda handler error: {str(e)}")
        import traceback
        traceback.print_exc()
        return json_resp({"ok": False, "error": "internal error", "debug": str(e)}, 500)


def handle_username_check(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Check if a username is available."""
    username = payload.get("username", "").strip().lower()
    
    if not username:
        return {"ok": False, "error": "username is required"}
    
    if len(username) < 3:
        return {"ok": False, "error": "username must be at least 3 characters"}
    
    if len(username) > 20:
        return {"ok": False, "error": "username must be 20 characters or less"}
    
    # Check for valid characters (alphanumeric and underscore only)
    import re
    if not re.match("^[a-zA-Z0-9_]+$", username):
        return {"ok": False, "error": "username can only contain letters, numbers, and underscores"}
    
    try:
        # Check if username exists in DynamoDB stj_authentication table
        response = dynamodb.get_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"username_{username}"},
                'sk': {'S': 'profile'}
            }
        )
        
        if 'Item' in response:
            return {
                "ok": True,
                "available": False,
                "message": "Username is already taken"
            }
        else:
            return {
                "ok": True,
                "available": True,
                "message": "Username is available"
            }
            
    except Exception as e:
        print(f"❌ Error checking username: {str(e)}")
        return {"ok": False, "error": f"Failed to check username: {str(e)}"}


def handle_username_registration(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Register a new username for a customer."""
    username = payload.get("username", "").strip().lower()
    customer_id = str(payload.get("customer_id", "")).strip()
    
    if not username:
        return {"ok": False, "error": "username is required"}
    
    if not customer_id:
        return {"ok": False, "error": "customer_id is required"}
    
    # Validate username format
    if len(username) < 3:
        return {"ok": False, "error": "username must be at least 3 characters"}
    
    if len(username) > 20:
        return {"ok": False, "error": "username must be 20 characters or less"}
    
    import re
    if not re.match("^[a-zA-Z0-9_]+$", username):
        return {"ok": False, "error": "username can only contain letters, numbers, and underscores"}
    
    try:
        # Check if customer already has a username
        customer_response = dynamodb.get_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"customer_{customer_id}"},
                'sk': {'S': 'username'}
            }
        )
        
        if 'Item' in customer_response:
            return {
                "ok": False,
                "error": "Customer already has a registered username"
            }
        
        # Check if username is available
        username_response = dynamodb.get_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"username_{username}"},
                'sk': {'S': 'profile'}
            }
        )
        
        if 'Item' in username_response:
            return {
                "ok": False,
                "error": "Username is already taken"
            }
        
        # Register the username
        from datetime import datetime
        timestamp = datetime.utcnow().isoformat()
        
        # Create username record
        dynamodb.put_item(
            TableName='stj_authentication',
            Item={
                'pk': {'S': f"username_{username}"},
                'sk': {'S': 'profile'},
                'username': {'S': username},
                'customer_id': {'S': customer_id},
                'created_at': {'S': timestamp},
                'status': {'S': 'active'},
                'type': {'S': 'username_profile'}
            }
        )
        
        # Create reverse lookup (customer_id -> username)
        dynamodb.put_item(
            TableName='stj_authentication',
            Item={
                'pk': {'S': f"customer_{customer_id}"},
                'sk': {'S': 'username'},
                'username': {'S': username},
                'customer_id': {'S': customer_id},
                'created_at': {'S': timestamp},
                'status': {'S': 'active'},
                'type': {'S': 'customer_username_lookup'}
            }
        )
        
        return {
            "ok": True,
            "username": username,
            "customer_id": customer_id,
            "message": "Username registered successfully"
        }
        
    except Exception as e:
        print(f"❌ Error registering username: {str(e)}")
        return {"ok": False, "error": f"Failed to register username: {str(e)}"}


def handle_get_username(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get username for a customer."""
    customer_id = str(payload.get("customer_id", "")).strip()
    
    if not customer_id:
        return {"ok": False, "error": "customer_id is required"}
    
    return get_customer_username(customer_id)


def get_customer_username(customer_id: str) -> Dict[str, Any]:
    """Get the username for a customer."""
    try:
        response = dynamodb.get_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"customer_{customer_id}"},
                'sk': {'S': 'username'}
            }
        )
        
        if 'Item' in response:
            return {
                "ok": True,
                "username": response['Item']['username']['S'],
                "has_username": True
            }
        else:
            return {
                "ok": True,
                "has_username": False,
                "message": "No username registered"
            }
            
    except Exception as e:
        print(f"❌ Error getting customer username: {str(e)}")
        return {"ok": False, "error": f"Failed to get username: {str(e)}"}


def get_username_customer(username: str) -> Dict[str, Any]:
    """Get the customer ID for a username."""
    try:
        response = dynamodb.get_item(
            TableName='stj_usernames',
            Key={'username': {'S': username.lower()}}
        )
        
        if 'Item' in response:
            return {
                "ok": True,
                "customer_id": response['Item']['customer_id']['S'],
                "username": username.lower()
            }
        else:
            return {
                "ok": False,
                "error": "Username not found"
            }
            
    except Exception as e:
        print(f"❌ Error getting username customer: {str(e)}")
        return {"ok": False, "error": f"Failed to get customer: {str(e)}"}


# DynamoDB table creation script (run once)
def create_username_table():
    """Create the stj_usernames DynamoDB table."""
    try:
        dynamodb.create_table(
            TableName='stj_usernames',
            KeySchema=[
                {
                    'AttributeName': 'username',
                    'KeyType': 'HASH'
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'username',
                    'AttributeType': 'S'
                }
            ],
            BillingMode='PAY_PER_REQUEST'
        )
        print("✅ Username table created successfully")
    except Exception as e:
        print(f"❌ Error creating username table: {str(e)}")


def handle_send_whatsapp_code(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send WhatsApp verification code via WATI API."""
    phone_number = payload.get("phone_number", "").strip()
    customer_id = str(payload.get("customer_id", "")).strip()
    
    if not phone_number:
        return {"ok": False, "error": "phone_number is required"}
    
    if not customer_id:
        return {"ok": False, "error": "customer_id is required"}
    
    # Clean phone number (remove spaces, dashes, etc.)
    clean_phone = ''.join(filter(str.isdigit, phone_number.replace('+', '')))
    if not clean_phone.startswith('+'):
        clean_phone = '+' + clean_phone
    
    try:
        # Generate 6-digit verification code
        import random
        verification_code = f"{random.randint(100000, 999999)}"
        
        # Store verification code in DynamoDB temporarily
        from datetime import datetime, timedelta
        expiry_time = datetime.utcnow() + timedelta(minutes=10)
        
        dynamodb.put_item(
            TableName='stj_authentication',
            Item={
                'pk': {'S': f"whatsapp_verification_{clean_phone}"},
                'sk': {'S': 'verification'},
                'phone_number': {'S': clean_phone},
                'verification_code': {'S': verification_code},
                'customer_id': {'S': customer_id},
                'expires_at': {'S': expiry_time.isoformat()},
                'verified': {'BOOL': False},
                'type': {'S': 'whatsapp_verification'}
            }
        )
        
        # Send via WATI API
        wati_result = send_wati_message(clean_phone, f"Your Screentime Journey verification code is: {verification_code}")
        
        if wati_result.get("success"):
            return {
                "ok": True,
                "phone_number": clean_phone,
                "message": "Verification code sent successfully"
            }
        else:
            return {
                "ok": False,
                "error": f"Failed to send WhatsApp message: {wati_result.get('error', 'Unknown error')}"
            }
            
    except Exception as e:
        print(f"❌ Error sending WhatsApp code: {str(e)}")
        return {"ok": False, "error": f"Failed to send verification code: {str(e)}"}


def handle_verify_whatsapp_code(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Verify WhatsApp code and complete setup."""
    phone_number = payload.get("phone_number", "").strip()
    verification_code = payload.get("verification_code", "").strip()
    customer_id = str(payload.get("customer_id", "")).strip()
    
    if not phone_number or not verification_code or not customer_id:
        return {"ok": False, "error": "phone_number, verification_code, and customer_id are required"}
    
    # Clean phone number
    clean_phone = ''.join(filter(str.isdigit, phone_number.replace('+', '')))
    if not clean_phone.startswith('+'):
        clean_phone = '+' + clean_phone
    
    try:
        # Get stored verification code
        response = dynamodb.get_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"whatsapp_verification_{clean_phone}"},
                'sk': {'S': 'verification'}
            }
        )
        
        if 'Item' not in response:
            return {"ok": False, "error": "No verification code found for this number"}
        
        item = response['Item']
        stored_code = item['verification_code']['S']
        stored_customer_id = item['customer_id']['S']
        expires_at = item['expires_at']['S']
        
        # Check if code matches and belongs to the same customer
        if stored_code != verification_code:
            return {"ok": False, "error": "Invalid verification code"}
        
        if stored_customer_id != customer_id:
            return {"ok": False, "error": "Code doesn't match customer"}
        
        # Check if code has expired
        from datetime import datetime
        if datetime.utcnow() > datetime.fromisoformat(expires_at):
            return {"ok": False, "error": "Verification code has expired"}
        
        # Mark as verified and store WhatsApp info
        from datetime import datetime
        timestamp = datetime.utcnow().isoformat()
        
        # Store verified WhatsApp contact
        dynamodb.put_item(
            TableName='stj_authentication',
            Item={
                'pk': {'S': f"whatsapp_contact_{customer_id}"},
                'sk': {'S': 'contact'},
                'customer_id': {'S': customer_id},
                'phone_number': {'S': clean_phone},
                'verified_at': {'S': timestamp},
                'status': {'S': 'active'},
                'opt_in': {'BOOL': True},
                'type': {'S': 'whatsapp_contact'}
            }
        )
        
        # Mark verification as used
        dynamodb.update_item(
            TableName='stj_authentication',
            Key={
                'pk': {'S': f"whatsapp_verification_{clean_phone}"},
                'sk': {'S': 'verification'}
            },
            UpdateExpression='SET verified = :verified',
            ExpressionAttributeValues={':verified': {'BOOL': True}}
        )
        
        # Send welcome message
        welcome_message = "🎉 Welcome to Screentime Journey! Your WhatsApp is now set up. You'll receive progress updates and coaching support to help you crush your screen time goals!"
        send_wati_message(clean_phone, welcome_message)
        
        return {
            "ok": True,
            "phone_number": clean_phone,
            "customer_id": customer_id,
            "message": "WhatsApp setup completed successfully"
        }
        
    except Exception as e:
        print(f"❌ Error verifying WhatsApp code: {str(e)}")
        return {"ok": False, "error": f"Failed to verify code: {str(e)}"}


def send_wati_message(phone_number: str, message: str) -> Dict[str, Any]:
    """Send a message via WATI API."""
    try:
        import requests
        import os
        
        # WATI API configuration
        wati_url = "https://live-server-1625.wati.io/api/v1/sendSessionMessage"
        wati_token = os.environ.get('WATI_API_TOKEN', '')
        
        if not wati_token:
            return {"success": False, "error": "WATI API token not configured"}
        
        headers = {
            'Authorization': f'Bearer {wati_token}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'whatsappNumber': phone_number,
            'message': message
        }
        
        response = requests.post(wati_url, headers=headers, json=data, timeout=30)
        
        if response.status_code == 200:
            return {"success": True, "response": response.json()}
        else:
            return {
                "success": False, 
                "error": f"WATI API error: {response.status_code} - {response.text}"
            }
            
    except Exception as e:
        return {"success": False, "error": f"Failed to send WATI message: {str(e)}"}


# Create authentication table (run once)
def create_authentication_table():
    """Create the unified authentication DynamoDB table."""
    try:
        # Single authentication table with composite key
        dynamodb.create_table(
            TableName='stj_authentication',
            KeySchema=[
                {
                    'AttributeName': 'pk',
                    'KeyType': 'HASH'  # Partition key
                },
                {
                    'AttributeName': 'sk',
                    'KeyType': 'RANGE'  # Sort key
                }
            ],
            AttributeDefinitions=[
                {
                    'AttributeName': 'pk',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'sk',
                    'AttributeType': 'S'
                }
            ],
            BillingMode='PAY_PER_REQUEST'
        )
        
        print("✅ Authentication table created successfully")
    except Exception as e:
        print(f"❌ Error creating authentication table: {str(e)}")

def handle_installed_app(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle requests for the installed app."""
    try:
        query_params = event.get("queryStringParameters") or {}
        shop = query_params.get("shop")
        
        # Simple HTML page for the installed app
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Commitment Widget App</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f6f6f7;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #008060;
            margin-bottom: 20px;
        }}
        .status {{
            background: #e8f5e8;
            border: 1px solid #4caf50;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }}
        .feature {{
            background: #f8f9fa;
            border-left: 4px solid #008060;
            padding: 15px;
            margin-bottom: 15px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 Commitment Widget App</h1>
        
        <div class="status">
            <strong>✅ App Successfully Installed!</strong><br>
            Shop: {shop}
        </div>
        
        <div class="feature">
            <h3>📊 Dashboard</h3>
            <p>Access your customer dashboard at: <code>/apps/stj/screentime-dashboard</code></p>
        </div>
        
        <div class="feature">
            <h3>🔧 Features</h3>
            <ul>
                <li>Customer commitment tracking</li>
                <li>WhatsApp integration</li>
                <li>Subscription management</li>
                <li>Analytics dashboard</li>
            </ul>
        </div>
        
        <div class="feature">
            <h3>📝 Next Steps</h3>
            <p>Your app is now ready to use! Customers can access their dashboard through your store's app proxy.</p>
        </div>
    </div>
</body>
</html>'''
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html; charset=utf-8",
                "Cache-Control": "no-store"
            },
            "body": html
        }
        
    except Exception as e:
        print(f"❌ Installed app error: {e}")
        return json_resp({"error": "Failed to load app"}, 500)

def handle_app_installation(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle app installation requests from Shopify."""
    try:
        # Get shop parameter from query string
        query_params = event.get("queryStringParameters") or {}
        shop = query_params.get("shop")
        
        if not shop:
            return json_resp({"error": "shop parameter required"}, 400)
        
        # Generate OAuth URL for app installation
        oauth_url = f"https://{shop}/admin/oauth/authorize"
        params = {
            "client_id": "cb42141b2a2dff84ca2779da26291b5c",  # Your app's client ID
            "scope": "read_webhooks,write_webhooks,read_own_subscription_contracts,write_own_subscription_contracts,read_orders,read_customers,write_customers,write_products",
            "redirect_uri": "https://ajvrzuyjarph5fvskles42g7ba0zxtxc.lambda-url.eu-north-1.on.aws/auth/callback"
        }
        
        # Build the OAuth URL
        param_string = "&".join([f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items()])
        full_oauth_url = f"{oauth_url}?{param_string}"
        
        print(f"🔧 Redirecting to OAuth URL: {full_oauth_url}")
        
        # Redirect to Shopify OAuth
        return {
            "statusCode": 302,
            "headers": {
                "Location": full_oauth_url
            },
            "body": ""
        }
        
    except Exception as e:
        print(f"❌ App installation error: {e}")
        return json_resp({"error": "App installation failed"}, 500)

def handle_oauth_install(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle OAuth installation request."""
    try:
        # Get shop parameter from query string
        query_params = event.get("queryStringParameters") or {}
        shop = query_params.get("shop")
        
        if not shop:
            return json_resp({"error": "shop parameter required"}, 400)
        
        # Generate OAuth URL
        oauth_url = f"https://{shop}/admin/oauth/authorize"
        params = {
            "client_id": "cb42141b2a2dff84ca2779da26291b5c",  # Your app's client ID
            "scope": "read_webhooks,write_webhooks,read_own_subscription_contracts,write_own_subscription_contracts,read_orders,read_customers,write_customers,write_products",
            "redirect_uri": "https://ajvrzuyjarph5fvskles42g7ba0zxtxc.lambda-url.eu-north-1.on.aws/auth/callback"
        }
        
        # Build the OAuth URL
        param_string = "&".join([f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items()])
        full_oauth_url = f"{oauth_url}?{param_string}"
        
        # Redirect to Shopify OAuth
        return {
            "statusCode": 302,
            "headers": {
                "Location": full_oauth_url
            },
            "body": ""
        }
        
    except Exception as e:
        print(f"❌ OAuth installation error: {e}")
        return json_resp({"error": "OAuth installation failed"}, 500)

def handle_customer_login(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle customer login page."""
    try:
        html = '''<!DOCTYPE html>
<html>
<head>
    <title>Screen Time Journey - Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #333;
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .divider {
            text-align: center;
            margin: 20px 0;
            color: #999;
        }
        .shopify-login {
            background: #95bf47;
        }
        .shopify-login:hover {
            background: #7ea839;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>🎯 Screen Time Journey</h1>
            <p style="color: #666; margin-top: 10px;">Access your dashboard</p>
        </div>
        
        <form id="loginForm">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <button type="submit" class="btn">Continue with Email</button>
        </form>
        
        <div class="divider">or</div>
        
        <button onclick="loginWithShopify()" class="btn shopify-login">
            🔐 Login with Shopify Account
        </button>
        
        <p style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">
            Need an account? <a href="#" style="color: #667eea;">Subscribe here</a>
        </p>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('email').value;
            window.location.href = '/?email=' + encodeURIComponent(email);
        });
        
        function loginWithShopify() {
            // Redirect to Shopify Customer Account login
            const shopDomain = 'screentimejourney.myshopify.com';
            const returnUrl = encodeURIComponent(window.location.href);
            window.location.href = `https://${shopDomain}/account/login?return_url=${returnUrl}`;
        }
    </script>
</body>
</html>'''
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html"
            },
            "body": html
        }
        
    except Exception as e:
        print(f"❌ Customer login error: {e}")
        return json_resp({"error": "Login page failed"}, 500)

def handle_customer_dashboard(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle customer dashboard."""
    try:
        query_params = event.get("queryStringParameters") or {}
        customer_email = query_params.get("email")
        customer_phone = query_params.get("phone")
        token = query_params.get("token")
        
        # Check subscription status in DynamoDB
        try:
            dynamodb = boto3.resource('dynamodb')
            subscribers_table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
            
            # Look up customer by email or phone
            customer_key = customer_email or customer_phone
            if customer_key:
                response = subscribers_table.get_item(Key={'customer_id': customer_key})
                
                if 'Item' in response and response['Item'].get('subscription_status') == 'active':
                    # Customer has active subscription, show dashboard
                    return show_customer_dashboard(event, response['Item'])
                else:
                    # Customer not found or no active subscription
                    return show_subscription_required(event)
            else:
                return show_subscription_required(event)
                
        except Exception as e:
            print(f"⚠️ Error checking subscription: {e}")
            return show_subscription_required(event)
            
    except Exception as e:
        print(f"❌ Customer dashboard error: {e}")
        return json_resp({"error": "Dashboard failed"}, 500)

def show_customer_dashboard(event: Dict[str, Any], customer_data: Dict[str, Any]) -> Dict[str, Any]:
    """Show the customer dashboard."""
    try:
        html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Screen Time Journey - Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f6f6f7;
        }}
        .header {{
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .welcome {{
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }}
        .subscription-info {{
            color: #666;
            font-size: 14px;
        }}
        .dashboard-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .card {{
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .card h3 {{
            margin: 0 0 16px 0;
            color: #333;
            font-size: 18px;
        }}
        .btn {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 8px 8px 8px 0;
        }}
        .btn:hover {{
            transform: translateY(-1px);
        }}
        .logout {{
            background: #dc3545;
            float: right;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="welcome">🎯 Welcome to Screen Time Journey!</div>
        <div class="subscription-info">
            Active Subscription • {customer_data.get('subscription_plan', 'Premium Plan')}
        </div>
        <a href="/" class="btn logout">Logout</a>
    </div>
    
    <div class="dashboard-grid">
        <div class="card">
            <h3>📊 Screen Time Analytics</h3>
            <p>View your daily screen time usage and get insights into your digital habits.</p>
            <button class="btn" onclick="viewAnalytics()">View Analytics</button>
        </div>
        
        <div class="card">
            <h3>🎯 Set Goals</h3>
            <p>Set daily screen time limits and track your progress towards digital wellness.</p>
            <button class="btn" onclick="setGoals()">Set Goals</button>
        </div>
        
        <div class="card">
            <h3>🔔 Notifications</h3>
            <p>Configure alerts and reminders to help you stay on track with your goals.</p>
            <button class="btn" onclick="configureNotifications()">Configure</button>
        </div>
        
        <div class="card">
            <h3>📱 Device Management</h3>
            <p>Manage your connected devices and sync settings across all your gadgets.</p>
            <button class="btn" onclick="manageDevices()">Manage Devices</button>
        </div>
    </div>

    <script>
        function viewAnalytics() {{
            alert('Analytics feature coming soon!');
        }}
        
        function setGoals() {{
            alert('Goal setting feature coming soon!');
        }}
        
        function configureNotifications() {{
            alert('Notification settings coming soon!');
        }}
        
        function manageDevices() {{
            alert('Device management coming soon!');
        }}
    </script>
</body>
</html>'''
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html"
            },
            "body": html
        }
        
    except Exception as e:
        print(f"❌ Show dashboard error: {e}")
        return json_resp({"error": "Dashboard display failed"}, 500)

def show_subscription_required(event: Dict[str, Any]) -> Dict[str, Any]:
    """Show subscription required page."""
    try:
        html = '''<!DOCTYPE html>
<html>
<head>
    <title>Screen Time Journey - Subscription Required</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        .icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        h1 {
            color: #333;
            margin: 0 0 20px 0;
            font-size: 28px;
        }
        p {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 8px;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">🔒</div>
        <h1>Subscription Required</h1>
        <p>To access the Screen Time Journey dashboard, you need an active subscription. Subscribe now to start your digital wellness journey!</p>
        
        <a href="https://screentimejourney.myshopify.com/products/screen-time-journey-subscription" class="btn">
            Subscribe Now
        </a>
        
        <a href="/" class="btn" style="background: #6c757d;">
            Back to Login
        </a>
    </div>
</body>
</html>'''
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html"
            },
            "body": html
        }
        
    except Exception as e:
        print(f"❌ Subscription required error: {e}")
        return json_resp({"error": "Subscription page failed"}, 500)

def handle_oauth_callback(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle OAuth callback from Shopify."""
    try:
        query_params = event.get("queryStringParameters") or {}
        code = query_params.get("code")
        shop = query_params.get("shop")
        
        if not code or not shop:
            return json_resp({"error": "code and shop parameters required"}, 400)
        
        # Exchange code for access token
        token_url = f"https://{shop}/admin/oauth/access_token"
        data = {
            "client_id": "cb42141b2a2dff84ca2779da26291b5c",
            "client_secret": "b039bfce077daf625c9b1791331357b1",  # Your app's client secret
            "code": code
        }
        
        response = requests.post(token_url, data=data)
        if response.status_code != 200:
            return json_resp({"error": "Failed to get access token"}, 500)
        
        token_data = response.json()
        access_token = token_data.get("access_token")
        
        if not access_token:
            return json_resp({"error": "No access token received"}, 500)
        
        # Store the access token (you might want to store this in DynamoDB)
        print(f"✅ OAuth successful for shop: {shop}")
        
        # Store the access token in DynamoDB
        try:
            dynamodb = boto3.resource('dynamodb')
            table = dynamodb.Table(os.environ.get('DDB_TABLE', 'mk_auth'))
            
            table.put_item(Item={
                'pk': f'shop:{shop}',
                'shop': shop,
                'access_token': access_token,
                'installed_at': int(time.time()),
                'scopes': 'read_webhooks,write_webhooks,read_own_subscription_contracts,write_own_subscription_contracts,read_orders,read_customers,write_customers,write_products'
            })
            print(f"✅ Access token stored for shop: {shop}")
        except Exception as e:
            print(f"⚠️ Failed to store access token: {e}")
        
        # Redirect back to the app
        return {
            "statusCode": 302,
            "headers": {
                "Location": f"https://ajvrzuyjarph5fvskles42g7ba0zxtxc.lambda-url.eu-north-1.on.aws/?shop={shop}&installed=true"
            },
            "body": ""
        }
        
    except Exception as e:
        print(f"❌ OAuth callback error: {e}")
        return json_resp({"error": "OAuth callback failed"}, 500)

def handle_app_proxy_page(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle app proxy page requests (GET requests for dashboard)."""
    path = event.get("requestContext", {}).get("http", {}).get("path", "")
    query_params = event.get("queryStringParameters") or {}
    
    print(f"🌐 App proxy page request: {path}")
    print(f"🔍 Query params: {query_params}")
    
    # Check if customer is logged in
    customer_id = query_params.get("customer_id") or query_params.get("logged_in_customer_id")
    if not customer_id:
        # Redirect to login page
        login_url = "/account/login?return_url=" + urllib.parse.quote("/apps/stj/screentime-dashboard")
        html = f'''<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="0;url={login_url}">
    <title>Redirecting to Login</title>
</head>
<body>
    <p>Please <a href="{login_url}">log in</a> to access your dashboard.</p>
</body>
</html>'''
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html; charset=utf-8",
                "Cache-Control": "no-store"
            },
            "body": html
        }
    
    # Extract page name from path (e.g., /stj/screentime-dashboard or /app-proxy/stj/screentime-dashboard -> screentime-dashboard)
    if "/app-proxy/stj/" in path:
        page_name = path.split("/app-proxy/stj/")[-1]
    elif "/stj/" in path:
        page_name = path.split("/stj/")[-1]
    else:
        page_name = ""
    
    # Handle the screentime dashboard page
    if page_name == "screentime-dashboard":
        return handle_dashboard_page(query_params)
    
    # Default 404 for unknown pages
    return {
        "statusCode": 404,
        "headers": {
            "Content-Type": "text/html; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization"
        },
        "body": f"<html><body><h1>Page Not Found</h1><p>The page '{page_name}' was not found.</p></body></html>"
    }

def handle_dashboard_page(query_params: Dict[str, Any]) -> Dict[str, Any]:
    """Serve the screentime dashboard page."""
    try:
        # Get customer data from query parameters
        customer_id = query_params.get("customer_id", "")
        customer_email = query_params.get("customer_email", "")
        shop_domain = query_params.get("shop", "")
        
        # Basic dashboard HTML with embedded JavaScript
        dashboard_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>📱 Screentime Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; background: #f8f9fa; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; border-radius: 12px; margin-bottom: 30px; text-align: center; }}
        .card {{ background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: #f8f9ff; padding: 25px; border-radius: 12px; text-align: center; }}
        .stat-value {{ font-size: 2.5em; color: #667eea; margin: 10px 0; font-weight: bold; }}
        .btn {{ background: #667eea; color: white; padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; margin: 5px; }}
        .btn:hover {{ background: #5a6fd8; }}
        .btn-secondary {{ background: #6c757d; }}
        .setup-card {{ max-width: 600px; margin: 0 auto; }}
        .form-group {{ margin: 20px 0; }}
        .form-group input {{ width: 100%; padding: 12px; border: 2px solid #e9ecef; border-radius: 8px; font-size: 16px; }}
        .form-group input:focus {{ outline: none; border-color: #667eea; }}
        .error {{ color: #dc3545; margin-top: 10px; }}
        .success {{ color: #28a745; margin-top: 10px; }}
        .loading {{ text-align: center; padding: 40px; color: #6c757d; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📱 Screentime Dashboard</h1>
            <p>Track and manage your digital wellness</p>
        </div>
        
        <div id="dashboard-content" class="loading">
            <p>Loading your dashboard...</p>
        </div>
    </div>
    
    <script>
        const API_BASE = 'https://ajvrzuyjarph5fvskles42g7ba0zxtxc.lambda-url.eu-north-1.on.aws';
        const customerId = '{customer_id}';
        const customerEmail = '{customer_email}';
        const shopDomain = '{shop_domain}';
        
        document.addEventListener('DOMContentLoaded', function() {{
            console.log('Dashboard loaded for customer:', customerId);
            checkUserSetupStatus();
        }});
        
        function checkUserSetupStatus() {{
            if (!customerId) {{
                showLoginRequired();
                return;
            }}
            
            fetch(API_BASE + '/get-username', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ customer_id: customerId }})
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.has_username) {{
                    showDashboard();
                }} else {{
                    showSetupFlow();
                }}
            }})
            .catch(error => {{
                console.error('Error checking setup status:', error);
                showDashboard(); // Fallback to dashboard
            }});
        }}
        
        function showLoginRequired() {{
            document.getElementById('dashboard-content').innerHTML = `
                <div class="card">
                    <h2>🔐 Login Required</h2>
                    <p>Please log in to your account to access the dashboard.</p>
                    <button class="btn" onclick="window.location.href='/account/login'">
                        Go to Login
                    </button>
                </div>
            `;
        }}
        
        function showSetupFlow() {{
            document.getElementById('dashboard-content').innerHTML = `
                <div class="setup-card">
                    <div class="card">
                        <h2>👤 Setup Your Dashboard</h2>
                        <p>Choose a unique username to get started with your screentime dashboard.</p>
                        
                        <div class="form-group">
                            <input type="text" id="username-input" placeholder="Enter your username" maxlength="20">
                            <div id="username-message"></div>
                        </div>
                        
                        <button class="btn" onclick="registerUsername()" id="register-btn">
                            Create Username
                        </button>
                        <button class="btn btn-secondary" onclick="skipSetup()">
                            Skip Setup
                        </button>
                    </div>
                </div>
            `;
            
            // Add username validation
            document.getElementById('username-input').addEventListener('input', function(e) {{
                const value = e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
                e.target.value = value;
                document.getElementById('register-btn').disabled = value.length < 3;
            }});
        }}
        
        function showDashboard() {{
            document.getElementById('dashboard-content').innerHTML = `
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>📱 Today's Screen Time</h3>
                        <div class="stat-value" id="screen-time">4h 23m</div>
                    </div>
                    <div class="stat-card">
                        <h3>🎯 Goal Progress</h3>
                        <div class="stat-value" id="goal-progress">73%</div>
                    </div>
                    <div class="stat-card">
                        <h3>📈 Weekly Average</h3>
                        <div class="stat-value" id="weekly-avg">5h 12m</div>
                    </div>
                    <div class="stat-card">
                        <h3>🏆 Current Streak</h3>
                        <div class="stat-value" id="streak">7 days</div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>🎯 Quick Actions</h2>
                    <button class="btn" onclick="setGoal()">Set Daily Goal</button>
                    <button class="btn" onclick="viewReport()">View Weekly Report</button>
                    <button class="btn" onclick="exportData()">Export Data</button>
                </div>
                
                <div class="card">
                    <h2>📊 This Week's Progress</h2>
                    <p>You're doing great! Keep up the momentum.</p>
                    <div style="background: #e9ecef; height: 20px; border-radius: 10px; overflow: hidden;">
                        <div style="background: #667eea; height: 100%; width: 73%; border-radius: 10px;"></div>
                    </div>
                    <p style="margin-top: 10px; color: #6c757d;">73% towards your weekly goal</p>
                </div>
            `;
        }}
        
        function registerUsername() {{
            const username = document.getElementById('username-input').value.trim();
            const messageEl = document.getElementById('username-message');
            
            if (!username || username.length < 3) {{
                messageEl.innerHTML = '<div class="error">Username must be at least 3 characters</div>';
                return;
            }}
            
            document.getElementById('register-btn').disabled = true;
            document.getElementById('register-btn').textContent = 'Creating...';
            
            fetch(API_BASE + '/register-username', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ 
                    username: username,
                    customer_id: customerId 
                }})
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.ok) {{
                    messageEl.innerHTML = '<div class="success">Username created successfully!</div>';
                    setTimeout(() => showDashboard(), 1500);
                }} else {{
                    messageEl.innerHTML = '<div class="error">' + (data.error || 'Failed to create username') + '</div>';
                    document.getElementById('register-btn').disabled = false;
                    document.getElementById('register-btn').textContent = 'Create Username';
                }}
            }})
            .catch(error => {{
                messageEl.innerHTML = '<div class="error">Failed to create username. Please try again.</div>';
                document.getElementById('register-btn').disabled = false;
                document.getElementById('register-btn').textContent = 'Create Username';
            }});
        }}
        
        function skipSetup() {{
            showDashboard();
        }}
        
        function setGoal() {{
            const goal = prompt('Enter your daily screen time goal (in hours):');
            if (goal && !isNaN(goal)) {{
                alert('Daily goal set to ' + goal + ' hours!');
            }}
        }}
        
        function viewReport() {{
            alert('Weekly report feature coming soon!');
        }}
        
        function exportData() {{
            alert('Data export feature coming soon!');
        }}
    </script>
</body>
</html>
        """
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/html; charset=utf-8",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": dashboard_content
        }
        
    except Exception as e:
        print(f"❌ Error serving dashboard page: {{str(e)}}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "text/html; charset=utf-8"
            },
            "body": f"<html><body><h1>Error</h1><p>Failed to load dashboard: {{str(e)}}</p></body></html>"
        }