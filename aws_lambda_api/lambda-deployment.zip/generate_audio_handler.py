"""
AWS Lambda handler for generating audio files using Amazon Polly
Generates spoken instructions for screen time pincode setup and stores in S3
"""

import json
import boto3
import uuid
import time
from decimal import Decimal
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
polly_client = boto3.client('polly', region_name='eu-north-1')
s3_client = boto3.client('s3', region_name='eu-north-1')
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')

# Configuration
S3_BUCKET = 'wati-audio-guides'
DYNAMODB_TABLE = 'MK_audio_guides'
PASSWORD_TABLE = 'stj_password'

def generate_pincode_ssml(pincode_digits):
    """Generate SSML for pincode instructions"""
    first, second, third, fourth = pincode_digits
    sleep = 2
    
    instruction_script = f"""
Press 1 <break time="{sleep}s"/>
Press 9 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press {first} <break time="{sleep}s"/>
Press 4 <break time="{sleep}s"/>
Press 6 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press {second} <break time="{sleep}s"/>
Press 7 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press 7 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press 3 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press 6 <break time="{sleep}s"/>
Press backspace <break time="{sleep}s"/>
Press {third} <break time="{sleep}s"/>
Press {fourth} <break time="{sleep}s"/>"""

    warning_tags = """DO NOT LOG OUT FROM ICLOUD
<break time="2s"/>
I REPEAT, DON'T LOG OUT FROM ICLOUD
<break time="2s"/>
See the instruction video for how to move around logging in with iCloud."""

    break_tags = """Now we are gonna do it again
<break time="2s"/>"""

    # Full SSML speech text
    ssml_text = f"""<speak>
Get ready to insert your screen time pincode
<break time="2s"/>
Click settings <break time="2s"/>
Click screen time <break time="2s"/>
Click Lock Screen Time settings <break time="2s"/>
Are you ready? Here we go <break time="2s"/>
{instruction_script}
{break_tags}
{instruction_script}
{warning_tags}
</speak>"""

    return ssml_text

def lambda_handler(event, context):
    """Main Lambda handler for audio generation"""
    try:
        logger.info(f"🎵 Audio generation request: {event}")
        
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Extract parameters
        device_type = body.get('device_type', 'iOS')
        device_name = body.get('device_name', 'Device')
        user_id = body.get('user_id', 'anonymous')
        
        # Use provided pincode or generate new one
        pincode = body.get('pincode')
        audio_uuid = body.get('uuid', str(uuid.uuid4()))
        
        if not pincode:
            # Generate 4-digit pincode if not provided
            pincode = str(int(time.time() * 1000) % 10000).zfill(4)
            audio_uuid = str(uuid.uuid4())
        
        pincode_digits = list(pincode)
        timestamp = int(time.time())
        
        # Store pincode in stj_password table BEFORE generating audio
        password_table = dynamodb.Table(PASSWORD_TABLE)
        
        password_record = {
            'user_id': user_id,
            'uuid': audio_uuid,
            'pincode': pincode,
            'device_type': device_type,
            'device_name': device_name,
            'method': 'create',
            'purpose': 'audio_guide',
            'created_at': timestamp,
            'url': f"https://{S3_BUCKET}.s3.eu-north-1.amazonaws.com/pincode-guides/audio-guide-{user_id}-{audio_uuid}.mp3"
        }
        
        try:
            password_table.put_item(Item=password_record)
            logger.info(f"✅ Pincode {pincode} stored in stj_password table")
        except Exception as e:
            logger.error(f"❌ Failed to store pincode in stj_password: {str(e)}")
            # Continue with audio generation even if password storage fails
        
        # Generate SSML content
        ssml_content = generate_pincode_ssml(pincode_digits)
        
        logger.info(f"🔊 Generated SSML for pincode {pincode}")
        
        # Generate audio using Polly
        polly_response = polly_client.synthesize_speech(
            Text=ssml_content,
            OutputFormat='mp3',
            VoiceId='Joanna',  # Female US English voice
            TextType='ssml',
            SampleRate='22050'
        )
        
        # Get audio stream
        audio_stream = polly_response['AudioStream'].read()
        
        # Generate S3 filename
        filename = f"audio-guide-{user_id}-{audio_uuid}.mp3"
        s3_key = f"pincode-guides/{filename}"
        
        # Upload to S3
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_key,
            Body=audio_stream,
            ContentType='audio/mpeg',
            ACL='public-read',
            Metadata={
                'user_id': user_id,
                'device_type': device_type,
                'pincode': pincode,
                'uuid': audio_uuid,
                'generated_at': str(timestamp)
            }
        )
        
        # Generate public S3 URL
        s3_url = f"https://{S3_BUCKET}.s3.eu-north-1.amazonaws.com/{s3_key}"
        
        logger.info(f"✅ Audio uploaded to S3: {s3_url}")
        
        # Store metadata in DynamoDB
        audio_table = dynamodb.Table(DYNAMODB_TABLE)
        
        audio_record = {
            'audio_id': audio_uuid,
            'user_id': user_id,
            'device_type': device_type,
            'device_name': device_name,
            'pincode': pincode,
            'pincode_digits': {
                'first': pincode_digits[0],
                'second': pincode_digits[1], 
                'third': pincode_digits[2],
                'fourth': pincode_digits[3]
            },
            's3_url': s3_url,
            's3_bucket': S3_BUCKET,
            's3_key': s3_key,
            'filename': filename,
            'voice_id': 'Joanna',
            'duration_estimate': Decimal('120'),  # Estimated 2 minutes
            'audio_size_bytes': len(audio_stream),
            'ssml_content': ssml_content,
            'created_at': timestamp,
            'status': 'active'
        }
        
        audio_table.put_item(Item=audio_record)
        
        logger.info(f"✅ Audio metadata stored in DynamoDB")
        
        # Prepare response
        response_data = {
            'success': True,
            'audioData': {
                'audioUrl': s3_url,
                'pincode': pincode,
                'digits': {
                    'first': pincode_digits[0],
                    'second': pincode_digits[1],
                    'third': pincode_digits[2], 
                    'fourth': pincode_digits[3]
                },
                'uuid': audio_uuid,
                'deviceType': device_type,
                'filename': filename,
                'instructions': f"Generated pincode: {pincode}. Follow the audio instructions to enter your screen time pincode.",
                'duration': 120,
                'createdAt': timestamp
            }
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"❌ Error generating audio: {str(e)}", exc_info=True)
        
        error_response = {
            'success': False,
            'error': f'Audio generation failed: {str(e)}',
            'errorType': type(e).__name__
        }
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(error_response)
        }

def handler(event, context):
    """Alternative handler name for compatibility"""
    return lambda_handler(event, context)
