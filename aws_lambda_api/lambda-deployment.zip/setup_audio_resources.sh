#!/bin/bash

# Setup AWS Resources for Audio Generation
# Creates S3 bucket and DynamoDB table for audio file storage and metadata

echo "🎵 Setting up AWS resources for audio generation..."

REGION="eu-north-1"
S3_BUCKET="wati-audio-guides"
DYNAMODB_TABLE="MK_audio_guides"

# Create S3 bucket for audio files
echo "🪣 Creating S3 bucket: $S3_BUCKET"
aws s3 mb s3://$S3_BUCKET --region $REGION 2>/dev/null || echo "Bucket already exists"

# Configure S3 bucket for public read access
echo "🔓 Configuring S3 bucket permissions..."
aws s3api put-bucket-cors --bucket $S3_BUCKET --cors-configuration '{
    "CORSRules": [
        {
            "AllowedHeaders": ["*"],
            "AllowedMethods": ["GET", "HEAD"],
            "AllowedOrigins": ["*"],
            "ExposeHeaders": [],
            "MaxAgeSeconds": 3000
        }
    ]
}' 2>/dev/null

# Create DynamoDB table for audio metadata
echo "🗄️ Creating DynamoDB table: $DYNAMODB_TABLE"
aws dynamodb create-table \
    --table-name $DYNAMODB_TABLE \
    --attribute-definitions \
        AttributeName=audio_id,AttributeType=S \
        AttributeName=user_id,AttributeType=S \
        AttributeName=created_at,AttributeType=N \
    --key-schema \
        AttributeName=audio_id,KeyType=HASH \
    --global-secondary-indexes \
        'IndexName=user_id-created_at-index,KeySchema=[{AttributeName=user_id,KeyType=HASH},{AttributeName=created_at,KeyType=RANGE}],Projection={ProjectionType=ALL},BillingMode=PAY_PER_REQUEST' \
    --billing-mode PAY_PER_REQUEST \
    --region $REGION 2>/dev/null || echo "Table already exists"

echo "⏳ Waiting for DynamoDB table to be active..."
aws dynamodb wait table-exists --table-name $DYNAMODB_TABLE --region $REGION

echo "✅ AWS resources setup complete!"
echo "🪣 S3 Bucket: s3://$S3_BUCKET"
echo "🗄️ DynamoDB Table: $DYNAMODB_TABLE"
echo "🌍 Region: $REGION"

