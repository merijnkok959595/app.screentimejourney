#!/bin/bash

# Deploy Subscription Cancellation Lambda Function
# This script packages and deploys the cancel_subscription_handler.py Lambda function

echo "🚀 Deploying Subscription Cancellation Lambda Function..."
echo "============================================================"

# Configuration
FUNCTION_NAME="stj-cancel-subscription"
REGION="eu-north-1"
PYTHON_VERSION="python3.11"
HANDLER="cancel_subscription_handler.lambda_handler"

# Create deployment package
echo "📦 Creating deployment package..."

# Create temporary directory for packaging
TEMP_DIR="cancel_lambda_package"
rm -rf $TEMP_DIR
mkdir $TEMP_DIR

# Copy handler file
cp cancel_subscription_handler.py $TEMP_DIR/

# Install dependencies if requirements file exists
if [ -f "cancel_requirements.txt" ]; then
    echo "📥 Installing dependencies..."
    pip install -r cancel_requirements.txt -t $TEMP_DIR/
else
    echo "⚠️  No cancel_requirements.txt found, skipping dependency installation"
fi

# Create deployment zip
cd $TEMP_DIR
echo "🗜️  Creating deployment zip..."
zip -r ../cancel-lambda-deployment.zip .
cd ..

# Clean up temporary directory
rm -rf $TEMP_DIR

echo "✅ Deployment package created: cancel-lambda-deployment.zip"

# Deploy to AWS Lambda
echo "🚀 Deploying to AWS Lambda..."

# Check if function exists
if aws lambda get-function --function-name $FUNCTION_NAME --region $REGION >/dev/null 2>&1; then
    echo "📝 Function exists, updating code..."
    aws lambda update-function-code \
        --function-name $FUNCTION_NAME \
        --zip-file fileb://cancel-lambda-deployment.zip \
        --region $REGION
    
    echo "⚙️  Updating function configuration..."
    aws lambda update-function-configuration \
        --function-name $FUNCTION_NAME \
        --handler $HANDLER \
        --runtime $PYTHON_VERSION \
        --timeout 30 \
        --memory-size 256 \
        --region $REGION
else
    echo "🆕 Creating new function..."
    aws lambda create-function \
        --function-name $FUNCTION_NAME \
        --runtime $PYTHON_VERSION \
        --role arn:aws:iam::$(aws sts get-caller-identity --query Account --output text):role/lambda-execution-role \
        --handler $HANDLER \
        --zip-file fileb://cancel-lambda-deployment.zip \
        --timeout 30 \
        --memory-size 256 \
        --region $REGION \
        --description "Handle subscription cancellation via Shopify API"
fi

# Add environment variables
echo "🔧 Setting environment variables..."
aws lambda update-function-configuration \
    --function-name $FUNCTION_NAME \
    --environment Variables='{
        "SUBSCRIBERS_TABLE":"stj_subscribers",
        "CANCELLATION_TABLE":"stj_cancellations",
        "FROM_EMAIL":"noreply@screentimejourney.com",
        "SHOPIFY_ACCESS_TOKEN":"your_shopify_access_token_here"
    }' \
    --region $REGION

# Create function URL (for direct HTTPS access)
echo "🌐 Creating function URL..."
aws lambda create-function-url-config \
    --function-name $FUNCTION_NAME \
    --auth-type NONE \
    --cors '{
        "AllowOrigins": ["*"],
        "AllowMethods": ["POST", "OPTIONS"],
        "AllowHeaders": ["Content-Type"],
        "MaxAge": 86400
    }' \
    --region $REGION 2>/dev/null || echo "Function URL already exists"

# Get function URL
FUNCTION_URL=$(aws lambda get-function-url-config --function-name $FUNCTION_NAME --region $REGION --query FunctionUrl --output text 2>/dev/null)

echo "============================================================"
echo "✅ Deployment completed successfully!"
echo ""
echo "📋 Function Details:"
echo "   • Function Name: $FUNCTION_NAME"
echo "   • Region: $REGION"
echo "   • Runtime: $PYTHON_VERSION"
echo "   • Handler: $HANDLER"
echo "   • Memory: 256 MB"
echo "   • Timeout: 30 seconds"
echo ""
if [ ! -z "$FUNCTION_URL" ]; then
    echo "🌐 Function URL: $FUNCTION_URL"
    echo ""
    echo "📝 API Endpoint: ${FUNCTION_URL}cancel_subscription"
    echo ""
fi
echo "⚙️  Next Steps:"
echo "   1. Update SHOPIFY_ACCESS_TOKEN environment variable with actual token"
echo "   2. Ensure SES is configured for sending emails"
echo "   3. Create stj_cancellations DynamoDB table if it doesn't exist"
echo "   4. Test the cancellation flow"
echo ""
echo "🧪 Test with curl:"
echo 'curl -X POST "'$FUNCTION_URL'cancel_subscription" \'
echo '  -H "Content-Type: application/json" \'
echo '  -d '"'"'{"user_id":"test_user","customer_email":"test@example.com","shop":"test.myshopify.com","cancel_reason":"testing"}'"'"''
echo ""
echo "============================================================"

