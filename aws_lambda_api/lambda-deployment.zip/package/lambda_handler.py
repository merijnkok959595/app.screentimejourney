"""
Clean Lambda Handler for Screen Time Journey Shopify App
Handles: Webhooks + Commitment Widget + App Proxy
"""

import os
import json
import time
import boto3
import requests
import hmac
import hashlib
import urllib.parse
import random
from typing import Dict, Any, Tuple, Optional
from datetime import datetime, timedelta
from decimal import Decimal

# Try to import JWT, fall back gracefully if not available
try:
    import jwt
    JWT_AVAILABLE = True
except ImportError:
    JWT_AVAILABLE = False
    print("⚠️ JWT library not available - some features will be disabled")

# Initialize AWS clients
secretsmanager = boto3.client('secretsmanager')

# Global cache for tokens to avoid repeated API calls
_SHOPIFY_TOKEN_CACHE = None


# =============================================================================
# SHOPIFY API CREDENTIALS
# =============================================================================

SHOP_DOMAIN = os.environ.get('SHOP_DOMAIN', 'xpvznx-9w.myshopify.com')

def get_shopify_storefront_token() -> str:
    """Securely fetch and cache the Shopify Storefront Access Token from Secrets Manager."""
    global _SHOPIFY_TOKEN_CACHE
    if _SHOPIFY_TOKEN_CACHE:
        return _SHOPIFY_TOKEN_CACHE[0]

    try:
        resp = secretsmanager.get_secret_value(SecretId="Shopify-Storefront-Private-Token")
        token = None

        if "SecretString" in resp and resp["SecretString"]:
            try:
                # Try parsing as JSON first
                secret_data = json.loads(resp["SecretString"])
                token = secret_data.get("Shopify-Storefront-Private-Token")
            except json.JSONDecodeError:
                # Fallback: treat as plain string
                token = resp["SecretString"]

        if token:
            _SHOPIFY_TOKEN_CACHE = (token, time.time())
            print("✅ Successfully retrieved Shopify Storefront token from Secrets Manager")
            return token
        else:
            print("❌ Empty Shopify Storefront token in Secrets Manager")
            return ""

    except Exception as e:
        print(f"❌ Error retrieving Shopify Storefront token: {e}")
        return ""

def get_shopify_admin_token() -> str:
    """Get Shopify Admin API access token from environment"""
    return os.environ.get("SHOPIFY_ACCESS_TOKEN", "")

# =============================================================================
# UTILITIES
# =============================================================================

def json_resp(body: Dict[str, Any], status: int = 200):
    """Standard JSON response with CORS headers"""
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps(body, default=str)
    }


def parse_body(event) -> Dict[str, Any]:
    """Parse request body"""
    try:
        body = event.get("body", "{}")
        if isinstance(body, str):
            return json.loads(body)
        return body or {}
    except (json.JSONDecodeError, TypeError):
        return {}


def convert_floats_to_decimal(obj):
    """Convert floats in nested dict/list to Decimal for DynamoDB compatibility"""
    if isinstance(obj, float):
        return Decimal(str(obj))
    elif isinstance(obj, dict):
        return {k: convert_floats_to_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_floats_to_decimal(item) for item in obj]
    else:
        return obj


# Native Shopify HMAC verification removed - Flow webhooks only use Bearer token auth


# =============================================================================
# DATABASE OPERATIONS
# =============================================================================

def update_subscriber(customer_id: str, email: str, status: str, event_type: str, data: Dict = None, commitment_data: Dict = None, utm_data: Dict = None, phone: str = None) -> bool:
    """Update subscriber record in DynamoDB"""
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        if not customer_id:
            print(f"⚠️ No customer_id provided")
            return False

        # Try to get existing record first to preserve data
        try:
            existing_item = table.get_item(Key={'customer_id': customer_id})
            existing_data = existing_item.get('Item', {})
            print(f"📋 Found existing record for {customer_id}, merging data")
        except Exception:
            existing_data = {}
            print(f"📝 Creating new record for {customer_id}")

        # Start with ALL existing data to preserve everything
        update_data = existing_data.copy() if existing_data else {}
        
        # Only update specific fields, preserving everything else
        update_data.update({
            'customer_id': customer_id,
            'email': email,
            'subscription_status': status,
            'event_type': event_type,
            'last_updated': datetime.now().isoformat(),
            'status': status,
            # Only set created_at if it doesn't exist
            'created_at': existing_data.get('created_at', datetime.now().isoformat())
        })
        
        # Update commitment_data if provided
        if commitment_data:
            update_data['commitment_data'] = commitment_data
            print(f"📊 Updated commitment_data from webhook")
        
        # Update utm_data if provided
        if utm_data:
            update_data['utm_data'] = utm_data
            print(f"📊 Updated utm_data from webhook")
        
        # Update phone if provided (and not empty to avoid DynamoDB index issues)
        if phone and phone.strip():
            update_data['phone'] = phone
            print(f"📊 Updated phone from webhook")
        
        # Merge shopify_data instead of overwriting it
        existing_shopify_data = existing_data.get('shopify_data', {})
        new_shopify_data = convert_floats_to_decimal(data or {})
        
        # If existing record has shopify_data, merge both
        if existing_shopify_data:
            # Keep existing data and add new webhook data with event-specific key
            merged_shopify_data = existing_shopify_data.copy()
            merged_shopify_data[f'{event_type}_data'] = new_shopify_data
            update_data['shopify_data'] = merged_shopify_data
        else:
            # No existing shopify_data, just use new data
            update_data['shopify_data'] = new_shopify_data
            
        print(f"📊 Preserving fields: utm_data={bool(existing_data.get('utm_data'))}, commitment_data={bool(existing_data.get('commitment_data'))}, phone={bool(existing_data.get('phone'))}")
        
        table.put_item(Item=update_data)
        print(f"✅ Updated subscriber: {customer_id} - {status} - {event_type}")
        return True
        
    except Exception as e:
        print(f"❌ Database error: {e}")
        return False


def save_customer_profile(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Save customer profile data (username, gender, whatsapp) to DynamoDB"""
    try:
        customer_id = payload.get('customer_id')
        username = payload.get('username', '').strip()
        gender = payload.get('gender', '').strip()
        whatsapp = payload.get('whatsapp', '').strip()
        
        if not customer_id:
            return json_resp({'error': 'Customer ID is required'}, 400)
        
        if not username or not gender:
            return json_resp({'error': 'Username and gender are required'}, 400)
        
        # Validate gender
        if gender.lower() not in ['male', 'female']:
            return json_resp({'error': 'Gender must be "male" or "female"'}, 400)
        
        # CRITICAL: Final username uniqueness check to prevent race conditions
        username_check = check_username_availability({'username': username})
        if username_check['statusCode'] != 200:
            return username_check
        
        username_data = json.loads(username_check['body'])
        if not username_data.get('available', False):
            return json_resp({'error': 'Username is no longer available'}, 409)
        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Get existing record
        response = table.get_item(Key={'customer_id': customer_id})
        
        if 'Item' not in response:
            return json_resp({'error': 'Customer not found'}, 404)
        
        # Update the record with profile data
        update_data = response['Item']
        update_data.update({
            'username': username,
            'gender': gender.lower(),
            'profile_updated_at': datetime.now().isoformat()
        })
        
        # Add WhatsApp if provided
        if whatsapp:
            update_data['whatsapp'] = whatsapp
        
        table.put_item(Item=update_data)
        
        print(f"✅ Profile saved for customer {customer_id}: username={username}, gender={gender}")
        
        return json_resp({
            'success': True,
            'message': 'Profile saved successfully',
            'customer_id': customer_id
        })
        
    except Exception as e:
        print(f"❌ Error saving profile: {e}")
        return json_resp({'error': 'Failed to save profile'}, 500)


def check_username_availability(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Check if username is available (not taken by another customer)"""
    try:
        username = payload.get('username', '').strip().lower()
        
        if not username:
            return json_resp({'error': 'Username is required'}, 400)
        
        if len(username) < 2:
            return json_resp({'error': 'Username must be at least 2 characters'}, 400)
        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Scan for existing username (in a real app, you'd want a GSI for this)
        response = table.scan(
            FilterExpression='username = :username',
            ExpressionAttributeValues={':username': username}
        )
        
        is_available = len(response.get('Items', [])) == 0
        
        print(f"✅ Username '{username}' availability check: {'available' if is_available else 'taken'}")
        
        return json_resp({
            'available': is_available,
            'username': username,
            'message': 'Username is available' if is_available else 'Username is already taken'
        })
        
    except Exception as e:
        print(f"❌ Error checking username availability: {e}")
        return json_resp({'error': 'Failed to check username availability'}, 500)


def send_whatsapp_verification_code(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send WhatsApp verification code via WATI API"""
    try:
        phone = payload.get('phone', '').strip()
        
        if not phone:
            return json_resp({'error': 'Phone number is required'}, 400)
        
        # Generate 6-digit code
        import random
        verification_code = str(random.randint(100000, 999999))
        
        # In a real implementation, you would:
        # 1. Store the code in a temporary storage (Redis/DynamoDB with TTL)
        # 2. Call WATI API to send the code via WhatsApp
        # 3. Handle rate limiting and retry logic
        
        # For now, we'll simulate success and log the code
        print(f"📱 Would send WhatsApp code {verification_code} to {phone}")
        
        # Store verification code temporarily (in real app, use Redis or DynamoDB with TTL)
        # For demo purposes, we'll just store it in memory
        # In production, implement proper temporary storage
        
        return json_resp({
            'success': True,
            'message': f'Verification code sent to {phone}',
            'phone': phone,
            # In production, don't return the code!
            'debug_code': verification_code if os.environ.get('DEBUG') == 'true' else None
        })
        
    except Exception as e:
        print(f"❌ Error sending WhatsApp verification code: {e}")
        return json_resp({'error': 'Failed to send verification code'}, 500)


def verify_whatsapp_verification_code(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Verify WhatsApp verification code"""
    try:
        phone = payload.get('phone', '').strip()
        code = payload.get('code', '').strip()
        
        if not phone or not code:
            return json_resp({'error': 'Phone number and code are required'}, 400)
        
        if len(code) != 6 or not code.isdigit():
            return json_resp({'error': 'Invalid verification code format'}, 400)
        
        # In a real implementation, you would:
        # 1. Retrieve the stored code from temporary storage
        # 2. Compare with provided code
        # 3. Check if code has expired
        # 4. Mark phone as verified
        
        # For demo purposes, accept any 6-digit code
        print(f"📱 Verifying WhatsApp code {code} for {phone}")
        
        # In production, implement proper code verification
        is_valid = True  # For demo, always valid
        
        if is_valid:
            return json_resp({
                'success': True,
                'message': 'Phone number verified successfully',
                'phone': phone
            })
        else:
            return json_resp({'error': 'Invalid or expired verification code'}, 400)
        
    except Exception as e:
        print(f"❌ Error verifying WhatsApp code: {e}")
        return json_resp({'error': 'Failed to verify code'}, 500)


def get_customer_profile(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get complete customer profile data from DynamoDB"""
    try:
        customer_id = payload.get('customer_id')
        
        if not customer_id:
            return json_resp({'error': 'Customer ID is required'}, 400)
        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Get customer record
        response = table.get_item(Key={'customer_id': customer_id})
        
        if 'Item' not in response:
            return json_resp({'error': 'Customer not found'}, 404)
        
        customer_data = response['Item']
        
        # Build profile response with relevant fields
        profile = {
            'customer_id': customer_data.get('customer_id', ''),
            'email': customer_data.get('email', ''),
            'username': customer_data.get('username', ''),
            'gender': customer_data.get('gender', ''),
            'whatsapp': customer_data.get('whatsapp', ''),
            'subscription_status': customer_data.get('subscription_status', 'inactive'),
            'created_at': customer_data.get('created_at', ''),
            'updated_at': customer_data.get('profile_updated_at', customer_data.get('last_updated', '')),
            # Add any other relevant profile fields
            'commitment_data': customer_data.get('commitment_data', {}),
            'utm_data': customer_data.get('utm_data', {})
        }
        
        print(f"✅ Profile retrieved for customer {customer_id}")
        
        return json_resp({
            'success': True,
            'profile': profile
        })
        
    except Exception as e:
        print(f"❌ Error getting customer profile: {e}")
        return json_resp({'error': 'Failed to get profile'}, 500)


def update_customer_profile(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Update customer profile data in DynamoDB"""
    try:
        customer_id = payload.get('customer_id')
        
        if not customer_id:
            return json_resp({'error': 'Customer ID is required'}, 400)
        
        # Get the fields to update (excluding email and customer_id)
        updatable_fields = ['username', 'gender', 'whatsapp']
        update_data = {}
        
        for field in updatable_fields:
            if field in payload:
                value = payload[field]
                if field == 'username':
                    # Validate and sanitize username
                    value = str(value).strip().lower()
                    if len(value) < 3 or not value.replace('_', '').replace('-', '').isalnum():
                        return json_resp({'error': 'Invalid username format'}, 400)
                    # Check username availability (excluding current user)
                    username_check = check_username_availability_for_update(value, customer_id)
                    if not username_check:
                        return json_resp({'error': 'Username is already taken'}, 409)
                elif field == 'gender':
                    # Validate gender
                    value = str(value).strip().lower()
                    if value not in ['male', 'female']:
                        return json_resp({'error': 'Gender must be "male" or "female"'}, 400)
                elif field == 'whatsapp':
                    # Sanitize WhatsApp (optional field)
                    value = str(value).strip() if value else ''
                
                update_data[field] = value
        
        if not update_data:
            return json_resp({'error': 'No valid fields to update'}, 400)
        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Get existing record
        response = table.get_item(Key={'customer_id': customer_id})
        
        if 'Item' not in response:
            return json_resp({'error': 'Customer not found'}, 404)
        
        # Update the record
        existing_data = response['Item']
        existing_data.update(update_data)
        existing_data['profile_updated_at'] = datetime.now().isoformat()
        
        table.put_item(Item=existing_data)
        
        # Build updated profile response
        profile = {
            'customer_id': existing_data.get('customer_id', ''),
            'email': existing_data.get('email', ''),
            'username': existing_data.get('username', ''),
            'gender': existing_data.get('gender', ''),
            'whatsapp': existing_data.get('whatsapp', ''),
            'subscription_status': existing_data.get('subscription_status', 'inactive'),
            'created_at': existing_data.get('created_at', ''),
            'updated_at': existing_data.get('profile_updated_at', ''),
            'commitment_data': existing_data.get('commitment_data', {}),
            'utm_data': existing_data.get('utm_data', {})
        }
        
        print(f"✅ Profile updated for customer {customer_id}: {list(update_data.keys())}")
        
        return json_resp({
            'success': True,
            'profile': profile,
            'message': 'Profile updated successfully'
        })
        
    except Exception as e:
        print(f"❌ Error updating customer profile: {e}")
        return json_resp({'error': 'Failed to update profile'}, 500)


def check_username_availability_for_update(username: str, customer_id: str) -> bool:
    """Check if username is available for update (excluding current customer)"""
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Scan for existing username (excluding current customer)
        response = table.scan(
            FilterExpression='username = :username AND customer_id <> :customer_id',
            ExpressionAttributeValues={
                ':username': username,
                ':customer_id': customer_id
            }
        )
        
        is_available = len(response.get('Items', [])) == 0
        
        print(f"✅ Username '{username}' availability check for update: {'available' if is_available else 'taken'}")
        
        return is_available
        
    except Exception as e:
        print(f"❌ Error checking username availability for update: {e}")
        return False


def find_and_update_webapp_record(shopify_customer_id: str, customer_email: str, order_data: Dict[str, Any]) -> bool:
    """Find existing webapp record and update it with real Shopify customer ID"""
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        print(f"🔍 Looking for existing webapp record for email: {customer_email}")
        
        # Scan for records with matching email (we can't use query without a GSI on email)
        response = table.scan(
            FilterExpression="email = :email",
            ExpressionAttributeValues={':email': customer_email},
            Limit=50  # Reasonable limit to avoid long scans
        )
        
        webapp_records = [item for item in response.get('Items', []) 
                         if str(item.get('customer_id', '')).startswith('webapp_')]
        
        if not webapp_records:
            print(f"ℹ️ No webapp records found for email: {customer_email}")
            return False
        
        # Find the most recent webapp record
        webapp_record = max(webapp_records, key=lambda x: x.get('created_at', ''))
        old_customer_id = webapp_record.get('customer_id')
        
        print(f"✅ Found webapp record: {old_customer_id}")
        
        # Merge the data from both records
        merged_data = {
            'customer_id': shopify_customer_id,  # Update to real Shopify customer ID
            'email': customer_email,
            'subscription_status': 'active',
            'event_type': 'order_created',
            'last_updated': datetime.now().isoformat(),
            'shopify_data': convert_floats_to_decimal(order_data),
            # Preserve existing data from webapp record
            'commitment_data': webapp_record.get('commitment_data', {}),
            'utm_data': webapp_record.get('utm_data', {}),
            'country_code': webapp_record.get('country_code', ''),
            'variant_gid': webapp_record.get('variant_gid', ''),
            'selling_plan_id': webapp_record.get('selling_plan_id', ''),
            'checkout_url': webapp_record.get('checkout_url', ''),
            'status': 'order_completed',  # Update status
            'created_at': webapp_record.get('created_at', datetime.now().isoformat())
        }
        
        # Only add phone if it exists and is not empty (DynamoDB index constraint)
        phone = webapp_record.get('phone', '')
        if phone and phone.strip():
            merged_data['phone'] = phone.strip()
        
        # Update the record with new customer ID
        table.put_item(Item=merged_data)
        print(f"✅ Updated webapp record {old_customer_id} -> {shopify_customer_id}")
        
        # Optionally delete the old webapp record to avoid duplicates
        try:
            table.delete_item(Key={'customer_id': old_customer_id})
            print(f"🗑️ Deleted old webapp record: {old_customer_id}")
        except Exception as delete_error:
            print(f"⚠️ Failed to delete old webapp record: {delete_error}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error finding/updating webapp record: {e}")
        return False


def find_and_update_webapp_record_for_subscription(shopify_customer_id: str, customer_email: str, subscription_data: Dict[str, Any]) -> bool:
    """Find existing webapp record and update it with real Shopify customer ID for subscription"""
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        print(f"🔍 Looking for existing webapp record for subscription: {customer_email}")
        
        # Scan for records with matching email
        response = table.scan(
            FilterExpression="email = :email",
            ExpressionAttributeValues={':email': customer_email},
            Limit=50  # Reasonable limit to avoid long scans
        )
        
        webapp_records = [item for item in response.get('Items', []) 
                         if str(item.get('customer_id', '')).startswith('webapp_')]
        
        if not webapp_records:
            print(f"ℹ️ No webapp records found for subscription email: {customer_email}")
            return False
        
        # Find the most recent webapp record
        webapp_record = max(webapp_records, key=lambda x: x.get('created_at', ''))
        old_customer_id = webapp_record.get('customer_id')
        
        print(f"✅ Found webapp record for subscription: {old_customer_id}")
        
        # Merge the data from both records
        merged_data = {
            'customer_id': shopify_customer_id,  # Update to real Shopify customer ID
            'email': customer_email,
            'subscription_status': 'active',
            'event_type': 'subscription_created',
            'last_updated': datetime.now().isoformat(),
            'shopify_data': convert_floats_to_decimal(subscription_data),
            # Preserve existing data from webapp record
            'commitment_data': webapp_record.get('commitment_data', {}),
            'utm_data': webapp_record.get('utm_data', {}),
            'country_code': webapp_record.get('country_code', ''),
            'variant_gid': webapp_record.get('variant_gid', ''),
            'selling_plan_id': webapp_record.get('selling_plan_id', ''),
            'checkout_url': webapp_record.get('checkout_url', ''),
            'status': 'subscription_active',  # Update status
            'created_at': webapp_record.get('created_at', datetime.now().isoformat())
        }
        
        # Only add phone if it exists and is not empty (DynamoDB index constraint)
        phone = webapp_record.get('phone', '')
        if phone and phone.strip():
            merged_data['phone'] = phone.strip()
        
        # Update the record with new customer ID
        table.put_item(Item=merged_data)
        print(f"✅ Updated webapp record for subscription {old_customer_id} -> {shopify_customer_id}")
        
        # Delete the old webapp record to avoid duplicates
        try:
            table.delete_item(Key={'customer_id': old_customer_id})
            print(f"🗑️ Deleted old webapp record: {old_customer_id}")
        except Exception as delete_error:
            print(f"⚠️ Failed to delete old webapp record: {delete_error}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error finding/updating webapp record for subscription: {e}")
        return False


# =============================================================================
# WEBHOOK HANDLERS
# =============================================================================

def handle_subscription_created(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Handle subscription created webhook"""
    customer = payload.get('customer', {})
    customer_id = str(customer.get('id', ''))
    customer_email = customer.get('email', '')
    
    print(f"🎉 Subscription created for: {customer_email}, customer_id: {customer_id}")
    
    # Extract commitment and UTM data from the subscription payload
    commitment_data = payload.get('commitment_data', {})
    
    # Extract UTM data from subscription line items properties
    utm_data = {}
    subscription = payload.get('subscription', {})
    line_items = subscription.get('line_items', [])
    if line_items:
        properties = line_items[0].get('properties', [])
        utm_source = next((p['value'] for p in properties if p['name'] == '_utm_source'), 'unknown')
        utm_campaign = next((p['value'] for p in properties if p['name'] == '_utm_campaign'), 'unknown')
        utm_clickid = next((p['value'] for p in properties if p['name'] == '_utm_clickid'), 'none')
        
        utm_data = {
            'utm_source': utm_source,
            'utm_campaign': utm_campaign,
            'utm_clickid': utm_clickid
        }
    
    # Extract phone from subscription line items properties
    phone = ''
    if line_items:
        properties = line_items[0].get('properties', [])
        phone = next((p['value'] for p in properties if p['name'] == 'WhatsApp'), '')
    
    print(f"📊 Extracted from subscription webhook - commitment_data: {bool(commitment_data)}, utm_data: {bool(utm_data)}, phone: {bool(phone)}")
    
    # Simply update/create record with customer ID from payload
    success = update_subscriber(
        customer_id=customer_id,
        email=customer_email, 
        status='active',
        event_type='subscription_created',
        data=payload,
        commitment_data=commitment_data,
        utm_data=utm_data,
        phone=phone
    )
    
    if success:
        return json_resp({"success": True, "customer_id": customer_id})
    else:
        return json_resp({"error": "Failed to update subscriber"}, 500)


def handle_subscription_cancelled(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Handle subscription cancelled webhook"""
    customer = payload.get('customer', {})
    customer_id = str(customer.get('id', ''))
    customer_email = customer.get('email', '')
    
    print(f"❌ Subscription cancelled for: {customer_email}")
    
    success = update_subscriber(
        customer_id=customer_id,
        email=customer_email,
        status='cancelled', 
        event_type='subscription_cancelled',
        data=payload
    )
    
    if success:
        return json_resp({"success": True, "customer_id": customer_id})
    else:
        return json_resp({"error": "Failed to update subscriber"}, 500)

def handle_subscription_billing(payload: Dict[str, Any], topic: str) -> Dict[str, Any]:
    """Handle subscription billing webhooks (success/failure)"""
    customer = payload.get('customer', {})
    customer_id = str(customer.get('id', ''))
    customer_email = customer.get('email', '')
    
    status = 'billing_success' if 'success' in topic else 'billing_failure'
    print(f"💳 Subscription billing {status} for: {customer_email}")
    
    success = update_subscriber(
        customer_id=customer_id,
        email=customer_email,
        status=status, 
        event_type=topic.replace('/', '_'),
        data=payload
    )
    
    if success:
        return json_resp({"success": True, "customer_id": customer_id})
    else:
        return json_resp({"error": "Failed to update subscriber"}, 500)


def handle_order_created(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Handle order created webhook from Shopify Flow"""
    customer = payload.get('customer', {})
    if not customer:
        return json_resp({"success": True, "message": "No customer in order"})
        
    customer_id = str(customer.get('id', ''))
    customer_email = customer.get('email', '')
    
    print(f"🛒 Order created for: {customer_email}, customer_id: {customer_id}")
    
    # Extract commitment and UTM data from the order payload
    commitment_data = payload.get('commitment_data', {})
    
    # Extract UTM data from line items properties
    utm_data = {}
    order = payload.get('order', {})
    line_items = order.get('line_items', [])
    if line_items:
        properties = line_items[0].get('properties', [])
        utm_source = next((p['value'] for p in properties if p['name'] == '_utm_source'), 'unknown')
        utm_campaign = next((p['value'] for p in properties if p['name'] == '_utm_campaign'), 'unknown')
        utm_clickid = next((p['value'] for p in properties if p['name'] == '_utm_clickid'), 'none')
        
        utm_data = {
            'utm_source': utm_source,
            'utm_campaign': utm_campaign,
            'utm_clickid': utm_clickid
        }
    
    # Extract phone from line items properties
    phone = ''
    if line_items:
        properties = line_items[0].get('properties', [])
        phone = next((p['value'] for p in properties if p['name'] == 'WhatsApp'), '')
    
    print(f"📊 Extracted from webhook - commitment_data: {bool(commitment_data)}, utm_data: {bool(utm_data)}, phone: {bool(phone)}")
    
    # Simply update/create record with customer ID from payload
    success = update_subscriber(
        customer_id=customer_id,
        email=customer_email,
        status='active',
        event_type='order_created', 
        data=payload,
        commitment_data=commitment_data,
        utm_data=utm_data,
        phone=phone
    )
    
    if success:
        return json_resp({"success": True, "customer_id": customer_id})
    else:
        return json_resp({"error": "Failed to update subscriber"}, 500)


# =============================================================================
# COMMITMENT WIDGET
# =============================================================================

def evaluate_only(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluate commitment form using OpenAI - frontend version"""
    try:
        
        q1 = str(payload.get('q1', '')).strip()
        q2 = str(payload.get('q2', '')).strip()
        q3 = str(payload.get('q3', '')).strip()
        
        if not all([q1, q2, q3]):
            return json_resp({"ok": False, "error": "q1, q2, q3 are required"}, 400)
            
        # Get OpenAI API key from environment or AWS Secrets Manager
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            # Try to get from AWS Secrets Manager if configured
            secret_name = os.environ.get('OPENAI_SECRET_NAME', 'CHATGPT_API_KEY')
            try:
                import boto3
                secrets_client = boto3.client('secretsmanager')
                response = secrets_client.get_secret_value(SecretId=secret_name)
                secret_data = json.loads(response['SecretString'])
                api_key = secret_data.get('CHATGPT_API_KEY')
            except Exception as secret_error:
                print(f"Failed to get OpenAI key from secrets: {secret_error}")
                # Fallback to environment variable
                api_key = os.environ.get('OPENAI_SECRET_KEY')
        
        if not api_key:
            return json_resp({"ok": False, "error": "OpenAI API key not configured"}, 500)
            
        # Make direct HTTP request to OpenAI API
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        prompt = f"""
        Evaluate this person's commitment to digital wellness and determine if they are passionate about change:
        
        What they want to quit: {q1}
        Why they want to change: {q2}
        Who they're doing it for: {q3}
        
        Respond with a JSON object containing:
        - "is_passionate": boolean (true if they show strong commitment)
        - "feedback": string (encouraging feedback message)
        - "surrender_text": string (personalized surrender statement they should repeat)
        """
        
        data = {
            "model": os.environ.get('OPENAI_MODEL', 'gpt-4o-mini'),
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.7
        }
        
        response = requests.post('https://api.openai.com/v1/chat/completions', 
                               headers=headers, json=data)
        response.raise_for_status()
        
        result = json.loads(response.json()['choices'][0]['message']['content'])
        return json_resp({
            "ok": True,
            "is_passionate": bool(result.get("is_passionate", False)),
            "feedback": result.get("feedback", ""),
            "surrender_text": result.get("surrender_text", "")
        })
            
    except Exception as e:
        print(f"❌ OpenAI evaluation error: {e}")
        # Return a fallback response that matches the expected format
        # This ensures the widget doesn't break even if OpenAI is unavailable
        fallback_response = {
            "ok": True,
            "is_passionate": True,  # Default to allowing progression
            "feedback": "Thank you for your commitment! We're evaluating your responses and you can continue with your digital wellness journey.",
            "surrender_text": f"I surrender my {q1} habits and commit to positive change for {q3}."
        }
        print(f"🔄 Using fallback response due to OpenAI error: {e}")
        return json_resp(fallback_response)

def evaluate_commitment(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluate commitment form using OpenAI"""
    try:
        
        q1 = payload.get('q1', '')
        q2 = payload.get('q2', '')
        q3 = payload.get('q3', '')
        
        if not all([q1, q2, q3]):
            return json_resp({"error": "Missing required fields"}, 400)
            
        # Get OpenAI API key from environment or AWS Secrets Manager
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            # Try to get from AWS Secrets Manager if configured
            secret_name = os.environ.get('OPENAI_SECRET_NAME', 'CHATGPT_API_KEY')
            try:
                import boto3
                secrets_client = boto3.client('secretsmanager')
                response = secrets_client.get_secret_value(SecretId=secret_name)
                secret_data = json.loads(response['SecretString'])
                api_key = secret_data.get('CHATGPT_API_KEY')
            except Exception as secret_error:
                print(f"Failed to get OpenAI key from secrets: {secret_error}")
                # Fallback to environment variable
                api_key = os.environ.get('OPENAI_SECRET_KEY')
        
        if not api_key:
            return json_resp({"error": "OpenAI API key not configured"}, 500)
            
        # Make direct HTTP request to OpenAI API
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        prompt = f"""
        Evaluate this person's commitment to digital wellness:
        
        What they want to quit: {q1}
        Why they want to change: {q2}
        Who they're doing it for: {q3}
        
        Respond with a JSON object containing:
        - "commitment_score": number 1-10
        - "personalized_message": encouraging message
        - "recommended_plan": "basic" or "premium"
        """
        
        data = {
            "model": os.environ.get('OPENAI_MODEL', 'gpt-4o-mini'),
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
            "temperature": 0.7
        }
        
        response = requests.post('https://api.openai.com/v1/chat/completions', 
                               headers=headers, json=data)
        response.raise_for_status()
        
        result = json.loads(response.json()['choices'][0]['message']['content'])
        return json_resp({
            "success": True,
            "evaluation": result,
            "next_step": "collect_contact"
        })
            
    except Exception as e:
        print(f"❌ OpenAI evaluation error: {e}")
        return json_resp({"error": "Evaluation failed"}, 500)


def create_checkout(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Create Shopify checkout"""
    try:
        phone = payload.get('phone', '')
        commitment_data = payload.get('commitment_form', {})
        
        if not phone or not commitment_data:
            return json_resp({"error": "Missing phone or commitment data"}, 400)
            
        # Simple checkout URL - customize as needed
        variant_id = "49692077785335"  # Your product variant ID
        checkout_url = f"https://xpvznx-9w.myshopify.com/cart/{variant_id}:1"
        
        return json_resp({
            "success": True,
            "checkout_url": checkout_url,
            "message": "Checkout created successfully"
        })
        
    except Exception as e:
        print(f"❌ Error creating checkout: {e}")
        return json_resp({"error": "Failed to create checkout"}, 500)

def create_webapp_checkout(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Create Shopify checkout for webapp flow"""
    try:
        # Extract data from frontend payload
        q1 = payload.get('q1', '')
        q2 = payload.get('q2', '')
        q3 = payload.get('q3', '')
        gender = payload.get('gender', '')
        phone = payload.get('phone', '')
        country_code = payload.get('country_code', 'US')
        surrender_text = payload.get('surrender_text', '')
        variant_gid = payload.get('variantGID', '')
        selling_plan_id = payload.get('sellingPlanId', '')
        
        # UTM parameters
        utm_source = payload.get('utm_source', 'direct')
        utm_campaign = payload.get('utm_campaign', 'organic')
        utm_clickid = payload.get('utm_clickid', 'none')
        
        print(f"🛒 Creating checkout for: gender={gender}, country={country_code}")
        print(f"📊 UTM: source={utm_source}, campaign={utm_campaign}, clickid={utm_clickid}")
        
        # Validate required fields
        if not all([q1, q2, q3, gender]):
            return json_resp({"ok": False, "error": "Missing required commitment data"}, 400)
        
        # Prepare commitment form data
        commitment_form_data = {
            'q1': q1, 'q2': q2, 'q3': q3,
            'surrender_text': surrender_text
        }
        
        # Use the enhanced GraphQL cart creation
        print(f"🛒 Creating GraphQL checkout for: {gender}, variant: {variant_gid}")
        ok, checkout_url, err = shopify_cart_create_enhanced(
            variant_gid=variant_gid,
            selling_plan_id=selling_plan_id,
            whatsapp=phone,
            commitment_form_data=commitment_form_data,
            gender=gender,
            utm_data={
                'utm_source': utm_source,
                'utm_campaign': utm_campaign, 
                'utm_clickid': utm_clickid
            }
        )
        
        if not ok:
            print(f"❌ GraphQL checkout creation failed: {err}")
            return json_resp({"ok": False, "error": err or "checkout_failed"}, 500)
        
        # Optionally store commitment data in DynamoDB for tracking
        try:
            import boto3
            dynamodb = boto3.resource('dynamodb')
            table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
            
            # Store commitment data
            commitment_record = {
                'customer_id': f"webapp_{int(time.time())}",  # Temporary ID until real customer created
                'commitment_data': commitment_form_data,
                'utm_data': {
                    'utm_source': utm_source,
                    'utm_campaign': utm_campaign, 
                    'utm_clickid': utm_clickid
                },
                'country_code': country_code,
                'variant_gid': variant_gid,
                'selling_plan_id': selling_plan_id,
                'status': 'checkout_created',
                'created_at': datetime.now().isoformat(),
                'checkout_url': checkout_url
            }
            
            # Only add phone if it's not empty (DynamoDB index constraint)
            if phone and phone.strip():
                commitment_record['phone'] = phone.strip()
            
            table.put_item(Item=commitment_record)
            print(f"💾 Stored GraphQL checkout data for webapp")
            
        except Exception as db_error:
            print(f"⚠️ Failed to store commitment data: {db_error}")
            # Don't fail the checkout if DB storage fails
        
        return json_resp({
            "ok": True,
            "checkoutUrl": checkout_url,
            "message": "Checkout created successfully"
        })
        
    except Exception as e:
        print(f"❌ Error creating webapp checkout: {e}")
        return json_resp({"ok": False, "error": "Failed to create checkout"}, 500)

def shopify_cart_create_enhanced(variant_gid: str, selling_plan_id: str, whatsapp: str, commitment_form_data: dict, gender: str, utm_data: dict = None) -> Tuple[bool, str, str]:
    """Create Shopify cart with enhanced commitment form data and invisible UTM attributes using GraphQL"""
    storefront_token = get_shopify_storefront_token()
    if not (SHOP_DOMAIN and storefront_token):
        return False, None, "shopify_credentials_missing"

    # Convert commitment form data to JSON string
    commitment_form_json = json.dumps(commitment_form_data)
    
    # Build base attributes (visible and hidden)
    base_attributes = [
        {"key": "WhatsApp", "value": whatsapp.replace("+", "")},  # Visible
        {"key": "gender", "value": gender.capitalize()},  # Visible
        {"key": "_commitment_form", "value": commitment_form_json},  # Hidden
        {"key": "_source", "value": "web"},  # Hidden
    ]
    
    # Add UTM parameters as invisible checkout attributes (prefixed with _)
    if utm_data:
        for utm_key, utm_value in utm_data.items():
            if utm_value and utm_value != "NONE":
                # Store as invisible attribute with _ prefix
                base_attributes.append({"key": f"_{utm_key}", "value": str(utm_value)})
        
        # Also store complete UTM data as JSON for backup
        utm_json = json.dumps(utm_data)
        base_attributes.append({"key": "_utm_data_json", "value": utm_json})

    # Add custom thank you URL for subscriptions BEFORE creating mutation
    if selling_plan_id:
        # Add custom redirect URL as attribute for subscription orders
        base_attributes.append({"key": "_thank_you_redirect", "value": f"https://{SHOP_DOMAIN}/account/extensions/commitment-widget"})

    # Create mutation based on whether selling plan is provided
    if selling_plan_id:
        # With selling plan (subscription)
        mutation = {
            "query": "mutation CreateCart($variantId: ID!, $planId: ID!, $qty: Int!, $attributes: [AttributeInput!]!) { cartCreate(input: { attributes: $attributes, lines: [{ merchandiseId: $variantId, sellingPlanId: $planId, quantity: $qty, attributes: $attributes }] }) { cart { id checkoutUrl lines(first: 10) { edges { node { id quantity merchandise { ... on ProductVariant { id title product { title } } } sellingPlanAllocation { sellingPlan { id name } } } } } cost { totalAmount { amount currencyCode } subtotalAmount { amount currencyCode } } } userErrors { field message } } }",
            "variables": {
                "variantId": variant_gid,
                "planId": selling_plan_id,
                "qty": 1,
                "attributes": base_attributes
            }
        }
    else:
        # Without selling plan (one-time purchase)
        mutation = {
            "query": "mutation CreateCart($variantId: ID!, $qty: Int!, $attributes: [AttributeInput!]!) { cartCreate(input: { attributes: $attributes, lines: [{ merchandiseId: $variantId, quantity: $qty, attributes: $attributes }] }) { cart { id checkoutUrl lines(first: 10) { edges { node { id quantity merchandise { ... on ProductVariant { id title product { title } } } } } } cost { totalAmount { amount currencyCode } subtotalAmount { amount currencyCode } } } userErrors { field message } } }",
            "variables": {
                "variantId": variant_gid,
                "qty": 1,
                "attributes": base_attributes
            }
        }

    try:
        print(f"🛒 Creating GraphQL cart with variant: {variant_gid}, selling plan: {selling_plan_id}")
        response = requests.post(
            f"https://{SHOP_DOMAIN}/api/2025-07/graphql.json",
            json=mutation,
            headers={
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": storefront_token,
            },
            timeout=12
        )
        print(f"📞 Shopify GraphQL response status: {response.status_code}")
        data = response.json()
        print(f"📊 Shopify GraphQL response data: {data}")
    except Exception as e:
        print(f"❌ Shopify GraphQL request error: {e}")
        import traceback
        traceback.print_exc()
        return False, None, f"shopify_request_failed: {str(e)}"

    # Check for user errors first
    user_errors = data.get("data", {}).get("cartCreate", {}).get("userErrors", [])
    if user_errors:
        error_msgs = ", ".join(m.get("message", "") for m in user_errors)
        print(f"❌ Shopify GraphQL user errors: {error_msgs}")
        return False, None, error_msgs
    
    # Get cart data safely
    cart_data = data.get("data", {}).get("cartCreate", {}).get("cart")
    if not cart_data:
        print(f"❌ No cart data returned from Shopify GraphQL")
        return False, None, "no_cart_data_returned"
    
    checkout_url = cart_data.get("checkoutUrl")
    if checkout_url:
        print(f"✅ GraphQL checkout URL obtained: {checkout_url}")
        return True, checkout_url, None

    print(f"❌ No checkout URL in GraphQL cart data")
    return False, None, "no_checkout_url"


# =============================================================================
# APP PROXY
# =============================================================================

def verify_app_proxy_signature(query_params: Dict[str, Any]) -> bool:
    """
    Verify Shopify App Proxy signature (not HMAC)
    App Proxy uses 'signature' parameter with concatenated sorted key=value pairs (no & between them)
    https://shopify.dev/docs/apps/app-extensions/app-proxy#verify-proxy-requests
    """
    try:
        app_proxy_secret = os.environ.get('SHOPIFY_API_SECRET', '')
        if not app_proxy_secret:
            print("❌ No SHOPIFY_API_SECRET found for app proxy verification")
            return False
            
        # Extract signature
        signature = query_params.get('signature')
        if not signature:
            print("❌ No signature found in App Proxy request")
            return False

        # Remove signature from params for verification
        params_copy = query_params.copy()
        del params_copy['signature']
        
        # Sort parameters and concatenate key=value pairs (NO & between them)
        sorted_params = sorted(params_copy.items())
        message = ''.join([f"{k}={v}" for k, v in sorted_params])
        
        # Calculate expected signature using HMAC-SHA256, hex digest
        expected_signature = hmac.new(
            app_proxy_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        # Compare signatures (constant time comparison)
        is_valid = hmac.compare_digest(signature, expected_signature)
        
        if is_valid:
            print("✅ App Proxy HMAC signature verified")
        else:
            print(f"❌ Invalid App Proxy signature. Expected: {expected_signature}, Got: {signature}")
            print(f"Query string used: {query_string}")
        
        return is_valid
        
    except Exception as e:
        print(f"❌ Error verifying App Proxy signature: {e}")
        return False

def check_customer_entitlement(customer_id: str) -> Dict[str, Any]:
    """
    Check if customer has active entitlement in DynamoDB
    """
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Query stj_subscribers table
        response = table.get_item(Key={'customer_id': customer_id})
        
        if 'Item' not in response:
            print(f"❌ Customer {customer_id} not found in subscribers table")
            return {'has_access': False, 'reason': 'customer_not_found'}
        
        customer_data = response['Item']
        subscription_status = customer_data.get('subscription_status', 'inactive')
        
        if subscription_status == 'active':
            print(f"✅ Customer {customer_id} has active entitlement")
            
            # Check if profile is complete (username and gender required)
            username = customer_data.get('username', '')
            gender = customer_data.get('gender', '')
            
            profile_complete = bool(username and gender)
            print(f"👤 Profile completeness check - username: {bool(username)}, gender: {bool(gender)}")
            
            return {
                'has_access': True,
                'customer_data': customer_data,
                'subscription_status': subscription_status,
                'profile_complete': profile_complete
            }
        else:
            print(f"❌ Customer {customer_id} has inactive subscription: {subscription_status}")
            return {'has_access': False, 'reason': 'subscription_inactive', 'status': subscription_status}
            
    except Exception as e:
        print(f"❌ Error checking customer entitlement: {e}")
        return {'has_access': False, 'reason': 'database_error'}

def render_account_wall_page(reason: str, shop_domain: str) -> Dict[str, Any]:
    """
    Render the account wall page for customers without active subscriptions
    """
    # Map reasons to user-friendly messages and actions
    reason_config = {
        'customer_not_found': {
            'icon': '🔒',
            'title': 'Subscription Required',
            'message': 'You need an active subscription to access the Screen Time Journey dashboard.',
            'button_text': 'Get Subscription',
            'button_url': f'https://{shop_domain}/products/screen-time-journey'
        },
        'subscription_inactive': {
            'icon': '⏸️',
            'title': 'Subscription Inactive',
            'message': 'Your Screen Time Journey subscription is currently inactive. Please renew to continue your journey.',
            'button_text': 'Renew Subscription',
            'button_url': f'https://{shop_domain}/products/screen-time-journey'
        },
        'database_error': {
            'icon': '⚠️',
            'title': 'Unable to Verify Access',
            'message': 'We\'re having trouble verifying your subscription status. Please try again in a moment.',
            'button_text': 'Try Again',
            'button_url': f'https://{shop_domain}/apps/screen-time-journey'
        }
    }
    
    config = reason_config.get(reason, reason_config['customer_not_found'])
    
    html = f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Screen Time Journey - {config['title']}</title>
        <style>
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}
            
            body {{
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }}
            
            .container {{
                max-width: 480px;
                width: 100%;
                background: white;
                border-radius: 16px;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
                padding: 40px;
                text-align: center;
            }}
            
            .icon {{
                font-size: 72px;
                margin-bottom: 24px;
                display: block;
            }}
            
            h1 {{
                color: #1a1a1a;
                font-size: 28px;
                font-weight: 600;
                margin-bottom: 16px;
                line-height: 1.3;
            }}
            
            .message {{
                color: #666;
                font-size: 16px;
                line-height: 1.5;
                margin-bottom: 32px;
            }}
            
            .btn {{
                background: #007cba;
                color: white;
                padding: 14px 28px;
                font-size: 16px;
                font-weight: 500;
                text-decoration: none;
                border-radius: 8px;
                display: inline-block;
                transition: all 0.2s ease;
                margin-bottom: 16px;
            }}
            
            .btn:hover {{
                background: #005a8b;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(0, 124, 186, 0.3);
            }}
            
            .secondary-link {{
                color: #999;
                text-decoration: none;
                font-size: 14px;
                display: block;
                margin-top: 16px;
            }}
            
            .secondary-link:hover {{
                color: #666;
            }}
            
            .feature-list {{
                text-align: left;
                margin: 24px 0;
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
            }}
            
            .feature-list h3 {{
                color: #333;
                font-size: 16px;
                margin-bottom: 12px;
                text-align: center;
            }}
            
            .feature-list ul {{
                list-style: none;
                color: #666;
            }}
            
            .feature-list li {{
                padding: 4px 0;
                position: relative;
                padding-left: 20px;
            }}
            
            .feature-list li:before {{
                content: "✓";
                color: #007cba;
                font-weight: bold;
                position: absolute;
                left: 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="icon">{config['icon']}</div>
            <h1>{config['title']}</h1>
            <p class="message">{config['message']}</p>
            
            <div class="feature-list">
                <h3>What You'll Get:</h3>
                <ul>
                    <li>Daily screen time tracking</li>
                    <li>Personal progress dashboard</li>
                    <li>AI-powered commitment validation</li>
                    <li>WhatsApp accountability reminders</li>
                    <li>Journey milestones and achievements</li>
                </ul>
            </div>
            
            <a href="{config['button_url']}" class="btn">{config['button_text']}</a>
            <a href="https://{shop_domain}" class="secondary-link">← Back to Store</a>
        </div>
    </body>
    </html>
    '''
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'no-store'
        },
        'body': html
    }

def create_jwt_token(customer_data: Dict[str, Any], shop_domain: str) -> str:
    """
    Create JWT token for customer session on app.screentimejourney.com
    """
    if not JWT_AVAILABLE:
        print("⚠️ JWT library not available - returning simple token")
        # Return a simple base64 encoded token as fallback
        import base64
        simple_token = base64.b64encode(f"customer_{customer_data['customer_id']}".encode()).decode()
        return simple_token
        
    try:
        jwt_secret = os.environ.get('JWT_SECRET', 'your-super-secret-jwt-key-change-this')
        
        # Token payload
        payload = {
            'customer_id': customer_data['customer_id'],
            'email': customer_data.get('email', ''),
            'subscription_status': customer_data.get('subscription_status', 'active'),
            'shop': shop_domain,
            'iat': int(time.time()),
            'exp': int(time.time()) + (24 * 60 * 60),  # 24 hours
            'iss': 'screen-time-journey-app',
            'aud': 'app.screentimejourney.com'
        }
        
        # Create JWT token
        token = jwt.encode(payload, jwt_secret, algorithm='HS256')
        print(f"✅ Created JWT token for customer {customer_data['customer_id']}")
        
        return token
        
    except Exception as e:
        print(f"❌ Error creating JWT token: {e}")
        return None

def handle_app_proxy(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle App Proxy requests from Shopify storefront"""
    try:
        query_params = event.get('queryStringParameters', {}) or {}
        
        # Log incoming request (redact signature for security)
        qs_redacted = {k: v for k, v in query_params.items() if k != 'signature'}
        print(f"📥 App Proxy request QS: {qs_redacted}")
        
        # 1. Verify signature for security
        if not verify_app_proxy_signature(query_params):
            print("🔒 BRANCH: INVALID_SIGNATURE")
            return {
                'statusCode': 401,
                'headers': {'Content-Type': 'text/plain'},
                'body': 'Invalid signature'
            }
        
        # 2. Extract customer information
        customer_id = query_params.get('logged_in_customer_id')
        shop_domain = query_params.get('shop', '')
        
        if not customer_id:
            # Redirect to Shopify login
            login_url = f"https://{shop_domain}/account/login?return_url=/apps/screen-time-journey"
            print(f"🔑 BRANCH: LOGIN_REDIRECT")
            print(f"📤 Location: {login_url}")
            
            return {
                'statusCode': 302,
                'headers': {
                    'Location': login_url,
                    'Cache-Control': 'no-store'
                },
                'body': 'Redirecting to login...'
            }
        
        # 3. Check customer entitlement (ACCOUNT WALL)
        entitlement_check = check_customer_entitlement(customer_id)
        if not entitlement_check['has_access']:
            print(f"🚫 BRANCH: NO_ACCESS - Reason: {entitlement_check.get('reason', 'unknown')}")
            return render_account_wall_page(entitlement_check.get('reason', 'unknown'), shop_domain)
        
        print(f"✅ Customer {customer_id} has active entitlement - proceeding to dashboard")
        
        # Get customer data and profile status
        customer_data = entitlement_check['customer_data']
        profile_complete = entitlement_check.get('profile_complete', False)
        
        # 4. Create one-time, short-lived token
        app_base_url = os.environ.get('APP_BASE_URL', 'https://d1603y70syq9xl.amplifyapp.com')
        token_ttl = int(os.environ.get('TOKEN_TTL_SECONDS', '120'))  # 2 minutes
        
        # Create enhanced token: shop|cid|iat|ttl|profile_complete|sig
        iat = int(time.time())
        profile_flag = "1" if profile_complete else "0"
        payload = f"{shop_domain}|{customer_id}|{iat}|{token_ttl}|{profile_flag}"
        
        # Sign with SHOPIFY_API_SECRET
        secret = os.environ.get('SHOPIFY_API_SECRET', '')
        signature = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        token = f"{payload}|{signature}"
        
        # Encode for URL safety
        import base64
        safe_token = base64.urlsafe_b64encode(token.encode()).decode()
        
        # 5. Redirect to main dashboard (now in index.html)
        dashboard_url = f"{app_base_url}/?shop={urllib.parse.quote(shop_domain)}&cid={urllib.parse.quote(customer_id)}&token={urllib.parse.quote(safe_token)}"
        
        print(f"🚀 BRANCH: DASHBOARD_REDIRECT")
        print(f"📤 Location: {dashboard_url}")
        
        return {
            'statusCode': 302,
            'headers': {
                'Location': dashboard_url,
                'Cache-Control': 'no-store'
            },
            'body': 'Redirecting to dashboard...'
        }
        
    except Exception as e:
        print(f"❌ App Proxy error: {e}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'text/html'},
            'body': '<h1>Error</h1><p>Something went wrong</p>'
        }

def handle_jwt_verification(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle JWT verification for app.screentimejourney.com
    This endpoint will be called from your frontend to verify tokens
    """
    try:
        query_params = event.get('queryStringParameters', {}) or {}
        body = parse_body(event)
        
        # Token can come from query params or POST body
        token = query_params.get('token') or body.get('token')
        
        if not token:
            return json_resp({'error': 'No token provided'}, 400)
        
        jwt_secret = os.environ.get('JWT_SECRET', 'your-super-secret-jwt-key-change-this')
        
        # Verify JWT token
        if not JWT_AVAILABLE:
            print("⚠️ JWT library not available - using simple verification")
            # Simple base64 verification for fallback
            import base64
            try:
                decoded = base64.b64decode(token).decode()
                if decoded.startswith('customer_'):
                    customer_id = decoded.replace('customer_', '')
                    entitlement_check = check_customer_entitlement(customer_id)
                    if entitlement_check['has_access']:
                        return json_resp({
                            'valid': True,
                            'customer_id': customer_id,
                            'email': '',
                            'subscription_status': 'active',
                            'shop': ''
                        })
            except Exception:
                pass
            return json_resp({'error': 'Invalid token'}, 401)
        
        try:
            payload = jwt.decode(
                token, 
                jwt_secret, 
                algorithms=['HS256'],
                audience='app.screentimejourney.com',
                issuer='screen-time-journey-app'
            )
            
            print(f"✅ Valid JWT token for customer {payload.get('customer_id')}")
            
            # Re-verify customer entitlement for extra security
            entitlement_check = check_customer_entitlement(payload['customer_id'])
            if not entitlement_check['has_access']:
                return json_resp({'error': 'Access revoked'}, 403)
            
            return json_resp({
                'valid': True,
                'customer_id': payload['customer_id'],
                'email': payload['email'],
                'subscription_status': payload['subscription_status'],
                'shop': payload['shop']
            })
            
        except Exception as e:
            if JWT_AVAILABLE:
                if 'ExpiredSignatureError' in str(type(e)):
                    print("❌ JWT token has expired")
                    return json_resp({'error': 'Token expired'}, 401)
                else:
                    print(f"❌ Invalid JWT token: {e}")
                    return json_resp({'error': 'Invalid token'}, 401)
            else:
                print(f"❌ Token verification error: {e}")
                return json_resp({'error': 'Invalid token'}, 401)
            
    except Exception as e:
        print(f"❌ Error verifying JWT: {e}")
        return json_resp({'error': 'Internal server error'}, 500)


# =============================================================================
# SQS EVENT HANDLER (from EventBridge)
# =============================================================================

def handle_sqs_events(event, context):
    """Handle SQS events from EventBridge containing Shopify webhooks"""
    try:
        results = []
        
        for record in event.get("Records", []):
            # Extract the EventBridge event from SQS message
            message_body = json.loads(record["body"])
            print(f"📦 Processing SQS record: {json.dumps(message_body, default=str)}")
            
            # Extract Shopify webhook data from EventBridge event
            detail = message_body.get("detail", {})
            topic = detail.get("topic", "")
            payload = detail.get("payload", {})
            
            print(f"🎯 EventBridge webhook topic: {topic}")
            
            # Route to appropriate handler based on topic
            if topic == "subscription_contracts/create":
                result = handle_subscription_created(payload)
                results.append(result)
            elif topic == "subscription_contracts/cancel":
                result = handle_subscription_cancelled(payload)
                results.append(result)
            elif topic == "orders/create":
                result = handle_order_created(payload)
                results.append(result)
            elif topic in ["subscription_billing_attempts/success", "subscription_billing_attempts/failure"]:
                result = handle_subscription_billing(payload, topic)
                results.append(result)
            else:
                print(f"⚠️ Unknown EventBridge webhook topic: {topic}")
                results.append({"statusCode": 200, "body": json.dumps({"message": f"Unknown topic: {topic}"})})
        
        # Return success for all processed records
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": f"Processed {len(results)} SQS records successfully",
                "results": results
            })
        }
        
    except Exception as e:
        print(f"❌ SQS event processing error: {e}")
        import traceback
        traceback.print_exc()
        # For SQS, we should raise the exception to trigger retry/DLQ
        raise e


# =============================================================================
# FRONTEND API ENDPOINTS
# =============================================================================

def get_milestones(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get milestone data for journey progress"""
    try:
        gender = payload.get('gender', 'male')
        
        # TODO: In production, these should come from a database
        # For now, return the static milestone data
        milestones = [
            {
                "gene": "male",
                "level": 0,
                "days_range": "0",
                "title": "Ground Zero",
                "emoji": "🪨",
                "description": "Every journey starts from the ground. You've chosen to rise from where you stand.",
                "milestone_day": 0,
                "media_url": "https://wati-files.s3.eu-north-1.amazonaws.com/male_level_0_groundzero.jpg",
                "next_level_title": "Fighter",
                "next_level_emoji": "🥊",
                "days_to_next": 7,
                "level_template": ""
            },
            {
                "gene": "male",
                "level": 1,
                "days_range": "7–14",
                "title": "Fighter",
                "emoji": "🥊",
                "description": "You've stepped into the fight. Each day you stay the course, your strength builds silently.",
                "milestone_day": 14,
                "media_url": "https://wati-files.s3.eu-north-1.amazonaws.com/male_level_1_fighter.jpg",
                "next_level_title": "King",
                "next_level_emoji": "👑",
                "days_to_next": 351,
                "level_template": "m1"
            },
            {
                "gene": "male",
                "level": 10,
                "days_range": "365+",
                "title": "King",
                "emoji": "👑",
                "description": "You've walked the path fully. Quiet strength and clarity mark the way you stand today.",
                "milestone_day": 365,
                "media_url": "https://wati-files.s3.eu-north-1.amazonaws.com/male_level_10_theking.jpg",
                "next_level_title": None,
                "next_level_emoji": None,
                "days_to_next": None,
                "level_template": "m10"
            }
        ]
        
        # Filter by gender if specified
        filtered_milestones = [m for m in milestones if m['gene'] == gender]
        
        print(f"✅ Returning {len(filtered_milestones)} milestones for gender: {gender}")
        
        return json_resp({
            'success': True,
            'milestones': filtered_milestones
        })
        
    except Exception as e:
        print(f"❌ Error getting milestones: {e}")
        return json_resp({'error': 'Failed to get milestones'}, 500)


def get_system_config(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get system configuration (device flows, etc.)"""
    try:
        config_key = payload.get('config_key', '')
        
        # Mock device flow configurations
        configs = {
            'device_setup_flow': {
                'flow_name': 'Device Setup Flow',
                'total_steps': 4,
                'steps': [
                    {
                        'step': 1,
                        'title': 'Device Information',
                        'description': 'Select your device type and provide details',
                        'required_fields': ['device_type', 'device_name']
                    },
                    {
                        'step': 2,
                        'title': 'Generate Pincode',
                        'description': 'Create a secure pincode for device access',
                        'action': 'generate_pincode'
                    },
                    {
                        'step': 3,
                        'title': 'Setup Profile',
                        'description': 'Configure your device protection profile',
                        'action': 'generate_vpn_profile'
                    },
                    {
                        'step': 4,
                        'title': 'Audio Guide',
                        'description': 'Get your personalized audio guide',
                        'action': 'generate_audio'
                    }
                ]
            },
            'device_unlock_flow': {
                'flow_name': 'Device Unlock Flow',
                'total_steps': 3,
                'steps': [
                    {
                        'step': 1,
                        'title': 'Record Surrender',
                        'description': 'Record your surrender message',
                        'required_fields': ['audio_recording']
                    },
                    {
                        'step': 2,
                        'title': 'AI Validation',
                        'description': 'AI validates your surrender',
                        'action': 'validate_surrender'
                    },
                    {
                        'step': 3,
                        'title': 'Unlock Code',
                        'description': 'Receive your unlock code',
                        'action': 'generate_unlock_code'
                    }
                ]
            }
        }
        
        if config_key and config_key in configs:
            print(f"✅ Returning config for: {config_key}")
            return json_resp({
                'success': True,
                'data': configs[config_key]
            })
        elif config_key:
            print(f"❌ Config key not found: {config_key}")
            return json_resp({'error': 'Configuration not found'}, 404)
        else:
            print(f"✅ Returning all configs")
            return json_resp({
                'success': True,
                'data': configs
            })
            
    except Exception as e:
        print(f"❌ Error getting system config: {e}")
        return json_resp({'error': 'Failed to get configuration'}, 500)


def store_pincode(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Store generated pincode in database"""
    try:
        pincode = payload.get('pincode')
        uuid = payload.get('uuid')
        device_type = payload.get('device_type')
        device_name = payload.get('device_name')
        user_id = payload.get('user_id')
        
        if not all([pincode, uuid, device_type, user_id]):
            return json_resp({'error': 'Missing required fields'}, 400)
        
        # Store in DynamoDB (stj_passwords table)
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('PASSWORDS_TABLE', 'stj_passwords'))
        
        item = {
            'pincode': pincode,
            'uuid': uuid,
            'device_type': device_type,
            'device_name': device_name,
            'user_id': user_id,
            'created_at': datetime.now().isoformat(),
            'status': 'active',
            'expires_at': (datetime.now() + timedelta(days=365)).isoformat()  # 1 year expiry
        }
        
        table.put_item(Item=item)
        
        print(f"✅ Stored pincode for user {user_id}, device {device_name}")
        
        return json_resp({
            'success': True,
            'message': 'Pincode stored successfully',
            'pincode': pincode,
            'uuid': uuid
        })
        
    except Exception as e:
        print(f"❌ Error storing pincode: {e}")
        return json_resp({'error': 'Failed to store pincode'}, 500)


def generate_vpn_profile(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Generate VPN configuration profile"""
    try:
        device_type = payload.get('device_type')
        device_name = payload.get('device_name')
        
        if not device_type:
            return json_resp({'error': 'Device type is required'}, 400)
        
        # Generate mock VPN profile data
        if device_type.lower() == 'ios':
            profile_data = {
                'profile_type': 'iOS Configuration Profile',
                'filename': f"ScreenTimeJourney_{device_name.replace(' ', '_')}.mobileconfig",
                'download_url': 'https://example.com/profiles/ios_profile.mobileconfig',
                'installation_instructions': [
                    'Download the profile to your device',
                    'Go to Settings > General > VPN & Device Management',
                    'Tap on the downloaded profile',
                    'Follow the installation prompts'
                ]
            }
        elif device_type.lower() == 'android':
            profile_data = {
                'profile_type': 'Android VPN Profile',
                'filename': f"ScreenTimeJourney_{device_name.replace(' ', '_')}.ovpn",
                'download_url': 'https://example.com/profiles/android_profile.ovpn',
                'installation_instructions': [
                    'Download OpenVPN Connect from Play Store',
                    'Download the profile file',
                    'Import the profile in OpenVPN Connect',
                    'Connect to the VPN'
                ]
            }
        else:
            profile_data = {
                'profile_type': 'Generic VPN Profile',
                'filename': f"ScreenTimeJourney_{device_name.replace(' ', '_')}.conf",
                'download_url': 'https://example.com/profiles/generic_profile.conf',
                'installation_instructions': [
                    'Download the configuration file',
                    'Import into your VPN client',
                    'Configure according to device specifications'
                ]
            }
        
        print(f"✅ Generated VPN profile for {device_type} device: {device_name}")
        
        return json_resp({
            'success': True,
            'profileData': profile_data
        })
        
    except Exception as e:
        print(f"❌ Error generating VPN profile: {e}")
        return json_resp({'error': 'Failed to generate VPN profile'}, 500)


def generate_audio_guide(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Generate personalized audio guide"""
    try:
        device_type = payload.get('device_type')
        device_name = payload.get('device_name')
        user_id = payload.get('user_id')
        pincode = payload.get('pincode')
        
        if not all([device_type, user_id, pincode]):
            return json_resp({'error': 'Missing required fields'}, 400)
        
        # Mock audio generation (in production, would use OpenAI TTS)
        audio_data = {
            'audioUrl': f'https://example.com/audio/{user_id}_{pincode}.mp3',
            'duration': '45 seconds',
            'transcript': f"Welcome to Screen Time Journey. Your {device_name} is now protected. Your unlock code is {pincode}. Remember, every moment of focus counts on your journey to digital wellness.",
            'pincode': pincode,
            'generated_at': datetime.now().isoformat()
        }
        
        print(f"✅ Generated audio guide for user {user_id}, device {device_name}")
        
        return json_resp({
            'success': True,
            'audioData': audio_data
        })
        
    except Exception as e:
        print(f"❌ Error generating audio guide: {e}")
        return json_resp({'error': 'Failed to generate audio guide'}, 500)


def validate_surrender(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Validate surrender recording using AI"""
    try:
        # In production, this would process the audio file and validate with OpenAI
        # For now, return mock validation
        
        # Mock AI validation (in production, would analyze audio)
        is_approved = True  # Mock approval
        unlock_pincode = str(random.randint(1000, 9999))
        
        if is_approved:
            print(f"✅ Surrender validated, generated unlock code: {unlock_pincode}")
            return json_resp({
                'success': True,
                'approved': True,
                'pincode': unlock_pincode,
                'message': 'Your surrender has been validated. Here is your unlock code.'
            })
        else:
            print(f"❌ Surrender not approved")
            return json_resp({
                'success': True,
                'approved': False,
                'message': 'Your surrender was not convincing enough. Please try again with more sincerity.'
            })
        
    except Exception as e:
        print(f"❌ Error validating surrender: {e}")
        return json_resp({'error': 'Failed to validate surrender'}, 500)


def get_notification_settings(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get user notification settings"""
    try:
        customer_id = payload.get('customer_id')
        
        if not customer_id:
            return json_resp({'error': 'Customer ID is required'}, 400)
        
        # Get customer record from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        response = table.get_item(Key={'customer_id': customer_id})
        
        if 'Item' not in response:
            return json_resp({'error': 'Customer not found'}, 404)
        
        customer_data = response['Item']
        
        # Extract notification settings or use defaults
        notification_settings = customer_data.get('notification_settings', {
            'email_notifications': True,
            'weekly_reports': True,
            'milestone_alerts': True,
            'unlock_notifications': False,
            'whatsapp_notifications': False
        })
        
        print(f"✅ Retrieved notification settings for customer {customer_id}")
        
        return json_resp({
            'success': True,
            'settings': notification_settings
        })
        
    except Exception as e:
        print(f"❌ Error getting notification settings: {e}")
        return json_resp({'error': 'Failed to get notification settings'}, 500)


def update_notification_settings(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Update user notification settings"""
    try:
        customer_id = payload.get('customer_id')
        settings = payload.get('settings', {})
        
        if not customer_id:
            return json_resp({'error': 'Customer ID is required'}, 400)
        
        # Update customer record in DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ.get('SUBSCRIBERS_TABLE', 'stj_subscribers'))
        
        # Update notification settings
        table.update_item(
            Key={'customer_id': customer_id},
            UpdateExpression='SET notification_settings = :settings, last_updated = :timestamp',
            ExpressionAttributeValues={
                ':settings': settings,
                ':timestamp': datetime.now().isoformat()
            }
        )
        
        print(f"✅ Updated notification settings for customer {customer_id}")
        
        return json_resp({
            'success': True,
            'message': 'Notification settings updated successfully',
            'settings': settings
        })
        
    except Exception as e:
        print(f"❌ Error updating notification settings: {e}")
        return json_resp({'error': 'Failed to update notification settings'}, 500)


# =============================================================================
# MAIN HANDLER
# =============================================================================

def handler(event, context):
    """Main Lambda handler"""
    try:
        print(f"🚀 Lambda started: {json.dumps(event, default=str)}")
        
        # Check if this is an SQS event (from EventBridge)
        if "Records" in event:
            return handle_sqs_events(event, context)
        
        method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method", "GET")
        path = event.get("path") or event.get("requestContext", {}).get("http", {}).get("path", "/")
        
        print(f"📍 {method} {path}")
        
        # Handle OPTIONS for CORS
        if method == "OPTIONS":
            return json_resp({"ok": True})
            
        # App Proxy requests (from Shopify storefront)
        # Shopify will forward requests to the root of your proxy URL
        if method == "GET" and (path == "/" or path == "" or "apps" in path or "proxy" in path):
            return handle_app_proxy(event)
            
        # JWT verification endpoint for app.screentimejourney.com
        if path.endswith("/verify-jwt") or path.endswith("/verify_jwt"):
            return handle_jwt_verification(event)
            
        # Parse body for POST requests
        body = parse_body(event) if method == "POST" else {}
        
        # POST request endpoints
        if method == "POST":
            # Handle Frontend API endpoints FIRST (no signature verification needed)
            if path.endswith("/evaluate_only"):
                print(f"📞 Evaluate_only called with body: {body}")
                response = evaluate_only(body)
                print(f"📤 Evaluate_only response: {response}")
                return response
            elif path.endswith("/evaluate-and-start"):
                return evaluate_commitment(body)
            elif path.endswith("/create-checkout"):
                return create_checkout(body)
            elif path.endswith("/create_webapp_checkout"):
                print(f"📞 Create_webapp_checkout called with body: {body}")
                response = create_webapp_checkout(body)
                print(f"📤 Create_webapp_checkout response: {response}")
                return response
            elif path.endswith("/save_profile"):
                print(f"📞 Save_profile called with body: {body}")
                response = save_customer_profile(body)
                print(f"📤 Save_profile response: {response}")
                return response
            elif path.endswith("/check_username"):
                print(f"📞 Check_username called with body: {body}")
                response = check_username_availability(body)
                print(f"📤 Check_username response: {response}")
                return response
            elif path.endswith("/send_whatsapp_code"):
                print(f"📞 Send_whatsapp_code called with body: {body}")
                response = send_whatsapp_verification_code(body)
                print(f"📤 Send_whatsapp_code response: {response}")
                return response
            elif path.endswith("/verify_whatsapp_code"):
                print(f"📞 Verify_whatsapp_code called with body: {body}")
                response = verify_whatsapp_verification_code(body)
                print(f"📤 Verify_whatsapp_code response: {response}")
                return response
            elif path.endswith("/get_profile"):
                print(f"📞 Get_profile called with body: {body}")
                response = get_customer_profile(body)
                print(f"📤 Get_profile response: {response}")
                return response
            elif path.endswith("/update_profile"):
                print(f"📞 Update_profile called with body: {body}")
                response = update_customer_profile(body)
                print(f"📤 Update_profile response: {response}")
                return response
            elif path.endswith("/get_milestones"):
                print(f"📞 Get_milestones called with body: {body}")
                response = get_milestones(body)
                print(f"📤 Get_milestones response: {response}")
                return response
            elif path.endswith("/get_system_config"):
                print(f"📞 Get_system_config called with body: {body}")
                response = get_system_config(body)
                print(f"📤 Get_system_config response: {response}")
                return response
            elif path.endswith("/store_pincode"):
                print(f"📞 Store_pincode called with body: {body}")
                response = store_pincode(body)
                print(f"📤 Store_pincode response: {response}")
                return response
            elif path.endswith("/generate_vpn_profile"):
                print(f"📞 Generate_vpn_profile called with body: {body}")
                response = generate_vpn_profile(body)
                print(f"📤 Generate_vpn_profile response: {response}")
                return response
            elif path.endswith("/generate_audio"):
                print(f"📞 Generate_audio called with body: {body}")
                response = generate_audio_guide(body)
                print(f"📤 Generate_audio response: {response}")
                return response
            elif path.endswith("/validate_surrender"):
                print(f"📞 Validate_surrender called with body: {body}")
                response = validate_surrender(body)
                print(f"📤 Validate_surrender response: {response}")
                return response
            elif path.endswith("/get_notifications"):
                print(f"📞 Get_notifications called with body: {body}")
                response = get_notification_settings(body)
                print(f"📤 Get_notifications response: {response}")
                return response
            elif path.endswith("/update_notifications"):
                print(f"📞 Update_notifications called with body: {body}")
                response = update_notification_settings(body)
                print(f"📤 Update_notifications response: {response}")
                return response
            
            # Check if this is a Shopify Flow webhook (different signature handling)
            is_shopify_flow = (
                path.endswith("/subscription-created") or 
                path.endswith("/subscription-cancelled") or 
                path.endswith("/subscription-canceled") or 
                path.endswith("/orders-created")
            )
            
            # ONLY Shopify Flow webhooks are supported (Bearer token authentication)
            if is_shopify_flow:
                # Check for Bearer token authorization
                headers = event.get("headers", {})
                auth_header = headers.get("authorization") or headers.get("Authorization", "")
                api_secret = os.environ.get('SHOPIFY_API_SECRET', '')
                
                # Handle both "Bearer" and "earer" cases (sometimes B gets truncated)
                valid_tokens = [
                    f"Bearer {api_secret}",
                    f"earer {api_secret}"  # Handle truncated case
                ]
                
                if not auth_header or auth_header not in valid_tokens:
                    print(f"❌ Invalid Flow webhook authorization: '{auth_header}' (expected: Bearer {api_secret})")
                    return json_resp({"error": "Invalid authorization"}, 401)
                else:
                    print(f"✅ Valid Flow webhook authorization")
                    
                # Handle Shopify Flow webhook endpoints
                if path.endswith("/subscription-created"):
                    return handle_subscription_created(body)
                elif path.endswith("/subscription-cancelled") or path.endswith("/subscription-canceled"):
                    return handle_subscription_cancelled(body)
                elif path.endswith("/orders-created"):
                    return handle_order_created(body)
            else:
                # Reject ALL native Shopify webhooks - only Flow webhooks allowed
                print(f"❌ Native Shopify webhooks not supported. Path: {path}")
                return json_resp({"error": "Only Shopify Flow webhooks are supported"}, 400)
                
        # Default health check
        return json_resp({
            "message": "Screen Time Journey API", 
            "status": "healthy",
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"❌ Lambda handler error: {e}")
        return json_resp({"error": "Internal server error"}, 500)
