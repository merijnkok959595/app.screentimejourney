#!/bin/bash

# Deploy Audio Generation Lambda Function
# This script packages and deploys the audio generation handler to AWS Lambda

echo "🎵 Deploying Audio Generation Lambda Function..."

# Set variables
FUNCTION_NAME="mk-screentime-audio-generator"
REGION="eu-north-1"
RUNTIME="python3.9"
HANDLER="generate_audio_handler.lambda_handler"
ROLE_ARN="arn:aws:iam::218638337917:role/lambda-execution-role"

# Create deployment package
echo "📦 Creating deployment package..."

# Create temporary directory
mkdir -p audio_package
cd audio_package

# Copy handler file
cp ../generate_audio_handler.py .

# Install dependencies
echo "📚 Installing dependencies..."
pip install -r ../audio_requirements.txt -t .

# Create deployment zip
echo "🗜️ Creating deployment package..."
zip -r ../audio-lambda-deployment.zip .

# Clean up
cd ..
rm -rf audio_package

# Deploy to AWS Lambda
echo "🚀 Deploying to AWS Lambda..."

# Check if function exists
if aws lambda get-function --function-name $FUNCTION_NAME --region $REGION >/dev/null 2>&1; then
    echo "📝 Updating existing function..."
    aws lambda update-function-code \
        --function-name $FUNCTION_NAME \
        --zip-file fileb://audio-lambda-deployment.zip \
        --region $REGION
        
    aws lambda update-function-configuration \
        --function-name $FUNCTION_NAME \
        --runtime $RUNTIME \
        --handler $HANDLER \
        --timeout 30 \
        --memory-size 512 \
        --region $REGION
else
    echo "🆕 Creating new function..."
    aws lambda create-function \
        --function-name $FUNCTION_NAME \
        --runtime $RUNTIME \
        --role $ROLE_ARN \
        --handler $HANDLER \
        --zip-file fileb://audio-lambda-deployment.zip \
        --timeout 30 \
        --memory-size 512 \
        --region $REGION \
        --environment Variables='{
            "S3_BUCKET":"wati-audio-guides",
            "DYNAMODB_TABLE":"MK_audio_guides"
        }'
fi

# Create function URL (if needed)
echo "🔗 Setting up Function URL..."
aws lambda create-function-url-config \
    --function-name $FUNCTION_NAME \
    --auth-type NONE \
    --cors '{
        "AllowCredentials": false,
        "AllowHeaders": ["Content-Type"],
        "AllowMethods": ["POST", "OPTIONS"],
        "AllowOrigins": ["*"],
        "ExposeHeaders": [],
        "MaxAge": 300
    }' \
    --region $REGION 2>/dev/null || echo "Function URL already exists"

# Get function URL
FUNCTION_URL=$(aws lambda get-function-url-config --function-name $FUNCTION_NAME --region $REGION --query 'FunctionUrl' --output text 2>/dev/null)

echo "✅ Audio Generation Lambda deployed successfully!"
echo "🌐 Function URL: $FUNCTION_URL"
echo "📊 Function Name: $FUNCTION_NAME"
echo "🗂️ S3 Bucket: wati-audio-guides"
echo "🗄️ DynamoDB Table: MK_audio_guides"

# Clean up deployment package
rm -f audio-lambda-deployment.zip

echo "🎉 Deployment complete!"

