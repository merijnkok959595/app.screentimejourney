"""
AWS Lambda handler for validating voice surrender using ChatGPT
Processes audio file, transcribes it, and validates with ChatGPT API
"""

import json
import boto3
import uuid
import time
import base64
from decimal import Decimal
import logging
import requests
import io

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3_client = boto3.client('s3', region_name='eu-north-1')
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')

# Configuration
S3_BUCKET = 'wati-audio-surrenders'
SURRENDER_TABLE = 'stj_surrenders'
OPENAI_API_KEY = 'sk-your-openai-key-here'  # Set this in environment variables

def transcribe_audio_openai(audio_data):
    """Transcribe audio using OpenAI Whisper API"""
    try:
        # Prepare the audio file for OpenAI
        files = {
            'file': ('surrender.webm', audio_data, 'audio/webm'),
            'model': (None, 'whisper-1')
        }
        
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}'
        }
        
        response = requests.post(
            'https://api.openai.com/v1/audio/transcriptions',
            headers=headers,
            files=files
        )
        
        if response.status_code == 200:
            transcription = response.json().get('text', '')
            logger.info(f"✅ Audio transcribed successfully: {transcription[:100]}...")
            return transcription
        else:
            logger.error(f"❌ OpenAI transcription failed: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"❌ Error transcribing audio: {str(e)}")
        return None

def validate_surrender_with_chatgpt(transcription, expected_text):
    """Validate surrender transcription using ChatGPT"""
    try:
        prompt = f"""
You are validating a voice surrender recording for a screen time accountability app.

EXPECTED TEXT (must be read exactly):
"{expected_text}"

ACTUAL TRANSCRIPTION:
"{transcription}"

VALIDATION RULES:
1. The user must say ALL key phrases about giving up screen time habits
2. The user must mention being a "present family man" or similar family responsibility
3. The user must mention "distraction over discipline"
4. The user must use the word "surrender" or "give up"
5. Minor word variations are acceptable (e.g., "give up" vs "surrender")
6. The core meaning and commitment must be preserved

Respond with ONLY a JSON object:
{{"approved": true/false, "reason": "explanation why approved or rejected"}}

Be strict but fair. The user must demonstrate genuine commitment to the surrender.
"""

        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'model': 'gpt-4',
            'messages': [
                {
                    'role': 'system',
                    'content': 'You are a strict validator for accountability surrenders. Be thorough and fair.'
                },
                {
                    'role': 'user',
                    'content': prompt
                }
            ],
            'temperature': 0.1,
            'max_tokens': 200
        }
        
        response = requests.post(
            'https://api.openai.com/v1/chat/completions',
            headers=headers,
            json=data
        )
        
        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']
            
            try:
                validation_result = json.loads(content)
                logger.info(f"✅ ChatGPT validation: {validation_result}")
                return validation_result
            except json.JSONDecodeError:
                logger.error(f"❌ Invalid JSON from ChatGPT: {content}")
                return {"approved": False, "reason": "Invalid response format"}
                
        else:
            logger.error(f"❌ ChatGPT API failed: {response.text}")
            return {"approved": False, "reason": "API validation failed"}
            
    except Exception as e:
        logger.error(f"❌ Error validating with ChatGPT: {str(e)}")
        return {"approved": False, "reason": f"Validation error: {str(e)}"}

def lambda_handler(event, context):
    """Main Lambda handler for surrender validation"""
    try:
        logger.info(f"🎙️ Surrender validation request: {event}")
        
        # Parse multipart form data (simplified handling)
        # In production, you'd use a proper multipart parser
        body = event.get('body')
        if event.get('isBase64Encoded'):
            body = base64.b64decode(body)
        
        # Extract form data (simplified - in production use proper multipart parsing)
        # For now, we'll work with JSON body for testing
        if isinstance(body, bytes):
            try:
                data = json.loads(body.decode('utf-8'))
            except:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({
                        'success': False,
                        'error': 'Invalid request format'
                    })
                }
        else:
            data = json.loads(body) if isinstance(body, str) else body
        
        user_id = data.get('user_id', 'anonymous')
        device_id = data.get('device_id', 'unknown')
        surrender_text = data.get('surrender_text', '')
        
        # For testing purposes, simulate the validation
        # In production, you'd extract the actual audio file from multipart data
        
        # Mock transcription for testing
        mock_transcription = "I hereby give up on changing my screen time habits. I give up the chance to be a present family man, live with more presence and purpose, and give attention to my wife and children. I choose distraction over discipline, and I surrender my intention to grow."
        
        # Validate with ChatGPT
        validation_result = validate_surrender_with_chatgpt(mock_transcription, surrender_text)
        
        # Generate unique identifier
        surrender_id = str(uuid.uuid4())
        timestamp = int(time.time())
        
        # Store surrender record in DynamoDB
        surrender_table = dynamodb.Table(SURRENDER_TABLE)
        
        surrender_record = {
            'surrender_id': surrender_id,
            'user_id': user_id,
            'device_id': device_id,
            'surrender_text': surrender_text,
            'transcription': mock_transcription,
            'approved': validation_result.get('approved', False),
            'reason': validation_result.get('reason', ''),
            'created_at': timestamp,
            'validation_method': 'chatgpt',
            'status': 'processed'
        }
        
        try:
            surrender_table.put_item(Item=surrender_record)
            logger.info(f"✅ Surrender record stored: {surrender_id}")
        except Exception as e:
            logger.error(f"❌ Failed to store surrender record: {str(e)}")
            # Continue even if storage fails
        
        # Prepare response
        response_data = {
            'success': True,
            'approved': validation_result.get('approved', False),
            'reason': validation_result.get('reason', ''),
            'surrender_id': surrender_id,
            'timestamp': timestamp
        }
        
        logger.info(f"🎯 Surrender validation complete: {response_data}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"❌ Error processing surrender: {str(e)}", exc_info=True)
        
        error_response = {
            'success': False,
            'error': f'Surrender validation failed: {str(e)}',
            'errorType': type(e).__name__
        }
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(error_response)
        }

def handler(event, context):
    """Alternative handler name for compatibility"""
    return lambda_handler(event, context)

