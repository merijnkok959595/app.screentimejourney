#!/bin/bash

# Deploy Main Lambda Function with WATI Integration
echo "🚀 Deploying Main Lambda Function with WATI API integration..."

# Set variables
FUNCTION_NAME="mk_shopify_web_app"
REGION="eu-north-1"
RUNTIME="python3.9"
HANDLER="lambda_handler.lambda_handler"

# Create deployment package
echo "📦 Creating deployment package..."

# Create temporary directory
mkdir -p deployment_package
cd deployment_package

# Copy main handler
cp ../lambda_handler.py .

# Install dependencies
echo "📚 Installing dependencies..."
pip install -r ../requirements.txt -t .

# Create deployment zip
echo "🗜️ Creating deployment package..."
zip -r ../main-lambda-deployment.zip .

# Clean up
cd ..
rm -rf deployment_package

# Deploy to AWS Lambda
echo "🚀 Deploying to AWS Lambda..."

# Check if function exists
if aws lambda get-function --function-name $FUNCTION_NAME --region $REGION >/dev/null 2>&1; then
    echo "📝 Updating existing function..."
    aws lambda update-function-code \
        --function-name $FUNCTION_NAME \
        --zip-file fileb://main-lambda-deployment.zip \
        --region $REGION
        
    aws lambda update-function-configuration \
        --function-name $FUNCTION_NAME \
        --runtime $RUNTIME \
        --handler $HANDLER \
        --timeout 30 \
        --memory-size 512 \
        --environment Variables='{
            "APP_BASE_URL":"https://app.screentimejourney.com",
            "JWT_SECRET":"STJ-app-proxy-secure-jwt-secret-2025",
            "SHOPIFY_API_SECRET":"b039bfce077daf625c9b1791331357b1",
            "SHOP_DOMAIN":"xpvznx-9w.myshopify.com",
            "SUBSCRIBERS_TABLE":"stj_subscribers",
            "AUTH_TABLE":"stj_auth_codes"
        }' \
        --region $REGION
else
    echo "❌ Function $FUNCTION_NAME not found. Please create it first in AWS Console."
    exit 1
fi

# Get function URL
FUNCTION_URL=$(aws lambda get-function-url-config --function-name $FUNCTION_NAME --region $REGION --query 'FunctionUrl' --output text 2>/dev/null)

echo "✅ Main Lambda deployed successfully!"
echo "🌐 Function URL: $FUNCTION_URL"
echo "📊 Function Name: $FUNCTION_NAME"
echo ""
echo "🔧 WATI Integration Features:"
echo "   ✅ Real WhatsApp verification codes"
echo "   ✅ DynamoDB storage for auth codes"
echo "   ✅ Code expiry and validation"
echo "   ✅ Customer ID verification"

# Clean up deployment package
rm -f main-lambda-deployment.zip

echo "🎉 Deployment complete!"
