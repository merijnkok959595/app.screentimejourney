#!/bin/bash

# Setup AWS Resources for Subscription Cancellation
# This script creates DynamoDB tables and other resources needed for cancellation flow

echo "🚀 Setting up AWS resources for subscription cancellation..."
echo "============================================================"

REGION="eu-north-1"
CANCELLATION_TABLE="stj_cancellations"

echo "📊 Creating DynamoDB table: $CANCELLATION_TABLE"

# Create cancellations table
aws dynamodb create-table \
    --table-name $CANCELLATION_TABLE \
    --attribute-definitions \
        AttributeName=cancellation_id,AttributeType=S \
        AttributeName=user_id,AttributeType=S \
        AttributeName=request_timestamp,AttributeType=N \
    --key-schema \
        AttributeName=cancellation_id,KeyType=HASH \
    --global-secondary-indexes \
        IndexName=UserIndex,KeySchema='[{AttributeName=user_id,KeyType=HASH},{AttributeName=request_timestamp,KeyType=RANGE}]',Projection='{ProjectionType=ALL}',ProvisionedThroughput='{ReadCapacityUnits=5,WriteCapacityUnits=5}' \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region $REGION

echo "⏳ Waiting for table to become active..."
aws dynamodb wait table-exists --table-name $CANCELLATION_TABLE --region $REGION

echo "✅ Table $CANCELLATION_TABLE created successfully"

echo "🔍 Verifying SES email address..."
# Check if FROM_EMAIL is verified in SES
FROM_EMAIL="noreply@screentimejourney.com"
aws ses get-identity-verification-attributes \
    --identities $FROM_EMAIL \
    --region $REGION

echo "============================================================"
echo "✅ Resource setup completed!"
echo ""
echo "📋 Created Resources:"
echo "   • DynamoDB Table: $CANCELLATION_TABLE"
echo "   • Region: $REGION"
echo ""
echo "📝 Next Steps:"
echo "   1. Verify $FROM_EMAIL in AWS SES if not already verified"
echo "   2. Configure Shopify access tokens"
echo "   3. Deploy the Lambda function using deploy_cancel_lambda.sh"
echo "   4. Test the cancellation flow"
echo ""
echo "⚠️  Note: If SES email verification failed above, verify the email address:"
echo "   aws ses verify-email-identity --email-address $FROM_EMAIL --region $REGION"
echo ""
echo "============================================================"

