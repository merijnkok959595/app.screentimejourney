"""
AWS Lambda handler for sending unlock emails with pincode
Sends email notification when device unlock is approved
"""

import json
import boto3
import time
import logging
from decimal import Decimal

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
ses_client = boto3.client('ses', region_name='eu-north-1')
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')

# Configuration
FROM_EMAIL = 'noreply@screentimejourney.com'  # Must be verified in SES
EMAIL_TABLE = 'stj_unlock_emails'

def lambda_handler(event, context):
    """Main Lambda handler for sending unlock emails"""
    try:
        logger.info(f"📧 Unlock email request: {event}")
        
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Extract parameters
        user_id = body.get('user_id', 'anonymous')
        pincode = body.get('pincode', '0000')
        device_id = body.get('device_id', 'unknown')
        device_name = body.get('device_name', 'Unknown Device')
        
        # Get user email (in production, fetch from user database)
        user_email = get_user_email(user_id)
        
        if not user_email:
            logger.warning(f"No email found for user {user_id}")
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': 'User email not found'
                })
            }
        
        # Generate email content
        email_subject = f"🔓 Device Unlock Code - {device_name}"
        email_body = generate_unlock_email_html(pincode, device_name, user_id)
        
        # Send email via SES
        try:
            response = ses_client.send_email(
                Source=FROM_EMAIL,
                Destination={
                    'ToAddresses': [user_email]
                },
                Message={
                    'Subject': {
                        'Data': email_subject,
                        'Charset': 'UTF-8'
                    },
                    'Body': {
                        'Html': {
                            'Data': email_body,
                            'Charset': 'UTF-8'
                        },
                        'Text': {
                            'Data': f"Your unlock code for {device_name}: {pincode}\n\nThis code is valid for 15 minutes.",
                            'Charset': 'UTF-8'
                        }
                    }
                }
            )
            
            message_id = response['MessageId']
            logger.info(f"✅ Email sent successfully: {message_id}")
            
        except Exception as e:
            logger.error(f"❌ Failed to send email: {str(e)}")
            # Continue to log the attempt even if email fails
            message_id = None
        
        # Log email attempt in DynamoDB
        log_email_attempt(user_id, user_email, pincode, device_id, device_name, message_id)
        
        # Prepare response
        response_data = {
            'success': True,
            'message_id': message_id,
            'user_email': user_email,
            'pincode': pincode,
            'device_name': device_name,
            'timestamp': int(time.time())
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"❌ Error sending unlock email: {str(e)}", exc_info=True)
        
        error_response = {
            'success': False,
            'error': f'Email sending failed: {str(e)}',
            'errorType': type(e).__name__
        }
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(error_response)
        }

def get_user_email(user_id):
    """Get user email from customer data (implement based on your user system)"""
    # In production, fetch from your user database
    # For now, return a mock email for testing
    if user_id == 'dev_user_123':
        return 'test@example.com'
    
    # Try to get from customer table or return mock
    return 'user@screentimejourney.com'

def generate_unlock_email_html(pincode, device_name, user_id):
    """Generate HTML email content for unlock notification"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Device Unlock Code</title>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: #2E0456; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }}
            .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }}
            .pincode-box {{ background: white; border: 3px solid #10b981; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0; }}
            .pincode {{ font-family: monospace; font-size: 36px; font-weight: bold; color: #059669; letter-spacing: 8px; }}
            .warning {{ background: #fef3c7; border: 1px solid #f59e0b; border-radius: 6px; padding: 16px; margin: 20px 0; }}
            .footer {{ text-align: center; margin-top: 30px; font-size: 12px; color: #666; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🔓 Device Unlock Approved</h1>
            <p>Screen Time Journey</p>
        </div>
        
        <div class="content">
            <h2>Your surrender has been accepted.</h2>
            
            <p>You have requested to unlock <strong>{device_name}</strong>. Below is your temporary unlock code:</p>
            
            <div class="pincode-box">
                <div class="pincode">{pincode}</div>
                <p style="margin: 10px 0 0 0; color: #047857;">Enter this code on your device</p>
            </div>
            
            <div class="warning">
                <p style="margin: 0; color: #92400e; font-weight: 500;">
                    ⚠️ <strong>Remember:</strong> This unlock comes with the acknowledgment of what you're giving up in your journey toward presence and purpose.
                </p>
            </div>
            
            <p><strong>Valid for:</strong> 15 minutes from now</p>
            <p><strong>Device:</strong> {device_name}</p>
            <p><strong>Time:</strong> {time.strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
            
            <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
            
            <p style="font-style: italic; color: #666;">
                "Every unlock is a choice. Every choice shapes your journey. Use this time mindfully."
            </p>
        </div>
        
        <div class="footer">
            <p>Screen Time Journey | Transforming habits, building presence</p>
            <p>This email was sent because you requested a device unlock.</p>
        </div>
    </body>
    </html>
    """

def log_email_attempt(user_id, user_email, pincode, device_id, device_name, message_id):
    """Log email attempt to DynamoDB"""
    try:
        email_table = dynamodb.Table(EMAIL_TABLE)
        
        email_record = {
            'user_id': user_id,
            'timestamp': Decimal(str(int(time.time()))),
            'email': user_email,
            'pincode': pincode,
            'device_id': device_id,
            'device_name': device_name,
            'message_id': message_id,
            'status': 'sent' if message_id else 'failed',
            'email_type': 'unlock_notification',
            'created_at': time.strftime('%Y-%m-%d %H:%M:%S UTC')
        }
        
        email_table.put_item(Item=email_record)
        logger.info(f"✅ Email attempt logged for user {user_id}")
        
    except Exception as e:
        logger.error(f"❌ Failed to log email attempt: {str(e)}")

def handler(event, context):
    """Alternative handler name for compatibility"""
    return lambda_handler(event, context)

