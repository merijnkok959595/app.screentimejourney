"""
AWS Lambda handler for subscription cancellation via Shopify API
Handles subscription cancellation requests with proper Shopify API integration
"""

import json
import boto3
import time
import requests
import logging
from decimal import Decimal
from datetime import datetime

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')
ses_client = boto3.client('ses', region_name='eu-north-1')

# Configuration
SUBSCRIBERS_TABLE = 'stj_subscribers'
CANCELLATION_TABLE = 'stj_cancellations'
FROM_EMAIL = 'noreply@screentimejourney.com'

def lambda_handler(event, context):
    """Main Lambda handler for subscription cancellation"""
    try:
        logger.info(f"📥 Cancellation request: {event}")
        
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Extract parameters
        user_id = body.get('user_id', 'anonymous')
        customer_email = body.get('customer_email', '')
        shop = body.get('shop', '')
        subscription_id = body.get('subscription_id')
        cancel_reason = body.get('cancel_reason', '')
        feedback = body.get('feedback', '')
        cancel_date = body.get('cancel_date', datetime.now().isoformat())
        
        logger.info(f"🔄 Processing cancellation for user: {user_id}, shop: {shop}")
        
        # Validate required fields
        if not all([user_id, customer_email, shop]):
            return {
                'statusCode': 400,
                'headers': get_cors_headers(),
                'body': json.dumps({
                    'success': False,
                    'error': 'Missing required fields: user_id, customer_email, shop'
                })
            }
        
        # Log cancellation request
        cancellation_record = log_cancellation_request(
            user_id, customer_email, shop, subscription_id, 
            cancel_reason, feedback, cancel_date
        )
        
        # Cancel subscription via Shopify API
        shopify_result = cancel_shopify_subscription(shop, subscription_id, user_id)
        
        if not shopify_result['success']:
            logger.warning(f"⚠️ Shopify cancellation failed, continuing with local cancellation")
            # Continue with local cancellation even if Shopify fails
        
        # Update subscriber status in DynamoDB
        update_result = update_subscriber_status(user_id, 'cancelled', cancel_reason, feedback)
        
        # Send cancellation confirmation email
        email_result = send_cancellation_email(
            customer_email, user_id, cancel_reason, feedback, shop
        )
        
        # Update cancellation record with results
        update_cancellation_record(
            cancellation_record['cancellation_id'], 
            shopify_result, 
            update_result, 
            email_result
        )
        
        # Prepare response
        response_data = {
            'success': True,
            'cancellation_id': cancellation_record['cancellation_id'],
            'shopify_cancelled': shopify_result['success'],
            'database_updated': update_result,
            'email_sent': email_result['success'],
            'message': 'Subscription cancelled successfully',
            'timestamp': int(time.time())
        }
        
        logger.info(f"✅ Cancellation completed: {response_data}")
        
        return {
            'statusCode': 200,
            'headers': get_cors_headers(),
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        logger.error(f"❌ Error processing cancellation: {str(e)}", exc_info=True)
        
        error_response = {
            'success': False,
            'error': f'Cancellation failed: {str(e)}',
            'errorType': type(e).__name__
        }
        
        return {
            'statusCode': 500,
            'headers': get_cors_headers(),
            'body': json.dumps(error_response)
        }

def cancel_shopify_subscription(shop, subscription_id, user_id):
    """Cancel subscription via Shopify Subscription Contracts API"""
    try:
        # Get Shopify credentials from environment or secrets
        shopify_access_token = get_shopify_access_token(shop)
        
        if not shopify_access_token:
            logger.warning(f"No Shopify access token found for shop: {shop}")
            return {'success': False, 'error': 'No access token found'}
        
        if not subscription_id:
            logger.warning("No subscription ID provided")
            return {'success': False, 'error': 'No subscription ID provided'}
        
        # Shopify GraphQL mutation to cancel subscription
        graphql_query = """
        mutation subscriptionContractCancel($subscriptionContractId: ID!) {
          subscriptionContractCancel(subscriptionContractId: $subscriptionContractId) {
            subscriptionContract {
              id
              status
              lastPaymentStatus
            }
            userErrors {
              field
              message
            }
          }
        }
        """
        
        variables = {
            'subscriptionContractId': f'gid://shopify/SubscriptionContract/{subscription_id}'
        }
        
        headers = {
            'Content-Type': 'application/json',
            'X-Shopify-Access-Token': shopify_access_token
        }
        
        url = f'https://{shop}/admin/api/2023-10/graphql.json'
        
        payload = {
            'query': graphql_query,
            'variables': variables
        }
        
        logger.info(f"📡 Sending Shopify cancellation request for subscription: {subscription_id}")
        
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            
            if 'errors' in result:
                logger.error(f"❌ Shopify GraphQL errors: {result['errors']}")
                return {'success': False, 'error': result['errors']}
            
            data = result.get('data', {})
            cancel_result = data.get('subscriptionContractCancel', {})
            
            if cancel_result.get('userErrors'):
                logger.error(f"❌ Shopify user errors: {cancel_result['userErrors']}")
                return {'success': False, 'error': cancel_result['userErrors']}
            
            subscription = cancel_result.get('subscriptionContract', {})
            logger.info(f"✅ Shopify subscription cancelled: {subscription}")
            
            return {
                'success': True,
                'shopify_response': subscription,
                'new_status': subscription.get('status'),
                'payment_status': subscription.get('lastPaymentStatus')
            }
        else:
            logger.error(f"❌ Shopify API error: {response.status_code} - {response.text}")
            return {'success': False, 'error': f'Shopify API error: {response.status_code}'}
            
    except Exception as e:
        logger.error(f"❌ Error cancelling Shopify subscription: {str(e)}")
        return {'success': False, 'error': str(e)}

def get_shopify_access_token(shop):
    """Get Shopify access token for the shop (implement based on your auth system)"""
    # In production, fetch from your secure storage
    # For now, return environment variable or mock
    import os
    return os.environ.get('SHOPIFY_ACCESS_TOKEN', 'mock_token_for_testing')

def log_cancellation_request(user_id, customer_email, shop, subscription_id, cancel_reason, feedback, cancel_date):
    """Log cancellation request to DynamoDB"""
    try:
        cancellation_table = dynamodb.Table(CANCELLATION_TABLE)
        
        cancellation_id = f"cancel_{user_id}_{int(time.time())}"
        
        cancellation_record = {
            'cancellation_id': cancellation_id,
            'user_id': user_id,
            'customer_email': customer_email,
            'shop': shop,
            'subscription_id': subscription_id,
            'cancel_reason': cancel_reason,
            'feedback': feedback,
            'cancel_date': cancel_date,
            'request_timestamp': Decimal(str(int(time.time()))),
            'status': 'processing',
            'created_at': datetime.now().isoformat()
        }
        
        cancellation_table.put_item(Item=cancellation_record)
        logger.info(f"✅ Logged cancellation request: {cancellation_id}")
        
        return cancellation_record
        
    except Exception as e:
        logger.error(f"❌ Failed to log cancellation request: {str(e)}")
        return {'cancellation_id': f"error_{int(time.time())}"}

def update_subscriber_status(user_id, status, cancel_reason, feedback):
    """Update subscriber status in DynamoDB"""
    try:
        subscribers_table = dynamodb.Table(SUBSCRIBERS_TABLE)
        
        # Get existing record
        response = subscribers_table.get_item(Key={'customer_id': user_id})
        
        if 'Item' not in response:
            logger.warning(f"Subscriber {user_id} not found in database")
            return False
        
        # Update status
        update_expression = """
            SET subscription_status = :status,
                #last_updated = :timestamp,
                cancel_reason = :reason,
                feedback = :feedback,
                cancelled_at = :cancelled_at
        """
        
        expression_attribute_names = {
            '#last_updated': 'last_updated'
        }
        
        expression_attribute_values = {
            ':status': status,
            ':timestamp': datetime.now().isoformat(),
            ':reason': cancel_reason,
            ':feedback': feedback,
            ':cancelled_at': datetime.now().isoformat()
        }
        
        subscribers_table.update_item(
            Key={'customer_id': user_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values
        )
        
        logger.info(f"✅ Updated subscriber status to {status} for user: {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to update subscriber status: {str(e)}")
        return False

def send_cancellation_email(customer_email, user_id, cancel_reason, feedback, shop):
    """Send cancellation confirmation email"""
    try:
        subject = "Your Screen Time Journey subscription has been cancelled"
        html_body = generate_cancellation_email_html(user_id, cancel_reason, feedback, shop)
        text_body = generate_cancellation_email_text(user_id, cancel_reason, feedback, shop)
        
        response = ses_client.send_email(
            Source=FROM_EMAIL,
            Destination={'ToAddresses': [customer_email]},
            Message={
                'Subject': {
                    'Data': subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Html': {
                        'Data': html_body,
                        'Charset': 'UTF-8'
                    },
                    'Text': {
                        'Data': text_body,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        
        message_id = response['MessageId']
        logger.info(f"✅ Cancellation email sent: {message_id}")
        
        return {'success': True, 'message_id': message_id}
        
    except Exception as e:
        logger.error(f"❌ Failed to send cancellation email: {str(e)}")
        return {'success': False, 'error': str(e)}

def generate_cancellation_email_html(user_id, cancel_reason, feedback, shop):
    """Generate HTML cancellation email"""
    reason_text = {
        'too_expensive': 'the subscription was too expensive',
        'not_using': 'you weren\'t using the service enough',
        'technical_issues': 'you experienced technical issues',
        'missing_features': 'missing features you needed',
        'found_alternative': 'you found a better alternative',
        'temporary_pause': 'you needed a temporary break',
        'privacy_concerns': 'privacy or data concerns',
        'other': 'other reasons'
    }.get(cancel_reason, 'unspecified reasons')
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Subscription Cancelled</title>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: #2E0456; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }}
            .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }}
            .info-box {{ background: white; border: 1px solid #d1d5db; border-radius: 8px; padding: 20px; margin: 20px 0; }}
            .footer {{ text-align: center; margin-top: 30px; font-size: 12px; color: #666; }}
            .cta-button {{ display: inline-block; background: #2E0456; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>😔 Subscription Cancelled</h1>
            <p>Screen Time Journey</p>
        </div>
        
        <div class="content">
            <h2>We're sorry to see you go</h2>
            
            <p>Your Screen Time Journey subscription has been successfully cancelled.</p>
            
            <div class="info-box">
                <h3>Cancellation Details</h3>
                <p><strong>Cancelled on:</strong> {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}</p>
                <p><strong>Reason:</strong> {reason_text.title()}</p>
                <p><strong>Your access:</strong> Continues until the end of your current billing period</p>
            </div>
            
            {f'<div class="info-box"><h3>Your Feedback</h3><p>"{feedback}"</p><p><em>Thank you for taking the time to share this with us.</em></p></div>' if feedback else ''}
            
            <h3>What happens next?</h3>
            <ul>
                <li>✅ No further charges will be made to your account</li>
                <li>📧 You'll receive a final invoice for any remaining balance</li>
                <li>🔒 Your data will be safely stored for 90 days in case you return</li>
                <li>🔄 You can reactivate anytime by visiting your dashboard</li>
            </ul>
            
            <p>If you change your mind, you can easily reactivate your subscription:</p>
            <a href="https://{shop}/apps/screen-time-journey" class="cta-button">Reactivate Subscription</a>
            
            <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;">
            
            <p>We genuinely appreciate the time you spent with Screen Time Journey. While we're sad to see you go, we understand that everyone's journey is different.</p>
            
            <p>If you ever want to restart your journey toward digital wellness, we'll be here with open arms.</p>
            
            <p style="font-style: italic; color: #666;">
                "Every ending is a new beginning. Thank you for being part of our community."
            </p>
        </div>
        
        <div class="footer">
            <p>Screen Time Journey | Building presence in a digital world</p>
            <p>If you have any questions, reply to this email or contact our support team.</p>
        </div>
    </body>
    </html>
    """

def generate_cancellation_email_text(user_id, cancel_reason, feedback, shop):
    """Generate plain text cancellation email"""
    reason_text = {
        'too_expensive': 'the subscription was too expensive',
        'not_using': 'you weren\'t using the service enough',
        'technical_issues': 'you experienced technical issues',
        'missing_features': 'missing features you needed',
        'found_alternative': 'you found a better alternative',
        'temporary_pause': 'you needed a temporary break',
        'privacy_concerns': 'privacy or data concerns',
        'other': 'other reasons'
    }.get(cancel_reason, 'unspecified reasons')
    
    return f"""
Screen Time Journey - Subscription Cancelled

We're sorry to see you go.

Your Screen Time Journey subscription has been successfully cancelled.

CANCELLATION DETAILS:
- Cancelled on: {datetime.now().strftime('%B %d, %Y at %I:%M %p UTC')}
- Reason: {reason_text.title()}
- Your access: Continues until the end of your current billing period

{f'YOUR FEEDBACK: "{feedback}" - Thank you for taking the time to share this with us.' if feedback else ''}

WHAT HAPPENS NEXT:
✅ No further charges will be made to your account
📧 You'll receive a final invoice for any remaining balance
🔒 Your data will be safely stored for 90 days in case you return
🔄 You can reactivate anytime by visiting your dashboard

If you change your mind, you can easily reactivate your subscription by visiting:
https://{shop}/apps/screen-time-journey

We genuinely appreciate the time you spent with Screen Time Journey. While we're sad to see you go, we understand that everyone's journey is different.

If you ever want to restart your journey toward digital wellness, we'll be here with open arms.

"Every ending is a new beginning. Thank you for being part of our community."

---
Screen Time Journey | Building presence in a digital world
If you have any questions, reply to this email or contact our support team.
"""

def update_cancellation_record(cancellation_id, shopify_result, update_result, email_result):
    """Update cancellation record with processing results"""
    try:
        cancellation_table = dynamodb.Table(CANCELLATION_TABLE)
        
        update_expression = """
            SET #status = :status,
                shopify_cancelled = :shopify_success,
                shopify_response = :shopify_response,
                database_updated = :db_updated,
                email_sent = :email_success,
                email_message_id = :email_id,
                completed_timestamp = :completed_time,
                processing_errors = :errors
        """
        
        expression_attribute_names = {
            '#status': 'status'
        }
        
        errors = []
        if not shopify_result['success']:
            errors.append(f"Shopify: {shopify_result.get('error', 'Unknown error')}")
        if not update_result:
            errors.append("Database update failed")
        if not email_result['success']:
            errors.append(f"Email: {email_result.get('error', 'Unknown error')}")
        
        expression_attribute_values = {
            ':status': 'completed' if not errors else 'completed_with_errors',
            ':shopify_success': shopify_result['success'],
            ':shopify_response': json.dumps(shopify_result),
            ':db_updated': update_result,
            ':email_success': email_result['success'],
            ':email_id': email_result.get('message_id', ''),
            ':completed_time': Decimal(str(int(time.time()))),
            ':errors': json.dumps(errors) if errors else ''
        }
        
        cancellation_table.update_item(
            Key={'cancellation_id': cancellation_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values
        )
        
        logger.info(f"✅ Updated cancellation record: {cancellation_id}")
        
    except Exception as e:
        logger.error(f"❌ Failed to update cancellation record: {str(e)}")

def get_cors_headers():
    """Get CORS headers for API responses"""
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
    }

def handler(event, context):
    """Alternative handler name for compatibility"""
    return lambda_handler(event, context)

